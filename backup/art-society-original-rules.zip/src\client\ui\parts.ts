import { MOVEMENT_INFO, PATRONS, PIGMENT_INFO, awardInfo } from '../../shared/content';
import { PIGMENTS, type Artwork, type AwardId, type MovementId, type PatronId, type Pigment, type PigmentSet } from '../../shared/types';
import { artImg } from '../art/generate';
import { el, esc } from './dom';
import { icon } from './icons';

export const francs = (n: number, cls = '') => `<span class="res res-franc ${cls}" title="Francs">${icon('coin')}<b>${n}</b></span>`;
export const insp = (n: number, cls = '') => `<span class="res res-insp ${cls}" title="Inspiration">${icon('muse')}<b>${n}</b></span>`;
export const pig = (p: Pigment, n: number, cls = '') =>
  `<span class="res res-pig ${cls}" style="--pc:${PIGMENT_INFO[p].color}" title="${PIGMENT_INFO[p].name}">${icon('drop')}<b>${n}</b></span>`;
export const prestige = (n: number, cls = '') => `<span class="res res-prestige ${cls}" title="Prestige">${icon('laurel')}<b>${n}</b></span>`;

export function pigments(set: PigmentSet, cls = ''): string {
  return PIGMENTS.map((p) => pig(p, set[p], cls)).join('');
}

/** One drop per pigment needed; drops you can't cover yet are hollow. */
export function costPips(cost: PigmentSet, have?: PigmentSet): string {
  let out = '';
  for (const p of PIGMENTS) {
    for (let i = 0; i < cost[p]; i++) {
      const missing = have ? i >= have[p] : false;
      out += `<i class="drop ${missing ? 'missing' : ''}" style="--pc:${PIGMENT_INFO[p].color}"></i>`;
    }
  }
  return `<span class="cost">${out}</span>`;
}

export function movementTag(m: MovementId, short = false): string {
  const info = MOVEMENT_INFO[m];
  return `<span class="mv" style="--mv:${info.color}">${icon(m)}<span>${esc(short ? info.short : info.name)}</span></span>`;
}

export function trendStars(v: number, max = 3): string {
  let s = '';
  for (let i = 0; i < max; i++) s += `<i class="star ${i < v ? 'on' : ''}"></i>`;
  return `<span class="stars" title="Trend ${v}">${s}</span>`;
}

export interface CardOpts {
  have?: PigmentSet;
  trend?: number;
  footer?: string;
  /** HTML laid over the bottom of the painting (e.g. the Paint button). */
  overlay?: string;
  cls?: string;
  onClick?: () => void;
}

/** A sketch or masterpiece as a framed card with its painting. */
export function artCard(art: Artwork, o: CardOpts = {}): HTMLElement {
  const card = el('div', `card art-card ${art.kind} ${o.cls ?? ''}`);
  card.style.setProperty('--mv', MOVEMENT_INFO[art.movement].color);
  const frame = el('div', 'frame');
  frame.appendChild(artImg(art));
  if (art.kind === 'canvas') frame.classList.add('sketchy');
  if (o.overlay) frame.insertAdjacentHTML('beforeend', o.overlay);
  card.appendChild(frame);
  const value = o.trend !== undefined ? `${art.value}<small>+${o.trend}</small>` : `${art.value}`;
  const body = el(
    'div',
    'card-body',
    `<div class="card-title" title="${esc(art.title)}">${esc(art.title)}</div>
     <div class="card-meta">${movementTag(art.movement, true)}<span class="value" title="Prestige (base + trend)">${icon('laurel')}${value}</span></div>
     ${art.kind === 'canvas' ? costPips(art.cost, o.have) : `<div class="artist">${esc(art.artist ?? '')}</div>`}
     ${o.footer ?? ''}`,
  );
  card.appendChild(body);
  if (o.onClick) {
    card.classList.add('clickable');
    card.addEventListener('click', o.onClick);
  }
  return card;
}

export function patronCard(id: PatronId | null, cls = ''): string {
  if (!id) return `<div class="patron-card hidden-patron ${cls}"><div class="patron-seal">?</div><div class="patron-name">Secret patron</div></div>`;
  const p = PATRONS[id];
  return `<div class="patron-card ${cls}">
    <div class="patron-seal">${icon('crown')}</div>
    <div class="patron-name">${esc(p.name)}</div>
    <div class="patron-title">${esc(p.title)}</div>
    <div class="patron-text">${esc(p.text)}</div>
  </div>`;
}

export function awardChip(id: AwardId, leaders: string): string {
  const a = awardInfo(id);
  return `<div class="award"><div class="award-icon">${icon('laurel')}</div><div><div class="award-name">${esc(a.name)}</div><div class="award-text">${esc(a.text)} ${leaders}</div></div></div>`;
}

export function dot(color: string, cls = ''): string {
  return `<i class="pdot ${cls}" style="--pc:${color}"></i>`;
}
