/**
 * Authoritative rules engine. Pure TypeScript with no I/O: the server owns the state and feeds it
 * actions; every change emits GameEvents that clients turn into animations.
 */
import type {
  Action,
  Artwork,
  EventId,
  GameEvent,
  GameState,
  GameView,
  HatId,
  LogKind,
  MovementId,
  PigmentSet,
  PlayerState,
} from './types';
import { MOVEMENTS, PIGMENTS } from './types';
import {
  BOARD,
  EVENT_DECK,
  EVENTS,
  GENERAL_AWARDS,
  MOVEMENT_INFO,
  PATRON_IDS,
  PIGMENT_INFO,
  RULES,
  buildCanvasDeck,
  buildLotDeck,
  spaceInfo,
} from './content';
import { nextRandom, pick, shuffle, type Rand } from './rng';
import { computeResults, movementCounts } from './scoring';

export interface PlayerSetup {
  id: string;
  name: string;
  color: string;
  hat: HatId;
  isBot: boolean;
}

export interface GameSetup {
  seed: number;
  players: PlayerSetup[];
  rounds: number;
  now: number;
}

export type ActionResult = { ok: true; events: GameEvent[] } | { ok: false; error: string };

class Ctx {
  events: GameEvent[] = [];
  readonly r: Rand;
  constructor(
    readonly s: GameState,
    readonly now: number,
  ) {
    this.r = () => nextRandom(s);
  }
  emit(e: GameEvent) {
    this.events.push(e);
  }
  log(kind: LogKind, text: string, pid?: string) {
    const s = this.s;
    s.log.push({ id: ++s.logSeq, kind, text, pid });
    if (s.log.length > 80) s.log.splice(0, s.log.length - 80);
  }
}

/**
 * Pigments actually spent to paint `cost` from `have`, or null if impossible.
 * Mixing rule: any 2 spare pigments can stand in for 1 missing pigment of another colour.
 */
export function paymentFor(have: PigmentSet, cost: PigmentSet): PigmentSet | null {
  const pay: PigmentSet = { red: 0, blue: 0, yellow: 0 };
  const spare: PigmentSet = { red: 0, blue: 0, yellow: 0 };
  let deficit = 0;
  for (const k of PIGMENTS) {
    pay[k] = Math.min(have[k], cost[k]);
    spare[k] = have[k] - pay[k];
    deficit += cost[k] - pay[k];
  }
  let needed = deficit * RULES.mixRatio;
  if (spare.red + spare.blue + spare.yellow < needed) return null;
  while (needed > 0) {
    const k = PIGMENTS.reduce((a, b) => (spare[b] > spare[a] ? b : a));
    spare[k]--;
    pay[k]++;
    needed--;
  }
  return pay;
}

/** Number of pigments that must be mixed (not paid with the right colour). */
export function mixedCount(have: PigmentSet, cost: PigmentSet): number {
  return PIGMENTS.reduce((sum, k) => sum + Math.max(0, cost[k] - have[k]), 0);
}

export function canAfford(have: PigmentSet, cost: PigmentSet): boolean {
  return paymentFor(have, cost) !== null;
}

export function missingPigments(have: PigmentSet, cost: PigmentSet): number {
  return PIGMENTS.reduce((sum, p) => sum + Math.max(0, cost[p] - have[p]), 0);
}

export function pigmentText(set: Partial<PigmentSet>): string {
  return PIGMENTS.filter((p) => (set[p] ?? 0) !== 0)
    .map((p) => `${set[p]} ${PIGMENT_INFO[p].name.toLowerCase()}`)
    .join(', ');
}

export function activePlayer(s: { players: PlayerState[]; turn: number }): PlayerState {
  return s.players[s.turn];
}

export function createGame(setup: GameSetup): { state: GameState; events: GameEvent[] } {
  const players = setup.players;
  if (players.length < RULES.minPlayers || players.length > RULES.maxPlayers) {
    throw new Error(`A game needs ${RULES.minPlayers}-${RULES.maxPlayers} players`);
  }
  const s: GameState = {
    seed: setup.seed >>> 0,
    rng: setup.seed >>> 0,
    round: 0,
    totalRounds: Math.max(1, Math.min(30, Math.floor(setup.rounds))),
    turn: 0,
    players: [],
    trends: Object.fromEntries(MOVEMENTS.map((m) => [m, RULES.trendStart])) as Record<MovementId, number>,
    canvasDeck: [],
    canvasRow: [],
    lotDeck: [],
    eventDeck: [],
    awards: [],
    phase: { kind: 'patrons', deadline: setup.now + RULES.patronSeconds * 1000 },
    lastRoll: null,
    log: [],
    logSeq: 0,
    results: null,
  };
  const ctx = new Ctx(s, setup.now);
  const r = ctx.r;

  s.players = shuffle(r, players.slice()).map((p) => ({
    id: p.id,
    name: p.name,
    color: p.color,
    hat: p.hat,
    isBot: p.isBot,
    connected: true,
    position: 0,
    francs: RULES.startFrancs,
    pigments: { red: RULES.startPigments, blue: RULES.startPigments, yellow: RULES.startPigments },
    inspiration: RULES.startInspiration,
    hand: [],
    collection: [],
    patron: null,
    patronOffer: [],
    patronChosen: false,
    auctionSpend: 0,
  }));
  s.canvasDeck = buildCanvasDeck(r);
  s.lotDeck = buildLotDeck(r);
  s.eventDeck = shuffle(r, EVENT_DECK.slice());
  s.awards = [`master:${pick(r, MOVEMENTS)}`, ...shuffle(r, GENERAL_AWARDS.slice()).slice(0, 2)];

  for (const p of s.players) {
    for (let i = 0; i < RULES.startHand; i++) {
      const c = s.canvasDeck.shift();
      if (c) p.hand.push(c);
    }
  }
  refillRow(s);

  const patrons = shuffle(r, PATRON_IDS.slice());
  s.players.forEach((p, i) => {
    p.patronOffer = [patrons[(2 * i) % patrons.length], patrons[(2 * i + 1) % patrons.length]];
  });

  ctx.emit({ t: 'start' });
  ctx.log('info', 'The Art Society convenes. Each artist chooses a secret patron.');
  return { state: s, events: ctx.events };
}

function refillRow(s: GameState) {
  while (s.canvasRow.length < RULES.rowSize && s.canvasDeck.length > 0) {
    s.canvasRow.push(s.canvasDeck.shift()!);
  }
}

function addInspiration(ctx: Ctx, p: PlayerState, n: number) {
  const before = p.inspiration;
  p.inspiration = Math.min(RULES.maxInspiration, p.inspiration + n);
  const got = p.inspiration - before;
  if (got > 0) ctx.emit({ t: 'gain', pid: p.id, inspiration: got });
}

function addFrancs(ctx: Ctx, p: PlayerState, n: number) {
  const real = n < 0 ? -Math.min(p.francs, -n) : n;
  if (real === 0) return;
  p.francs += real;
  ctx.emit({ t: 'gain', pid: p.id, francs: real });
}

function addPigments(ctx: Ctx, p: PlayerState, set: Partial<PigmentSet>) {
  const real: Partial<PigmentSet> = {};
  let any = false;
  for (const k of PIGMENTS) {
    const n = set[k] ?? 0;
    if (!n) continue;
    const d = n < 0 ? -Math.min(p.pigments[k], -n) : n;
    if (d === 0) continue;
    p.pigments[k] += d;
    real[k] = d;
    any = true;
  }
  if (any) ctx.emit({ t: 'gain', pid: p.id, pigments: real });
}

function changeTrend(ctx: Ctx, m: MovementId, delta: number, pid?: string): number {
  const s = ctx.s;
  const before = s.trends[m];
  s.trends[m] = Math.max(RULES.trendMin, Math.min(RULES.trendMax, before + delta));
  const d = s.trends[m] - before;
  if (d !== 0) ctx.emit({ t: 'trend', movement: m, delta: d, value: s.trends[m], pid });
  return d;
}

function beginPlay(ctx: Ctx) {
  const s = ctx.s;
  s.round = 1;
  s.turn = 0;
  s.phase = { kind: 'roll' };
  s.lastRoll = null;
  ctx.emit({ t: 'round', round: 1, final: s.totalRounds === 1 });
  ctx.log('round', `Round 1 of ${s.totalRounds} begins.`);
  ctx.emit({ t: 'turn', pid: s.players[0].id });
}

function advanceTurn(ctx: Ctx) {
  const s = ctx.s;
  s.turn = (s.turn + 1) % s.players.length;
  s.lastRoll = null;
  if (s.turn === 0) {
    if (s.round >= s.totalRounds) {
      finish(ctx);
      return;
    }
    s.round++;
    const final = s.round === s.totalRounds;
    ctx.emit({ t: 'round', round: s.round, final });
    ctx.log('round', final ? `Final round! Round ${s.round} of ${s.totalRounds}.` : `Round ${s.round} of ${s.totalRounds} begins.`);
  }
  s.phase = { kind: 'roll' };
  ctx.emit({ t: 'turn', pid: s.players[s.turn].id });
}

function finish(ctx: Ctx) {
  const s = ctx.s;
  s.phase = { kind: 'over' };
  s.results = computeResults(s.players, s.awards, s.trends);
  ctx.emit({ t: 'over' });
  ctx.log('info', 'The season ends. The Grand Gala begins!');
}

function toPaint(s: GameState) {
  s.phase = { kind: 'paint' };
}

function doMove(ctx: Ctx, p: PlayerState, roll: number, delta: number) {
  const steps = roll + delta;
  p.inspiration -= Math.abs(delta);
  const from = p.position;
  ctx.emit({ t: 'move', pid: p.id, from, steps, delta });
  p.position = (from + steps) % RULES.boardSize;
  if (from + steps >= RULES.boardSize) {
    p.francs += RULES.hallSalary;
    ctx.emit({ t: 'salary', pid: p.id, francs: RULES.hallSalary });
    ctx.log('gain', `${p.name} passes the Society Hall: +${RULES.hallSalary} ₣.`, p.id);
  }
  ctx.emit({ t: 'land', pid: p.id, space: p.position });
  resolveSpace(ctx, p);
}

function resolveSpace(ctx: Ctx, p: PlayerState) {
  const s = ctx.s;
  const space = BOARD[p.position];
  const info = spaceInfo(space);
  switch (space.type) {
    case 'hall':
      addInspiration(ctx, p, RULES.hallInspiration);
      ctx.log('gain', `${p.name} is welcomed at the Society Hall: +${RULES.hallInspiration} ✦.`, p.id);
      toPaint(s);
      return;
    case 'pigment': {
      const pig = space.pigment!;
      addPigments(ctx, p, { [pig]: RULES.pigmentGain });
      ctx.log('gain', `${p.name} visits ${info.name}: +${RULES.pigmentGain} ${PIGMENT_INFO[pig].name.toLowerCase()}.`, p.id);
      toPaint(s);
      return;
    }
    case 'patron':
      addFrancs(ctx, p, RULES.patronGain);
      ctx.log('gain', `${p.name} receives a commission: +${RULES.patronGain} ₣.`, p.id);
      toPaint(s);
      return;
    case 'muse':
      addInspiration(ctx, p, RULES.museInspiration);
      if (p.hand.length < RULES.handLimit && (s.canvasRow.length > 0 || s.canvasDeck.length > 0)) {
        s.phase = { kind: 'muse' };
      } else {
        ctx.log('info', `${p.name} is inspired, but has no room for another sketch.`, p.id);
        toPaint(s);
      }
      return;
    case 'shop':
      if (p.francs >= RULES.shopPrice) s.phase = { kind: 'shop' };
      else {
        ctx.log('info', `${p.name} browses the Art Supplier with empty pockets.`, p.id);
        toPaint(s);
      }
      return;
    case 'gazette':
      s.phase = { kind: 'review' };
      return;
    case 'soiree': {
      if (s.eventDeck.length === 0) s.eventDeck = shuffle(ctx.r, EVENT_DECK.slice());
      const id = s.eventDeck.shift()!;
      const at = ctx.events.length;
      const text = applyEvent(ctx, p, id);
      ctx.events.splice(at, 0, { t: 'soiree', pid: p.id, event: id, text });
      ctx.log('event', `${p.name} at the Soirée — ${EVENTS[id].title}: ${text}`, p.id);
      toPaint(s);
      return;
    }
    case 'auction':
      startAuction(ctx, p);
      return;
  }
}

function startAuction(ctx: Ctx, p: PlayerState) {
  const s = ctx.s;
  const lot = s.lotDeck.shift();
  if (!lot) {
    addFrancs(ctx, p, 2);
    ctx.log('auction', `The Auction House vault is empty. ${p.name} sells a catalogue for 2 ₣.`, p.id);
    toPaint(s);
    return;
  }
  const deadline = ctx.now + RULES.auctionSeconds * 1000;
  s.phase = { kind: 'auction', lot, bids: {}, submitted: [], deadline };
  ctx.emit({ t: 'auction', pid: p.id, lot, deadline });
  ctx.log('auction', `${p.name} opens an auction: “${lot.title}” by ${lot.artist}. Place your secret bids!`, p.id);
  for (const pl of s.players) {
    if (pl.francs === 0) {
      s.phase.bids[pl.id] = 0;
      s.phase.submitted.push(pl.id);
    }
  }
  if (s.phase.submitted.length === s.players.length) resolveAuction(ctx);
}

function resolveAuction(ctx: Ctx) {
  const s = ctx.s;
  const ph = s.phase;
  if (ph.kind !== 'auction') return;
  const n = s.players.length;
  const bids: Record<string, number> = {};
  let best = 0;
  let winner: PlayerState | null = null;
  // Ties go to the bidder closest to the auction opener, starting with the opener.
  for (let i = 0; i < n; i++) {
    const pl = s.players[(s.turn + i) % n];
    const b = ph.bids[pl.id] ?? 0;
    bids[pl.id] = b;
    if (b > best) {
      best = b;
      winner = pl;
    }
  }
  const lot = ph.lot;
  if (winner) {
    winner.francs -= best;
    winner.auctionSpend += best;
    winner.collection.push(lot);
    ctx.log('auction', `Sold! ${winner.name} wins “${lot.title}” for ${best} ₣.`, winner.id);
  } else {
    s.lotDeck.push(lot);
    ctx.log('auction', `No bids. “${lot.title}” returns to the vault.`);
  }
  ctx.emit({ t: 'sold', lot, winner: winner?.id ?? null, price: best, bids });
  toPaint(s);
}

function applyEvent(ctx: Ctx, p: PlayerState, id: EventId): string {
  const s = ctx.s;
  const r = ctx.r;
  const mName = (m: MovementId) => MOVEMENT_INFO[m].name;
  switch (id) {
    case 'benefactor':
      addFrancs(ctx, p, 4);
      return 'You gain 4 ₣.';
    case 'spill': {
      let lost = 0;
      for (let i = 0; i < 2; i++) {
        const most = PIGMENTS.reduce((a, b) => (p.pigments[b] > p.pigments[a] ? b : a));
        if (p.pigments[most] <= 0) break;
        addPigments(ctx, p, { [most]: -1 });
        lost++;
      }
      return lost ? `You lose ${lost} pigment${lost > 1 ? 's' : ''}.` : 'Luckily your studio was empty.';
    }
    case 'buzz': {
      const options = MOVEMENTS.filter((m) => s.trends[m] < RULES.trendMax);
      const m = pick(r, options.length ? options : MOVEMENTS);
      changeTrend(ctx, m, 1, p.id);
      return `Everyone is talking about ${mName(m)}. Its trend rises.`;
    }
    case 'scandal': {
      const options = MOVEMENTS.filter((m) => s.trends[m] > RULES.trendMin);
      const m = pick(r, options.length ? options : MOVEMENTS);
      changeTrend(ctx, m, -1, p.id);
      return `A forgery scandal rocks ${mName(m)}. Its trend falls.`;
    }
    case 'artfair':
      for (const pl of s.players) addPigments(ctx, pl, { [pick(r, PIGMENTS)]: 1 });
      return 'Every artist picks up a random pigment.';
    case 'moonlit':
      addInspiration(ctx, p, 2);
      return 'You gain 2 ✦ inspiration.';
    case 'tax': {
      const taxed = s.players.filter((pl) => pl.francs >= 8);
      for (const pl of taxed) addFrancs(ctx, pl, -2);
      return taxed.length ? `${taxed.map((t) => t.name).join(', ')} pay${taxed.length === 1 ? 's' : ''} 2 ₣.` : 'Nobody is rich enough to tax.';
    }
    case 'attic': {
      if (p.hand.length < RULES.handLimit && s.canvasDeck.length > 0) {
        const c = s.canvasDeck.shift()!;
        p.hand.push(c);
        ctx.emit({ t: 'take', pid: p.id, art: c, from: 'deck' });
        return `You find a forgotten sketch: “${c.title}”.`;
      }
      addFrancs(ctx, p, 2);
      return 'You sell the old junk for 2 ₣.';
    }
    case 'dinner':
      for (const pl of s.players) addFrancs(ctx, pl, 2);
      return 'Every artist gains 2 ₣.';
    case 'fashion': {
      const hi = Math.max(...MOVEMENTS.map((m) => s.trends[m]));
      const down = pick(r, MOVEMENTS.filter((m) => s.trends[m] === hi));
      const rest = MOVEMENTS.filter((m) => m !== down);
      const lo = Math.min(...rest.map((m) => s.trends[m]));
      const up = pick(r, rest.filter((m) => s.trends[m] === lo));
      changeTrend(ctx, down, -1, p.id);
      changeTrend(ctx, up, 1, p.id);
      return `${mName(down)} is passé; ${mName(up)} is suddenly chic.`;
    }
    case 'shipment':
      addPigments(ctx, p, { red: 1, blue: 1, yellow: 1 });
      return 'You gain 1 pigment of each colour.';
    case 'envy': {
      const others = s.players.filter((pl) => pl.id !== p.id && pl.francs > 0);
      if (!others.length) return 'Nobody has a franc to pay you.';
      const top = Math.max(...others.map((o) => o.francs));
      const payer = pick(r, others.filter((o) => o.francs === top));
      const amount = Math.min(2, payer.francs);
      addFrancs(ctx, payer, -amount);
      addFrancs(ctx, p, amount);
      return `${payer.name} pays you ${amount} ₣.`;
    }
    case 'studiovisit': {
      if (!p.collection.length) {
        addInspiration(ctx, p, 1);
        return 'Your studio is bare, but the critic inspires you: +1 ✦.';
      }
      const counts = movementCounts(p.collection);
      const top = Math.max(...MOVEMENTS.map((m) => counts[m]));
      const m = pick(r, MOVEMENTS.filter((x) => counts[x] === top));
      changeTrend(ctx, m, 1, p.id);
      return `The critic raves about your ${mName(m)}. Its trend rises.`;
    }
  }
}

const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n);

export function applyAction(s: GameState, pid: string, a: Action, now: number): ActionResult {
  const fail = (error: string): ActionResult => ({ ok: false, error });
  if (!a || typeof a !== 'object' || typeof (a as Action).type !== 'string') return fail('Malformed action');
  const p = s.players.find((x) => x.id === pid);
  if (!p) return fail('You are not seated in this game');
  const ctx = new Ctx(s, now);
  const ph = s.phase;

  if (a.type === 'choosePatron') {
    if (ph.kind !== 'patrons') return fail('Patrons have already been chosen');
    if (p.patronChosen) return fail('You already chose a patron');
    if (!p.patronOffer.includes(a.patron)) return fail('That patron was not offered to you');
    p.patron = a.patron;
    p.patronChosen = true;
    ctx.emit({ t: 'patronChosen', pid });
    if (s.players.every((x) => x.patronChosen)) beginPlay(ctx);
    return { ok: true, events: ctx.events };
  }

  if (a.type === 'bid') {
    if (ph.kind !== 'auction') return fail('There is no auction right now');
    if (ph.submitted.includes(pid)) return fail('You already placed a bid');
    if (!isInt(a.amount) || a.amount < 0 || a.amount > p.francs) return fail('Invalid bid');
    ph.bids[pid] = a.amount;
    ph.submitted.push(pid);
    ctx.emit({ t: 'bid', pid });
    if (ph.submitted.length === s.players.length) resolveAuction(ctx);
    return { ok: true, events: ctx.events };
  }

  if (activePlayer(s).id !== pid) return fail('It is not your turn');

  switch (a.type) {
    case 'roll': {
      if (ph.kind !== 'roll') return fail('You cannot roll now');
      const value = 1 + Math.floor(ctx.r() * 6);
      s.lastRoll = value;
      ctx.emit({ t: 'roll', pid, value });
      if (p.inspiration > 0) s.phase = { kind: 'adjust', roll: value };
      else doMove(ctx, p, value, 0);
      return { ok: true, events: ctx.events };
    }
    case 'move': {
      if (ph.kind !== 'adjust') return fail('You cannot move now');
      if (!isInt(a.delta) || Math.abs(a.delta) > p.inspiration) return fail('Not enough inspiration');
      if (ph.roll + a.delta < 1) return fail('You must move at least one space');
      doMove(ctx, p, ph.roll, a.delta);
      return { ok: true, events: ctx.events };
    }
    case 'pick': {
      if (ph.kind !== 'muse') return fail('The Muse is not with you');
      if (p.hand.length >= RULES.handLimit) return fail('Your hand is full');
      let card: Artwork | undefined;
      let from: 'row' | 'deck';
      if (a.index === -1) {
        card = s.canvasDeck.shift();
        from = 'deck';
      } else {
        if (!isInt(a.index) || a.index < 0 || a.index >= s.canvasRow.length) return fail('No such sketch');
        card = s.canvasRow.splice(a.index, 1)[0];
        from = 'row';
        refillRow(s);
      }
      if (!card) return fail('The sketch deck is empty');
      p.hand.push(card);
      ctx.emit({ t: 'take', pid, art: card, from });
      ctx.log('gain', `${p.name} takes the sketch “${card.title}”.`, pid);
      toPaint(s);
      return { ok: true, events: ctx.events };
    }
    case 'buy': {
      if (ph.kind !== 'shop') return fail('You are not at the Art Supplier');
      const set = a.pigments;
      if (!set || typeof set !== 'object') return fail('Invalid purchase');
      const buy: PigmentSet = { red: 0, blue: 0, yellow: 0 };
      for (const k of PIGMENTS) {
        const n = set[k] ?? 0;
        if (!isInt(n) || n < 0) return fail('Invalid purchase');
        buy[k] = n;
      }
      const total = buy.red + buy.blue + buy.yellow;
      const cost = total * RULES.shopPrice;
      if (total > RULES.shopMax) return fail(`You can buy at most ${RULES.shopMax} pigments`);
      if (cost > p.francs) return fail('Not enough francs');
      if (total > 0) {
        p.francs -= cost;
        for (const k of PIGMENTS) p.pigments[k] += buy[k];
        ctx.emit({ t: 'buy', pid, pigments: buy, cost });
        ctx.log('gain', `${p.name} buys ${pigmentText(buy)} for ${cost} ₣.`, pid);
      }
      toPaint(s);
      return { ok: true, events: ctx.events };
    }
    case 'review': {
      if (ph.kind !== 'review') return fail('You are not at the Gazette');
      if (!MOVEMENTS.includes(a.praise)) return fail('Unknown movement');
      if (a.pan !== null && (!MOVEMENTS.includes(a.pan) || a.pan === a.praise)) return fail('Pan a different movement');
      ctx.emit({ t: 'review', pid, praise: a.praise, pan: a.pan });
      changeTrend(ctx, a.praise, 1, pid);
      if (a.pan) changeTrend(ctx, a.pan, -1, pid);
      ctx.log(
        'trend',
        `${p.name} writes in the Gazette: praises ${MOVEMENT_INFO[a.praise].name}${a.pan ? `, pans ${MOVEMENT_INFO[a.pan].name}` : ''}.`,
        pid,
      );
      toPaint(s);
      return { ok: true, events: ctx.events };
    }
    case 'skip': {
      if (ph.kind !== 'muse' && ph.kind !== 'shop' && ph.kind !== 'review') return fail('Nothing to skip');
      toPaint(s);
      return { ok: true, events: ctx.events };
    }
    case 'paint': {
      if (ph.kind !== 'roll' && ph.kind !== 'paint') return fail('You cannot paint right now');
      const idx = p.hand.findIndex((c) => c.id === a.artId);
      if (idx < 0) return fail('That sketch is not in your hand');
      const art = p.hand[idx];
      const pay = paymentFor(p.pigments, art.cost);
      if (!pay) return fail('Not enough pigment');
      const mixed = mixedCount(p.pigments, art.cost);
      for (const k of PIGMENTS) p.pigments[k] -= pay[k];
      p.hand.splice(idx, 1);
      art.paintedBy = pid;
      p.collection.push(art);
      ctx.emit({ t: 'paint', pid, art, paid: pay });
      ctx.log(
        'paint',
        `${p.name} paints “${art.title}” (${MOVEMENT_INFO[art.movement].name}, ${art.value})${mixed ? `, mixing ${mixed} colour${mixed > 1 ? 's' : ''}` : ''}.`,
        pid,
      );
      return { ok: true, events: ctx.events };
    }
    case 'endTurn': {
      if (ph.kind !== 'paint') return fail('You cannot end your turn yet');
      advanceTurn(ctx);
      return { ok: true, events: ctx.events };
    }
    default:
      return fail('Unknown action');
  }
}

/** Resolves an expired deadline (patron choice or auction). Returns null when nothing expired. */
export function applyTimeout(s: GameState, now: number): GameEvent[] | null {
  const ph = s.phase;
  if ((ph.kind !== 'patrons' && ph.kind !== 'auction') || now < ph.deadline) return null;
  const ctx = new Ctx(s, now);
  if (ph.kind === 'patrons') {
    for (const p of s.players) {
      if (!p.patronChosen) {
        p.patron = p.patronOffer[0];
        p.patronChosen = true;
        ctx.emit({ t: 'patronChosen', pid: p.id });
      }
    }
    beginPlay(ctx);
  } else {
    for (const p of s.players) {
      if (!ph.submitted.includes(p.id)) {
        ph.bids[p.id] = 0;
        ph.submitted.push(p.id);
      }
    }
    resolveAuction(ctx);
  }
  return ctx.events;
}

/** Who the game is waiting on right now. */
export function waitingOn(s: { phase: GameState['phase']; players: PlayerState[]; turn: number }): string[] {
  const ph = s.phase;
  if (ph.kind === 'over') return [];
  if (ph.kind === 'patrons') return s.players.filter((p) => !p.patronChosen).map((p) => p.id);
  if (ph.kind === 'auction') return s.players.filter((p) => !ph.submitted.includes(p.id)).map((p) => p.id);
  return [s.players[s.turn].id];
}

export function viewFor(s: GameState, viewer: string | null): GameView {
  const over = s.phase.kind === 'over';
  const players = s.players.map((p) =>
    over || p.id === viewer ? p : { ...p, patron: null, patronOffer: [] },
  );
  let phase = s.phase;
  if (phase.kind === 'auction') {
    const bids: Record<string, number> = {};
    if (viewer && viewer in phase.bids) bids[viewer] = phase.bids[viewer];
    phase = { ...phase, bids, submitted: [...phase.submitted] };
  }
  return {
    seed: s.seed,
    round: s.round,
    totalRounds: s.totalRounds,
    turn: s.turn,
    players,
    trends: s.trends,
    canvasRow: s.canvasRow,
    awards: s.awards,
    phase,
    lastRoll: s.lastRoll,
    log: s.log,
    logSeq: s.logSeq,
    results: s.results,
    canvasDeckCount: s.canvasDeck.length,
    lotDeckCount: s.lotDeck.length,
    you: viewer,
  };
}

export function spaceName(index: number): string {
  return spaceInfo(BOARD[index]).name;
}
