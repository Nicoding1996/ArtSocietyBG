# Art Society

A 3D online board game of painters, patrons and prestige for 2–6 players. Everyone plays in their own browser on their own PC. You travel a gilded boulevard, gather pigments, paint procedurally generated artworks, bid on masterpieces in secret auctions and sway the critics. At the end, the **Grand Gala** reveals the awards and everyone's secret patron, then crowns the laureate on a podium.

Every painting is generated in the browser (Impressionist water lilies, swirling starry nights, Cubist still lifes, Ukiyo-e waves, Mondrian/Kandinsky/Rothko abstractions), so the game needs no image assets. Music and sound effects are synthesised too.

## Quick start

Requires [Node.js](https://nodejs.org) 20.19 or newer.

```bash
npm install
npm start
```

Open <http://localhost:3000>, enter a name and click **Create a room**. Add bots or invite friends with the link shown in the lobby, then click **Start the season**.

## Playing with friends on other PCs

The PC that runs `npm start` is the host. Everyone else only needs a browser.

**Same Wi-Fi or LAN.** The server prints addresses like `http://192.168.1.20:3000` under "On your network". Friends open that address, or the invite link from the lobby with your PC's address in place of `localhost`. The first time, Windows asks whether Node.js may accept connections. Allow it on private networks.

**Over the internet.** Pick one of these:

- **Cloudflare quick tunnel** (free, no account): install [cloudflared](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/), then run `cloudflared tunnel --url http://localhost:3000` next to `npm start` and share the `https://….trycloudflare.com` link it prints.
- **ngrok**: `ngrok http 3000` and share the forwarding URL.
- **Host it** on any Node host with WebSocket support (Render, Railway, Fly.io, a VPS). Use the build command `npm install && npm run build` and the start command `npm run serve`. The server reads the `PORT` environment variable.

Seats survive page reloads and short disconnects. If someone drops out mid-game, an autopilot plays their turns until they come back. A player who stays idle for 90 seconds also gets the autopilot until they click again.

## How to play

On your turn:

1. **Roll** the die. Spend ✦ inspiration to move one space more or less per ✦.
2. **Move** clockwise and resolve the space you land on.
3. **Paint** any sketch in your hand whose pigments you have. If you are short a colour, any 2 spare pigments mix into 1 of the missing colour.
4. **End** your turn.

| Space | Effect |
| --- | --- |
| Society Hall | +2 ₣ each time you pass; landing on it also gives +1 ✦ |
| Crimson / Ultramarine / Saffron markets | +3 pigment of that colour |
| The Muse | Take one of three face-up sketches (or draw blind), +1 ✦ |
| Art Supplier | Buy up to 4 pigments for 1 ₣ each |
| Patron's Salon | +3 ₣ commission |
| Auction House | A masterpiece goes up for auction. Everyone places one sealed bid and the highest bid wins |
| The Gazette | Praise one movement (trend +1) and pan another (trend −1) |
| Soirée | A random event: gifts, gossip, taxes, scandals |

**Scoring at the Grand Gala**

- Each artwork scores its prestige plus the final **trend** (0–3) of its movement.
- Three **Society Awards** are drawn each game, for example *Master of Cubism* or *The Prolific Brush*. Each is worth +5 to its leader, and tied leaders all score.
- Your **secret patron** pays a bonus, such as +3 per Ukiyo-e work or +5 per masterpiece. You pick one of two patrons at the start, and nobody else sees it until the Gala.
- You get +1 prestige for every 3 ₣ left over.

During play, the prestige shown next to each player counts only artworks at the current trends. Awards and patrons stay hidden until the Gala reveal, so leads can flip at the end.

**Controls:** drag to orbit the board, scroll to zoom, hover a space to read it, click a painting to see it full size. The top bar has toggles for camera follow, sound and music.

## Development

```bash
npm run dev        # Vite on http://localhost:5173 (hot reload) + game server on :3000
npm test           # rules-engine tests, including 125 full bot games across 2–6 players
npm run sim        # balance report: average scores, patron win rates, game length
npm run typecheck
```

- `http://localhost:5173/?gallery` shows 25 sample paintings, which helps when tuning the art generators. `?gallery=7` uses a different seed.
- `ART_SOCIETY_FAST=1 npm run serve` makes bots act almost instantly, which speeds up testing.
- All tunable numbers (starting resources, gains, hand limit, trend range, award points, timers) live in `RULES` in `src/shared/content.ts`. Run `npm run sim` after changing them.

### Project layout

```
src/shared/   rules engine, cards, scoring, bot AI (used by both the server and the browser)
src/server/   HTTP + WebSocket server, rooms, reconnects, autopilot and timers
src/client/
  art/        procedural painting generators, one file per art movement
  three/      the 3D board, pawns, die, galleries, trend lanterns, podium, effects
  ui/         lobby, HUD, action prompts, overlays and the Grand Gala ceremony
  game.ts     turns server events into animations, then shows the new state
scripts/      balance simulator
tests/        engine tests
```

The server is authoritative. Clients send intentions such as "roll" or "bid 3". The server validates them, updates the state, and sends every player a view with other players' secrets removed: patrons stay hidden until the end and bids stay hidden until the hammer falls.

## A note on the name

*Art Society* is also the name of a published board game (Mighty Boards, 2023). This project shares only the name: its rules and art are original. Using the name for private games with friends is fine, but pick a new title before you publish or sell the game.
