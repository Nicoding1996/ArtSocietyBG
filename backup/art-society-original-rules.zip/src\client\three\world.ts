import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RULES } from '../../shared/content';
import type { Artwork, HatId, MovementId } from '../../shared/types';
import { Board, gold, marble } from './board';
import { Gallery } from './gallery';
import { Die, Pawn } from './pieces';
import { Confetti, Particles, Tweens, ease } from './fx';
import { L, pawnSpot, polar, spaceAngle } from './layout';

const VignetteShader = {
  uniforms: { tDiffuse: { value: null }, strength: { value: 0.42 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float strength; varying vec2 vUv;
    void main(){ vec4 c = texture2D(tDiffuse, vUv); vec2 d = (vUv - 0.5) * vec2(1.0, 0.85);
    float v = smoothstep(0.78, 0.18, length(d)); c.rgb *= mix(1.0 - strength, 1.0, v); gl_FragColor = c; }`,
};

function rankTexture(n: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#e2c27a';
  ctx.font = '700 104px "Cormorant Garamond", Georgia, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(n), 64, 70);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export interface PawnInfo {
  id: string;
  color: string;
  hat: HatId;
  position: number;
}

interface Label {
  el: HTMLElement;
  pos: THREE.Vector3;
  born: number;
  life: number;
  rise: number;
}

export class World {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(38, 1, 0.1, 400);
  readonly controls: OrbitControls;
  readonly tw = new Tweens();
  readonly board = new Board();
  readonly gallery = new Gallery();
  readonly die = new Die();
  private particles: Particles;
  private confetti: Confetti;
  private composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private pawns = new Map<string, Pawn>();
  private pawnInfo = new Map<string, PawnInfo>();
  private moving = new Set<string>();
  private labels: Label[] = [];
  private last = performance.now();
  private lastUser = 0;
  private followPid: string | null = null;
  private podiumGroup: THREE.Group | null = null;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private hoverAt = 0;
  private downAt: { x: number; y: number } | null = null;
  follow = true;
  demo = true;
  ready: Promise<void>;
  onHover: ((space: number | null, x: number, y: number) => void) | null = null;
  onPickArt: ((art: Artwork) => void) | null = null;

  constructor(
    private canvas: HTMLCanvasElement,
    private labelLayer: HTMLElement,
  ) {
    const r = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFShadowMap;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.05;
    this.renderer = r;

    this.camera.position.set(0, 21, 25);
    this.controls = new OrbitControls(this.camera, canvas);
    const c = this.controls;
    c.target.set(0, 0.8, 0);
    c.enableDamping = true;
    c.dampingFactor = 0.08;
    c.minDistance = 8;
    c.maxDistance = 46;
    c.minPolarAngle = 0.2;
    c.maxPolarAngle = 1.3;
    c.screenSpacePanning = false;
    c.panSpeed = 0.6;
    c.rotateSpeed = 0.7;
    c.autoRotateSpeed = 0.35;
    c.addEventListener('start', () => (this.lastUser = performance.now() + 1e9));
    c.addEventListener('end', () => (this.lastUser = performance.now()));

    const size = new THREE.Vector2(window.innerWidth, window.innerHeight);
    const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(r, rt);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(size, 0.28, 0.55, 0.93);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new ShaderPass(VignetteShader));
    this.composer.addPass(new OutputPass());

    this.particles = new Particles(this.scene);
    this.confetti = new Confetti(this.scene);
    this.setupScene();
    this.resize();
    window.addEventListener('resize', () => this.resize());
    canvas.addEventListener('pointermove', (e) => this.onPointerMove(e));
    canvas.addEventListener('pointerdown', (e) => (this.downAt = { x: e.clientX, y: e.clientY }));
    canvas.addEventListener('pointerup', (e) => this.onPointerUp(e));
    canvas.addEventListener('pointerleave', () => this.onHover?.(null, 0, 0));
    this.ready = this.build();
    requestAnimationFrame(this.frame);
  }

  private setupScene() {
    const s = this.scene;
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    s.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    s.environmentIntensity = 0.5;
    s.fog = new THREE.Fog('#0c0a0e', 46, 120);

    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(200, 32, 16),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: { top: { value: new THREE.Color('#2a2130') }, bottom: { value: new THREE.Color('#09080b') } },
        vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'uniform vec3 top; uniform vec3 bottom; varying vec3 vP; void main(){ float t = smoothstep(-0.15, 0.7, vP.y); gl_FragColor = vec4(mix(bottom, top, t), 1.0); }',
      }),
    );
    s.add(sky);

    s.add(new THREE.HemisphereLight('#ffeedd', '#2a1c12', 0.55));
    const key = new THREE.DirectionalLight('#ffe2b8', 2.7);
    key.position.set(14, 26, 12);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    const sc = key.shadow.camera;
    sc.left = sc.bottom = -17;
    sc.right = sc.top = 17;
    sc.near = 5;
    sc.far = 70;
    key.shadow.bias = -0.0004;
    key.shadow.normalBias = 0.025;
    key.shadow.radius = 3;
    s.add(key);
    const fill = new THREE.DirectionalLight('#a8b8ff', 0.6);
    fill.position.set(-18, 10, -12);
    s.add(fill);
    const pool = new THREE.SpotLight('#fff0d8', 55, 40, 0.5, 0.8, 1.5);
    pool.position.set(0, 18, 2);
    pool.target.position.set(0, 0, 0);
    s.add(pool, pool.target);

    s.add(this.board.group, this.gallery.group, this.die.mesh);
  }

  private async build() {
    try {
      await Promise.race([
        Promise.all([document.fonts.load('700 64px "Cormorant Garamond"'), document.fonts.load('600 34px Inter')]),
        new Promise((r) => setTimeout(r, 2500)),
      ]);
    } catch {
      /* fall back to system fonts */
    }
    await this.board.build();
    await this.gallery.buildColumns();
    this.gallery.setTrends({ impressionism: 2, postimpressionism: 3, cubism: 1, ukiyoe: 2, abstract: 1 });
  }

  resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.composer.setSize(w, h);
    this.bloom.resolution.set(w, h);
    this.camera.aspect = w / h;
    // Keep the whole board in view on narrow screens.
    this.camera.fov = w / h < 1.2 ? 50 : 38;
    this.camera.updateProjectionMatrix();
  }

  // ---------- frame loop ----------

  private frame = (now: number) => {
    requestAnimationFrame(this.frame);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.tw.update(now);
    const c = this.controls;
    c.autoRotate = this.demo;
    if (this.follow && this.followPid && !this.demo && now - this.lastUser > 2500) {
      const pawn = this.pawns.get(this.followPid);
      if (pawn) {
        const want = pawn.group.position.clone().multiplyScalar(0.55).setY(0.8);
        const delta = want.sub(c.target).multiplyScalar(Math.min(1, dt * 2.2));
        c.target.add(delta);
        this.camera.position.add(delta);
      }
    }
    if (c.target.length() > 9) c.target.setLength(9);
    c.update();
    this.board.update(dt);
    this.gallery.update(dt);
    this.die.update(dt);
    for (const p of this.pawns.values()) p.update(dt);
    this.particles.update(dt);
    this.confetti.update(dt);
    for (const c of this.crowns) {
      c.rotation.y += dt * 1.2;
      c.position.y += Math.sin(now / 400) * 0.002;
    }
    this.updateLabels(now);
    this.composer.render();
  };

  // ---------- pointer ----------

  private setPointer(e: PointerEvent) {
    const rect = this.canvas.getBoundingClientRect();
    this.pointer.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
  }

  private onPointerMove(e: PointerEvent) {
    const now = performance.now();
    if (now - this.hoverAt < 40 || !this.onHover || e.buttons) return;
    this.hoverAt = now;
    this.setPointer(e);
    const hit = this.raycaster.intersectObjects(this.board.tiles, false)[0];
    this.onHover(hit ? (hit.object.userData.space as number) : null, e.clientX, e.clientY);
  }

  private onPointerUp(e: PointerEvent) {
    const d = this.downAt;
    this.downAt = null;
    if (!d || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 5 || !this.onPickArt) return;
    this.setPointer(e);
    const hit = this.raycaster.intersectObject(this.gallery.group, true).find((h) => {
      let o: THREE.Object3D | null = h.object;
      while (o && !o.userData.art) o = o.parent;
      return !!o;
    });
    if (!hit) return;
    let o: THREE.Object3D | null = hit.object;
    while (o && !o.userData.art) o = o.parent;
    if (o) this.onPickArt(o.userData.art as Artwork);
  }

  // ---------- camera ----------

  focus(point: THREE.Vector3, distance?: number, ms = 1100): Promise<void> {
    const c = this.controls;
    const fromT = c.target.clone();
    const fromP = this.camera.position.clone();
    const dir = fromP.clone().sub(fromT);
    const dist = distance ?? dir.length();
    dir.setLength(dist);
    const toP = point.clone().add(dir);
    return this.tw.add(ms, (t) => {
      c.target.lerpVectors(fromT, point, t);
      this.camera.position.lerpVectors(fromP, toP, t);
    });
  }

  /** Swings the camera to look at `point` from a given azimuth, elevation and distance. */
  orbitTo(point: THREE.Vector3, azimuth: number, polarAngle: number, distance: number, ms = 1600): Promise<void> {
    const c = this.controls;
    const fromT = c.target.clone();
    const off = this.camera.position.clone().sub(fromT);
    const s0 = new THREE.Spherical().setFromVector3(off);
    let dTheta = azimuth - s0.theta;
    while (dTheta > Math.PI) dTheta -= Math.PI * 2;
    while (dTheta < -Math.PI) dTheta += Math.PI * 2;
    const sph = new THREE.Spherical();
    return this.tw.add(ms, (t) => {
      c.target.lerpVectors(fromT, point, t);
      sph.set(s0.radius + (distance - s0.radius) * t, s0.phi + (polarAngle - s0.phi) * t, s0.theta + dTheta * t);
      this.camera.position.copy(c.target).add(new THREE.Vector3().setFromSpherical(sph));
    });
  }

  overview(ms = 1300) {
    return this.orbitTo(new THREE.Vector3(0, 0.8, 0), new THREE.Spherical().setFromVector3(this.camera.position.clone().sub(this.controls.target)).theta, 0.85, 31, ms);
  }

  followPlayer(pid: string | null) {
    this.followPid = pid;
  }

  // ---------- pawns ----------

  syncPawns(players: PawnInfo[], activeId: string | null) {
    for (const [id, pawn] of this.pawns) {
      if (!players.some((p) => p.id === id)) {
        this.scene.remove(pawn.group);
        this.pawns.delete(id);
        this.pawnInfo.delete(id);
      }
    }
    for (const p of players) {
      const prev = this.pawnInfo.get(p.id);
      if (!this.pawns.has(p.id) || prev?.color !== p.color || prev?.hat !== p.hat) {
        const old = this.pawns.get(p.id);
        if (old) this.scene.remove(old.group);
        const pawn = new Pawn(p.color, p.hat);
        this.pawns.set(p.id, pawn);
        this.scene.add(pawn.group);
      }
      this.pawnInfo.set(p.id, { ...p });
      this.pawns.get(p.id)!.active = p.id === activeId;
    }
    this.layoutPawns();
  }

  private layoutPawns(skip?: string) {
    const bySpace = new Map<number, string[]>();
    for (const p of this.pawnInfo.values()) {
      const list = bySpace.get(p.position) ?? [];
      list.push(p.id);
      bySpace.set(p.position, list);
    }
    for (const [space, ids] of bySpace) {
      ids.forEach((id, k) => {
        if (id === skip || this.moving.has(id)) return;
        const pawn = this.pawns.get(id)!;
        const spot = pawnSpot(space, k, ids.length);
        if (pawn.group.position.distanceTo(spot) > 0.01) {
          const from = pawn.group.position.clone();
          // Small shuffles on a tile glide; anything bigger (a new game, a reconnect) snaps.
          if (from.lengthSq() < 0.01 || from.distanceTo(spot) > 3) pawn.group.position.copy(spot);
          else this.tw.add(300, (t) => pawn.group.position.lerpVectors(from, spot, t));
        }
        pawn.group.rotation.y = -spaceAngle(space) - Math.PI / 2;
      });
    }
  }

  pawnPosition(pid: string): THREE.Vector3 | null {
    return this.pawns.get(pid)?.group.position.clone() ?? null;
  }

  async movePawn(pid: string, from: number, steps: number, onHop: (space: number) => void) {
    const pawn = this.pawns.get(pid);
    const info = this.pawnInfo.get(pid);
    if (!pawn || !info) return;
    this.moving.add(pid);
    info.position = from;
    this.layoutPawns(pid);
    for (let s = 1; s <= steps; s++) {
      const space = (from + s) % RULES.boardSize;
      const last = s === steps;
      let spot = pawnSpot(space, 0, 1);
      if (last) {
        const others = [...this.pawnInfo.values()].filter((p) => p.position === space && p.id !== pid).map((p) => p.id);
        spot = pawnSpot(space, others.length, others.length + 1);
      }
      pawn.group.rotation.y = -spaceAngle(space) - Math.PI / 2;
      await pawn.hop(this.tw, spot, last ? 320 : 250, last ? 1.1 : 0.75);
      onHop(space);
    }
    info.position = (from + steps) % RULES.boardSize;
    this.moving.delete(pid);
    this.layoutPawns();
  }

  setActive(pid: string | null) {
    for (const [id, pawn] of this.pawns) pawn.active = id === pid;
  }

  async rollDie(pid: string, value: number, onBounce: () => void) {
    const info = this.pawnInfo.get(pid);
    const a = spaceAngle(info?.position ?? 0) + 0.16;
    await this.die.roll(this.tw, polar(8.45, a, 0), value, onBounce);
  }

  // ---------- galleries & trends ----------

  syncGallery(players: { id: string; color: string; collection: Artwork[] }[]) {
    this.gallery.setOwners(players.map((p) => ({ id: p.id, color: p.color })));
    const created = this.gallery.sync(players);
    for (const p of players) {
      for (const art of p.collection) {
        const obj = this.gallery.objectFor(art.id);
        if (obj) obj.userData.art = art;
      }
    }
    return created;
  }

  /** Adds a freshly painted artwork with a little ceremony. */
  async revealArtwork(players: { id: string; color: string; collection: Artwork[] }[], art: Artwork, color: string) {
    this.syncGallery(players);
    const obj = this.gallery.objectFor(art.id);
    if (!obj) return;
    const pos = obj.position.clone();
    const zoom = this.follow && !this.demo;
    const back = { target: this.controls.target.clone(), dist: this.camera.position.distanceTo(this.controls.target) };
    if (zoom) void this.focus(pos.clone().setY(1), 19, 900);
    obj.scale.setScalar(0.001);
    await this.tw.wait(350);
    this.particles.burst(pos.clone().setY(pos.y + 1.2), '#ffe7a8', 70, 1.7);
    this.particles.burst(pos.clone().setY(pos.y + 1.2), color, 30, 1.2);
    await this.tw.add(700, (t) => obj.scale.setScalar(Math.max(0.001, t)), ease.back);
    // Admire it for a moment, then step back to where the camera was.
    if (zoom) {
      await this.tw.wait(700);
      void this.focus(back.target, Math.max(24, back.dist), 1000);
    }
  }

  setTrends(trends: Record<MovementId, number>, animate = false) {
    this.gallery.setTrends(trends, animate);
  }

  showLot(art: Artwork) {
    if (this.follow) void this.focus(new THREE.Vector3(0, 2.2, 0), 19, 1000);
    return this.gallery.showLot(this.tw, art);
  }

  async sellLot(winner: string | null) {
    let to: THREE.Vector3 | null = null;
    if (winner) {
      const pawn = this.pawns.get(winner);
      to = pawn ? pawn.group.position.clone().multiplyScalar(0.62).setY(1) : null;
    }
    await this.gallery.hideLot(this.tw, to);
  }

  hideLotNow() {
    this.gallery.hideLotNow();
  }

  pulseSpace(space: number, color?: string) {
    this.board.pulse(space, color);
  }

  sparkleAt(pid: string, color: string) {
    const p = this.pawnPosition(pid);
    if (p) this.particles.burst(p.setY(p.y + 1.2), color, 26, 1, 0.18, 1);
  }

  // ---------- floating labels ----------

  float(pid: string, html: string, cls = '') {
    const p = this.pawnPosition(pid);
    if (!p) return;
    this.floatAt(p.setY(p.y + 1.9), html, cls);
  }

  floatAt(pos: THREE.Vector3, html: string, cls = '', life = 1700) {
    const el = document.createElement('div');
    el.className = `float-label ${cls}`;
    el.innerHTML = html;
    this.labelLayer.appendChild(el);
    // Stack labels that start at the same moment.
    const stacked = this.labels.filter((l) => performance.now() - l.born < 250 && l.pos.distanceTo(pos) < 0.5).length;
    this.labels.push({ el, pos: pos.clone(), born: performance.now() + stacked * 180, life, rise: 46 });
  }

  screenOf(pos: THREE.Vector3): { x: number; y: number; visible: boolean } {
    const v = pos.clone().project(this.camera);
    return { x: (v.x * 0.5 + 0.5) * window.innerWidth, y: (-v.y * 0.5 + 0.5) * window.innerHeight, visible: v.z < 1 };
  }

  private updateLabels(now: number) {
    for (const l of this.labels) {
      const t = (now - l.born) / l.life;
      const s = this.screenOf(l.pos);
      if (t < 0) {
        l.el.style.opacity = '0';
        continue;
      }
      l.el.style.transform = `translate(-50%, -100%) translate(${s.x}px, ${s.y - t * l.rise}px) scale(${0.8 + Math.min(1, t * 6) * 0.2})`;
      l.el.style.opacity = s.visible ? String(Math.min(1, t * 8) * (1 - Math.pow(Math.max(0, t), 3))) : '0';
    }
    for (const l of this.labels.filter((x) => now - x.born > x.life)) l.el.remove();
    this.labels = this.labels.filter((x) => now - x.born <= x.life);
  }

  // ---------- the Grand Gala ----------

  async podium(ranked: string[]) {
    this.followPid = null;
    this.hideLotNow();
    this.clearPodium();
    const g = new THREE.Group();
    const steps: [number, number, number][] = [
      [0, 1.25, 0],
      [-1.35, 0.85, 0.25],
      [1.35, 0.55, 0.25],
    ];
    const mats = [gold, new THREE.MeshStandardMaterial({ color: '#cfd4dc', metalness: 1, roughness: 0.3 }), new THREE.MeshStandardMaterial({ color: '#b87333', metalness: 1, roughness: 0.35 })];
    steps.forEach(([x, h, z], i) => {
      const block = new THREE.Mesh(new THREE.BoxGeometry(1.25, h, 1.25), marble());
      block.position.set(x, h / 2, z);
      block.castShadow = true;
      const top = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.08, 1.3), mats[i]);
      top.position.set(x, h + 0.04, z);
      const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), (() => {
        const t = rankTexture(i + 1);
        return new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: '#e2c27a', emissiveIntensity: 0.55, transparent: true, metalness: 0.5, roughness: 0.4 });
      })());
      plate.position.set(x, Math.min(h * 0.55, h - 0.36), z + 0.63);
      g.add(block, top, plate);
    });
    g.position.set(0, L.plinthTop, 0.6);
    g.scale.setScalar(0.001);
    this.scene.add(g);
    this.podiumGroup = g;
    this.gallery.setColumnsVisible(false);
    await this.tw.add(900, (t) => g.scale.setScalar(Math.max(0.001, t)), ease.back);
    const front = new THREE.Spherical().setFromVector3(new THREE.Vector3(0, 0, 1)).theta;
    void this.orbitTo(new THREE.Vector3(0, 2.4, 0), front, 1.05, 15, 1800);
    for (let i = Math.min(2, ranked.length - 1); i >= 0; i--) {
      const pawn = this.pawns.get(ranked[i]);
      const info = this.pawnInfo.get(ranked[i]);
      if (!pawn || !info) continue;
      const [x, h, z] = steps[i];
      const to = new THREE.Vector3(x, L.plinthTop + h + 0.08, 0.6 + z);
      this.moving.add(ranked[i]);
      const from = pawn.group.position.clone();
      pawn.group.rotation.y = 0;
      await this.tw.add(1100, (t) => {
        pawn.group.position.lerpVectors(from, to, t);
        pawn.group.position.y = from.y + (to.y - from.y) * t + Math.sin(t * Math.PI) * 4;
      });
      this.particles.burst(to.clone().setY(to.y + 0.6), i === 0 ? '#ffd76a' : '#ffffff', 40, 1.3);
    }
  }

  celebrate(pid: string, colors: string[]) {
    const p = this.pawnPosition(pid) ?? new THREE.Vector3(0, 2, 0);
    this.confetti.start(p.clone().setY(p.y + 1), colors);
    this.particles.burst(p.clone().setY(p.y + 0.8), '#ffd76a', 120, 2.4, 0.3, 2);
    // A floating golden crown for the laureate.
    const crown = new THREE.Group();
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.22, 0.14, 32, 1, true), gold);
    crown.add(band);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 8), gold);
      spike.position.set(Math.cos(a) * 0.23, 0.15, Math.sin(a) * 0.23);
      const jewel = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), new THREE.MeshStandardMaterial({ color: i % 2 ? '#d1243c' : '#2b6bd8', emissive: i % 2 ? '#d1243c' : '#2b6bd8', emissiveIntensity: 0.6 }));
      jewel.position.set(Math.cos(a) * 0.23, 0.25, Math.sin(a) * 0.23);
      crown.add(spike, jewel);
    }
    crown.position.copy(p).setY(p.y + 1.85);
    this.scene.add(crown);
    this.crowns.push(crown);
  }

  private crowns: THREE.Group[] = [];

  clearPodium() {
    for (const c of this.crowns) this.scene.remove(c);
    this.crowns = [];
    if (this.podiumGroup) this.scene.remove(this.podiumGroup);
    this.podiumGroup = null;
    this.confetti.stop();
    this.gallery.setColumnsVisible(true);
    for (const id of [...this.moving]) this.moving.delete(id);
    this.layoutPawns();
  }

  /** Lobby/home backdrop: sample paintings in the salon and a slow orbit. */
  setDemo(on: boolean, samples?: { id: string; color: string; collection: Artwork[] }[]) {
    this.demo = on;
    if (on) {
      this.followPid = null;
      this.clearPodium();
      this.hideLotNow();
      if (samples) this.syncGallery(samples);
    }
  }
}
