import type {
  Artwork,
  AwardId,
  AwardResult,
  GameResults,
  MovementId,
  PatronId,
  PlayerResult,
  PlayerState,
} from './types';
import { MOVEMENTS } from './types';
import { RULES } from './content';

type Trends = Record<MovementId, number>;

export function artValue(art: Artwork, trends: Trends): number {
  return art.value + trends[art.movement];
}

/** Prestige everyone can see during play: artworks at current trends. */
export function visiblePrestige(p: PlayerState, trends: Trends): number {
  return p.collection.reduce((sum, a) => sum + artValue(a, trends), 0);
}

export function movementCounts(collection: Artwork[]): Record<MovementId, number> {
  const c = Object.fromEntries(MOVEMENTS.map((m) => [m, 0])) as Record<MovementId, number>;
  for (const a of collection) c[a.movement]++;
  return c;
}

export function distinctMovements(collection: Artwork[]): number {
  return new Set(collection.map((a) => a.movement)).size;
}

export function patronPoints(patron: PatronId | null, p: PlayerState, trends: Trends): number {
  if (!patron) return 0;
  const col = p.collection;
  const counts = movementCounts(col);
  switch (patron) {
    case 'lumiere':
      return 3 * counts.impressionism;
    case 'vincenzo':
      return 3 * counts.postimpressionism;
    case 'vogel':
      return 3 * counts.cubism;
    case 'sakura':
      return 3 * counts.ukiyoe;
    case 'kandin':
      return 3 * counts.abstract;
    case 'curator':
      return 2 * distinctMovements(col);
    case 'baron':
      return p.francs;
    case 'marteau':
      return 5 * col.filter((a) => a.kind === 'masterpiece').length;
    case 'plenty':
      return 2 * col.filter((a) => a.kind === 'canvas').length;
    case 'aurelius':
      return 3 * col.filter((a) => a.value >= 5).length;
    case 'vogue':
      return 3 * col.filter((a) => trends[a.movement] >= 2).length;
    case 'pur':
      return 4 * Object.values(counts).reduce((sum, n) => sum + Math.floor(n / 2), 0);
  }
}

export function awardMetric(id: AwardId, p: PlayerState, trends: Trends): number {
  const col = p.collection;
  if (id.startsWith('master:')) {
    const m = id.slice(7) as MovementId;
    return col.filter((a) => a.movement === m).length;
  }
  switch (id) {
    case 'prolific':
      return col.length;
    case 'connoisseur':
      return col.filter((a) => a.kind === 'masterpiece').length;
    case 'eclectic':
      return distinctMovements(col);
    case 'tycoon':
      return p.francs;
    case 'visionary':
      return Math.max(0, ...col.map((a) => artValue(a, trends)));
    case 'benefactor':
      return p.auctionSpend;
    default:
      return 0;
  }
}

export function evaluateAwards(awards: AwardId[], players: PlayerState[], trends: Trends): AwardResult[] {
  return awards.map((id) => {
    const values = players.map((p) => awardMetric(id, p, trends));
    const best = Math.max(0, ...values);
    const winners = best > 0 ? players.filter((_, i) => values[i] === best).map((p) => p.id) : [];
    return { id, winners, value: best };
  });
}

export function computeResults(players: PlayerState[], awards: AwardId[], trends: Trends): GameResults {
  const awardResults = evaluateAwards(awards, players, trends);
  const results: PlayerResult[] = players.map((p) => {
    const art = p.collection.map((a) => ({
      id: a.id,
      title: a.title,
      movement: a.movement,
      kind: a.kind,
      base: a.value,
      trend: trends[a.movement],
    }));
    const artPoints = art.reduce((s, a) => s + a.base + a.trend, 0);
    const won = awardResults.filter((a) => a.winners.includes(p.id)).map((a) => a.id);
    const awardPoints = won.length * RULES.awardPoints;
    const pp = patronPoints(p.patron, p, trends);
    const francPoints = Math.floor(p.francs / RULES.francsPerPoint);
    return {
      pid: p.id,
      art,
      artPoints,
      awards: won,
      awardPoints,
      patron: p.patron,
      patronPoints: pp,
      francs: p.francs,
      francPoints,
      total: artPoints + awardPoints + pp + francPoints,
      rank: 0,
    };
  });

  // Ties on prestige are broken by number of artworks, then francs. Full ties share the rank.
  const key = (r: PlayerResult) => [r.total, r.art.length, r.francs];
  const sorted = [...results].sort((a, b) => {
    const ka = key(a);
    const kb = key(b);
    for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return kb[i] - ka[i];
    return 0;
  });
  sorted.forEach((r, i) => {
    const prev = sorted[i - 1];
    r.rank = prev && key(prev).every((v, k) => v === key(r)[k]) ? prev.rank : i + 1;
  });

  return {
    players: sorted,
    awards: awardResults,
    winners: sorted.filter((r) => r.rank === 1).map((r) => r.pid),
    trends: { ...trends },
  };
}
