import { BOT_NAMES, PLAYER_COLORS, buildCanvasDeck, buildLotDeck } from '../shared/content';
import { makeRng } from '../shared/rng';
import { HATS, type RoomView, type ServerMessage } from '../shared/types';
import { Audio } from './audio';
import { GameScreen } from './game';
import { Net } from './net';
import { World } from './three/world';
import { ChatPanel } from './ui/chat';
import { el } from './ui/dom';
import { renderHome } from './ui/home';
import { LobbyView } from './ui/lobby';
import { closeModal, initOverlays, showHelp, toast } from './ui/overlays';

const NAME_KEY = 'artsociety.name';

export class App {
  private world: World;
  private net = new Net();
  private audio = new Audio();
  private chat = new ChatPanel(true);
  private screenEl = el('div', 'screen');
  private status = el('div', 'net-status');
  private lobby: LobbyView | null = null;
  private game: GameScreen | null = null;
  private room: RoomView | null = null;
  private me: string | null = null;
  private screen: 'home' | 'lobby' | 'game' | null = null;

  constructor(ui: HTMLElement) {
    const labels = el('div', 'labels');
    ui.append(labels, this.screenEl, this.status);
    initOverlays(ui);
    this.world = new World(document.getElementById('scene') as HTMLCanvasElement, labels);
    this.chat.onSend = (text) => this.net.send({ t: 'chat', text });
    this.chat.onReact = (emoji) => this.net.send({ t: 'react', emoji });
    // Browsers only allow sound after a user gesture.
    const unlock = () => this.audio.unlock();
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    this.net.onStatus((s) => {
      this.status.className = `net-status ${s}`;
      this.status.textContent = s === 'open' ? '' : s === 'connecting' ? 'Connecting to the salon…' : 'Connection lost — reconnecting…';
    });
    this.net.on((m) => this.handle(m));
    void this.world.ready.then(() => this.world.setDemo(true, demoGallery()));
    this.world.syncPawns(demoPawns(), null);
    this.showHome();
    this.net.connect();
  }

  private handle(m: ServerMessage) {
    switch (m.t) {
      case 'welcome':
        break;
      case 'room': {
        this.room = m.room;
        this.me = m.you;
        this.net.room = m.room.code;
        history.replaceState(null, '', `?room=${m.room.code}`);
        if (m.room.status === 'lobby') this.showLobby();
        else if (this.screen !== 'game') this.showGame();
        break;
      }
      case 'game':
        if (this.screen !== 'game') this.showGame();
        this.game!.receive(m.view, m.events);
        break;
      case 'chat':
        this.chat.addChat({ pid: m.pid, name: m.name, color: m.color, text: m.text, at: this.chat.stamp() });
        if (m.pid !== this.me) this.audio.click();
        break;
      case 'react':
        this.game?.react(m.pid, m.emoji);
        break;
      case 'error':
        if (this.game) this.game.rejected(m.message);
        else toast(m.message, 'error');
        break;
      case 'idle': {
        toast('You were away, so the autopilot is playing for you. Click anywhere to take over.', 'info', 8000);
        const back = () => {
          this.net.send({ t: 'back' });
          window.removeEventListener('pointerdown', back);
          window.removeEventListener('keydown', back);
        };
        window.addEventListener('pointerdown', back);
        window.addEventListener('keydown', back);
        break;
      }
      case 'left':
        this.net.room = null;
        this.room = null;
        history.replaceState(null, '', location.pathname);
        this.showHome();
        break;
    }
  }

  private clearScreen() {
    this.game?.dispose();
    this.game = null;
    this.lobby = null;
    this.screenEl.innerHTML = '';
    closeModal();
  }

  private showHome() {
    if (this.screen !== 'home') this.clearScreen();
    this.screen = 'home';
    this.world.setDemo(true);
    this.world.syncPawns(demoPawns(), null);
    const code = (new URLSearchParams(location.search).get('room') ?? '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4);
    const wrap = el('div', 'home');
    this.screenEl.appendChild(wrap);
    renderHome(wrap, localStorage.getItem(NAME_KEY) ?? '', code, {
      onCreate: (name) => {
        localStorage.setItem(NAME_KEY, name);
        this.audio.unlock();
        this.net.send({ t: 'create', name });
      },
      onJoin: (name, c) => {
        localStorage.setItem(NAME_KEY, name);
        this.audio.unlock();
        this.net.send({ t: 'join', code: c, name });
      },
      onHelp: () => showHelp(),
    });
  }

  private showLobby() {
    if (!this.room || !this.me) return;
    if (this.screen !== 'lobby') {
      this.clearScreen();
      this.screen = 'lobby';
      this.world.setDemo(true, demoGallery());
      this.lobby = new LobbyView(
        (msg) => this.net.send(msg),
        () => this.leave(),
        () => showHelp(),
        this.chat,
      );
      this.screenEl.appendChild(this.lobby.root);
    }
    this.lobby!.render(this.room, this.me);
    this.world.syncPawns(
      this.room.players.map((p, i) => ({ id: p.id, color: p.color, hat: p.hat, position: (i * 4) % 24 })),
      null,
    );
  }

  private showGame() {
    this.clearScreen();
    this.screen = 'game';
    this.world.setDemo(false);
    this.world.syncGallery([]);
    this.game = new GameScreen(
      this.world,
      this.net,
      this.audio,
      this.chat,
      () => this.me,
      () => !!this.room && this.room.hostId === this.me,
      () => this.leave(),
    );
    this.screenEl.appendChild(this.game.root);
  }

  private leave() {
    this.net.send({ t: 'leave' });
  }
}

function demoGallery() {
  const r = makeRng(20240611);
  const deck = buildCanvasDeck(r);
  const lots = buildLotDeck(r);
  return PLAYER_COLORS.slice(0, 5).map((color, i) => ({
    id: `demo${i}`,
    color,
    collection: [lots[i], ...deck.slice(i * 3, i * 3 + 3)],
  }));
}

function demoPawns() {
  return PLAYER_COLORS.slice(0, 4).map((color, i) => ({ id: `demo-pawn-${BOT_NAMES[i]}`, color, hat: HATS[i], position: [0, 7, 13, 19][i] }));
}
