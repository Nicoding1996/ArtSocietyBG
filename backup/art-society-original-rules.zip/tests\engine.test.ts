import { describe, expect, it } from 'vitest';
import { applyAction, applyTimeout, createGame, paymentFor, viewFor } from '../src/shared/engine';
import { RULES } from '../src/shared/content';
import { PIGMENTS, type GameState } from '../src/shared/types';
import { playBotGame } from '../scripts/botgame';

function newGame(players = 3, seed = 42): GameState {
  return createGame({
    seed,
    rounds: 4,
    now: 0,
    players: Array.from({ length: players }, (_, i) => ({
      id: `p${i}`,
      name: `P${i}`,
      color: '#fff',
      hat: 'beret' as const,
      isBot: false,
    })),
  }).state;
}

function choosePatrons(s: GameState) {
  for (const p of s.players) {
    const res = applyAction(s, p.id, { type: 'choosePatron', patron: p.patronOffer[0] }, 0);
    expect(res.ok).toBe(true);
  }
}

describe('full games', () => {
  it('bot games finish for every table size and keep resources valid', () => {
    for (let n = RULES.minPlayers; n <= RULES.maxPlayers; n++) {
      for (let seed = 1; seed <= 25; seed++) {
        const { s } = playBotGame(seed * 101 + n, n, 10, (_events, st) => {
          for (const p of st.players) {
            expect(p.francs).toBeGreaterThanOrEqual(0);
            expect(p.inspiration).toBeGreaterThanOrEqual(0);
            expect(p.inspiration).toBeLessThanOrEqual(RULES.maxInspiration);
            expect(p.hand.length).toBeLessThanOrEqual(RULES.handLimit);
            for (const k of PIGMENTS) expect(p.pigments[k]).toBeGreaterThanOrEqual(0);
          }
        });
        const res = s.results!;
        expect(res.players).toHaveLength(n);
        for (const r of res.players) {
          expect(r.total).toBe(r.artPoints + r.awardPoints + r.patronPoints + r.francPoints);
        }
        expect(res.winners.length).toBeGreaterThan(0);
        expect(res.players[0].rank).toBe(1);
      }
    }
  });
});

describe('rules', () => {
  it('starts with secret patron choice, then the first seat rolls', () => {
    const s = newGame();
    expect(s.phase.kind).toBe('patrons');
    choosePatrons(s);
    expect(s.phase.kind).toBe('roll');
    expect(s.round).toBe(1);
  });

  it('rejects actions from players who are not active', () => {
    const s = newGame();
    choosePatrons(s);
    const res = applyAction(s, s.players[1].id, { type: 'roll' }, 0);
    expect(res.ok).toBe(false);
  });

  it('hides other players patrons and auction bids in views', () => {
    const s = newGame();
    choosePatrons(s);
    const v = viewFor(s, 'p0');
    for (const p of v.players) {
      if (p.id === 'p0') expect(p.patron).not.toBeNull();
      else {
        expect(p.patron).toBeNull();
        expect(p.patronOffer).toEqual([]);
      }
    }
    s.phase = { kind: 'auction', lot: s.lotDeck[0], bids: { p1: 3 }, submitted: ['p1'], deadline: 1 };
    const v2 = viewFor(s, 'p0');
    expect(v2.phase.kind === 'auction' && v2.phase.bids).toEqual({});
    expect(JSON.stringify(viewFor(s, 'p2'))).not.toContain('"p1":3');
  });

  it('auction ties go to the opener and unpaid lots return to the vault', () => {
    const s = newGame();
    choosePatrons(s);
    const lot = s.lotDeck.shift()!;
    s.phase = { kind: 'auction', lot, bids: {}, submitted: [], deadline: 1000 };
    const opener = s.players[s.turn];
    applyAction(s, s.players[1].id, { type: 'bid', amount: 3 }, 0);
    applyAction(s, s.players[2].id, { type: 'bid', amount: 1 }, 0);
    const res = applyAction(s, opener.id, { type: 'bid', amount: 3 }, 0);
    expect(res.ok).toBe(true);
    expect(opener.collection.map((a) => a.id)).toContain(lot.id);
    expect(opener.francs).toBe(RULES.startFrancs - 3);

    const lot2 = s.lotDeck.shift()!;
    const before = s.lotDeck.length;
    s.phase = { kind: 'auction', lot: lot2, bids: {}, submitted: [], deadline: 1000 };
    expect(applyTimeout(s, 999)).toBeNull();
    expect(applyTimeout(s, 1000)).not.toBeNull();
    expect(s.lotDeck.length).toBe(before + 1);
    expect(s.phase.kind).toBe('paint');
  });

  it('rejects bids above the bidder’s francs', () => {
    const s = newGame();
    choosePatrons(s);
    s.phase = { kind: 'auction', lot: s.lotDeck[0], bids: {}, submitted: [], deadline: 1000 };
    expect(applyAction(s, 'p1', { type: 'bid', amount: 999 }, 0).ok).toBe(false);
    expect(applyAction(s, 'p1', { type: 'bid', amount: -1 }, 0).ok).toBe(false);
    expect(applyAction(s, 'p1', { type: 'bid', amount: 1.5 }, 0).ok).toBe(false);
  });

  it('mixes two spare pigments for each missing one', () => {
    expect(paymentFor({ red: 2, blue: 0, yellow: 0 }, { red: 2, blue: 0, yellow: 0 })).toEqual({ red: 2, blue: 0, yellow: 0 });
    expect(paymentFor({ red: 3, blue: 0, yellow: 1 }, { red: 1, blue: 1, yellow: 0 })).toEqual({ red: 3, blue: 0, yellow: 0 });
    expect(paymentFor({ red: 2, blue: 0, yellow: 0 }, { red: 1, blue: 1, yellow: 0 })).toBeNull();
  });

  it('limits shop purchases to the shop maximum and the player’s francs', () => {
    const s = newGame();
    choosePatrons(s);
    s.phase = { kind: 'shop' };
    const pid = s.players[s.turn].id;
    expect(applyAction(s, pid, { type: 'buy', pigments: { red: 5, blue: 0, yellow: 0 } }, 0).ok).toBe(false);
    expect(applyAction(s, pid, { type: 'buy', pigments: { red: 2, blue: 1, yellow: 0 } }, 0).ok).toBe(true);
    expect(s.players[s.turn].francs).toBe(RULES.startFrancs - 3);
  });
});
