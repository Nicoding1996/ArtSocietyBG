import type { GameEvent } from './types';

/**
 * Rough duration of the client animation for each event. The server waits this long before a bot
 * acts, so humans can follow what happened.
 */
export function eventAnimationMs(e: GameEvent): number {
  switch (e.t) {
    case 'roll':
      return 1400;
    case 'move':
      return 450 + e.steps * 300;
    case 'land':
      return 400;
    case 'soiree':
      return 2800;
    case 'auction':
      return 2200;
    case 'sold':
      return 3400;
    case 'paint':
      return 1600;
    case 'take':
      return 900;
    case 'review':
      return 1600;
    case 'trend':
      return 700;
    case 'round':
      return 1800;
    case 'turn':
      return 600;
    case 'buy':
      return 900;
    case 'gain':
    case 'salary':
      return 250;
    default:
      return 0;
  }
}

export function eventsAnimationMs(events: GameEvent[]): number {
  return events.reduce((sum, e) => sum + eventAnimationMs(e), 0);
}
