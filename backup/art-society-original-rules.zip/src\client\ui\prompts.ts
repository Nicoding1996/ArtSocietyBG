import { BOARD, MOVEMENT_INFO, PIGMENT_INFO, RULES, spaceInfo } from '../../shared/content';
import { canAfford } from '../../shared/engine';
import { MOVEMENTS, PIGMENTS, type Action, type GameView, type MovementId, type PigmentSet } from '../../shared/types';
import { el, esc, renderIf } from './dom';
import { icon } from './icons';
import { artCard, dot, francs, patronCard } from './parts';

interface Local {
  key: string;
  delta: number;
  buy: PigmentSet;
  praise: MovementId | null;
  pan: MovementId | null;
  bid: number;
  pending: boolean;
}

const fresh = (key: string): Local => ({ key, delta: 0, buy: { red: 0, blue: 0, yellow: 0 }, praise: null, pan: null, bid: 0, pending: false });

export class Prompts {
  readonly root = el('div', 'prompt');
  private local: Local = fresh('');
  private view: GameView | null = null;
  private me: string | null = null;
  private timer: number;

  constructor(
    private act: (a: Action) => void,
    private now: () => number,
    private onPreview: (space: number | null) => void,
  ) {
    this.timer = window.setInterval(() => this.tick(), 250);
  }

  dispose() {
    clearInterval(this.timer);
  }

  /** Called when the server rejected the last action: let the player try again. */
  unlock() {
    this.local.pending = false;
    if (this.view) this.render(this.view, this.me);
  }

  hide() {
    this.root.innerHTML = '';
    this.root.dataset.sig = '';
    this.root.className = 'prompt';
    this.onPreview(null);
  }

  private send(a: Action) {
    this.local.pending = true;
    this.root.classList.add('pending');
    this.act(a);
  }

  private tick() {
    for (const c of this.root.querySelectorAll<HTMLElement>('[data-deadline]')) {
      const s = Math.max(0, Math.ceil((Number(c.dataset.deadline) - this.now()) / 1000));
      c.textContent = `${s}s`;
      c.classList.toggle('urgent', s <= 5);
    }
  }

  render(v: GameView, me: string | null) {
    this.view = v;
    this.me = me;
    const p = v.players.find((x) => x.id === me);
    const ph = v.phase;
    const key = `${ph.kind}:${v.round}:${v.turn}:${ph.kind === 'auction' ? ph.lot.id : ''}:${v.lastRoll ?? ''}`;
    if (key !== this.local.key) this.local = fresh(key);
    if (!p) return this.hide();
    const mine = v.players[v.turn].id === me;
    const L = this.local;
    const sig = JSON.stringify([key, L, p.francs, p.pigments, p.inspiration, p.hand.length, ph.kind === 'auction' ? ph.submitted : null, p.patronChosen, v.canvasRow.map((c) => c.id)]);
    renderIf(this.root, sig, () => {
      this.root.className = `prompt ${L.pending ? 'pending' : ''}`;
      this.root.innerHTML = '';
      let preview: number | null = null;
      switch (ph.kind) {
        case 'patrons': {
          if (p.patronChosen) {
            const left = v.players.filter((x) => !x.patronChosen).length;
            this.root.appendChild(el('div', 'pr-box slim', `<div class="pr-title">Patron chosen</div><div class="pr-hint">Waiting for ${left} other artist${left === 1 ? '' : 's'}… <span class="countdown" data-deadline="${ph.deadline}"></span></div>`));
            break;
          }
          const box = el('div', 'pr-box wide', `<div class="pr-kicker">The Prelude</div><div class="pr-title">Choose your secret patron <span class="countdown" data-deadline="${ph.deadline}"></span></div><div class="pr-hint">Only you will know. Your patron's bonus is revealed at the Grand Gala.</div>`);
          const row = el('div', 'pr-choices');
          for (const id of p.patronOffer) {
            const b = el('button', 'choice patron-choice', patronCard(id));
            b.addEventListener('click', () => this.send({ type: 'choosePatron', patron: id }));
            row.appendChild(b);
          }
          box.appendChild(row);
          this.root.appendChild(box);
          break;
        }
        case 'roll': {
          if (!mine) break;
          const paintable = p.hand.some((c) => canAfford(p.pigments, c.cost));
          const box = el('div', 'pr-box slim center');
          box.innerHTML = `<button class="btn primary huge roll">${icon('dice')} Roll the die</button><div class="pr-hint">${paintable ? 'You can paint a sketch now, before you move.' : 'Move clockwise around the boulevard.'}</div>`;
          box.querySelector('.roll')!.addEventListener('click', () => this.send({ type: 'roll' }));
          this.root.appendChild(box);
          break;
        }
        case 'adjust': {
          if (!mine) break;
          const steps = ph.roll + L.delta;
          const dest = (p.position + steps) % RULES.boardSize;
          preview = dest;
          const info = spaceInfo(BOARD[dest]);
          const left = p.inspiration - Math.abs(L.delta);
          const canMinus = L.delta > 0 || (Math.abs(L.delta - 1) <= p.inspiration && steps - 1 >= 1);
          const canPlus = L.delta < 0 || Math.abs(L.delta + 1) <= p.inspiration;
          const box = el('div', 'pr-box slim center');
          box.innerHTML = `
            <div class="pr-title">You rolled <span class="die-val">${ph.roll}</span></div>
            <div class="adjust">
              <button class="btn minus" ${canMinus ? '' : 'disabled'} title="Use inspiration to move one space less">−1 ${icon('muse')}</button>
              <button class="btn primary big go">Move ${steps} → <b>${esc(info.name)}</b></button>
              <button class="btn plus" ${canPlus ? '' : 'disabled'} title="Use inspiration to move one space more">+1 ${icon('muse')}</button>
            </div>
            <div class="pr-hint">${esc(info.text)} · ${icon('muse')} ${left} inspiration left</div>`;
          box.querySelector('.minus')!.addEventListener('click', () => {
            L.delta--;
            this.render(v, me);
          });
          box.querySelector('.plus')!.addEventListener('click', () => {
            L.delta++;
            this.render(v, me);
          });
          box.querySelector('.go')!.addEventListener('click', () => this.send({ type: 'move', delta: L.delta }));
          this.root.appendChild(box);
          break;
        }
        case 'muse': {
          if (!mine) break;
          const box = el('div', 'pr-box wide', `<div class="pr-kicker">${icon('muse')} The Muse</div><div class="pr-title">Take a sketch into your studio</div><div class="pr-hint">Hollow drops are pigments you still need.</div>`);
          const row = el('div', 'pr-choices');
          v.canvasRow.forEach((c, i) => {
            const card = artCard(c, { have: p.pigments, trend: v.trends[c.movement], cls: 'pick' });
            card.addEventListener('click', () => this.send({ type: 'pick', index: i }));
            row.appendChild(card);
          });
          if (v.canvasDeckCount > 0) {
            const blind = el('button', 'card blind', `<div class="blind-back">${icon('sketch')}</div><div class="card-body"><div class="card-title">Draw blind</div><div class="pr-hint">${v.canvasDeckCount} left in the deck</div></div>`);
            blind.addEventListener('click', () => this.send({ type: 'pick', index: -1 }));
            row.appendChild(blind);
          }
          box.appendChild(row);
          const skip = el('button', 'btn ghost', 'Skip');
          skip.addEventListener('click', () => this.send({ type: 'skip' }));
          box.appendChild(el('div', 'pr-actions')).appendChild(skip);
          this.root.appendChild(box);
          break;
        }
        case 'shop': {
          if (!mine) break;
          const total = L.buy.red + L.buy.blue + L.buy.yellow;
          const cost = total * RULES.shopPrice;
          const box = el('div', 'pr-box center', `<div class="pr-kicker">${icon('shop')} Art Supplier</div><div class="pr-title">Buy pigments · ${RULES.shopPrice} ₣ each</div>`);
          const row = el('div', 'steppers');
          for (const k of PIGMENTS) {
            const info = PIGMENT_INFO[k];
            const s = el(
              'div',
              'stepper',
              `<div class="stp-name" style="--pc:${info.color}">${icon('drop')} ${info.name}</div>
               <div class="stp-ctl"><button class="icon-btn dec" ${L.buy[k] > 0 ? '' : 'disabled'}>${icon('minus')}</button><b>${L.buy[k]}</b><button class="icon-btn inc" ${total < RULES.shopMax && cost + RULES.shopPrice <= p.francs ? '' : 'disabled'}>${icon('plus')}</button></div>`,
            );
            s.querySelector('.dec')!.addEventListener('click', () => {
              L.buy[k]--;
              this.render(v, me);
            });
            s.querySelector('.inc')!.addEventListener('click', () => {
              L.buy[k]++;
              this.render(v, me);
            });
            row.appendChild(s);
          }
          box.appendChild(row);
          const acts = el('div', 'pr-actions');
          acts.innerHTML = `<span class="pr-hint">You have ${francs(p.francs)} · up to ${RULES.shopMax} pigments</span>`;
          const buy = el('button', 'btn primary', total ? `Buy ${total} for ${cost} ₣` : 'Choose pigments');
          if (!total) buy.setAttribute('disabled', '');
          buy.addEventListener('click', () => this.send({ type: 'buy', pigments: { ...L.buy } }));
          const skip = el('button', 'btn ghost', 'Leave the shop');
          skip.addEventListener('click', () => this.send({ type: 'skip' }));
          acts.append(skip, buy);
          box.appendChild(acts);
          this.root.appendChild(box);
          break;
        }
        case 'review': {
          if (!mine) break;
          const box = el('div', 'pr-box wide', `<div class="pr-kicker">${icon('gazette')} The Gazette</div><div class="pr-title">Write tomorrow's review</div><div class="pr-hint">Praise raises a movement's trend by 1; panning lowers another by 1. Trends add to every artwork of that movement at the Gala.</div>`);
          const mk = (label: string, which: 'praise' | 'pan') => {
            const row = el('div', 'mv-pick', `<div class="mv-pick-label">${label}</div>`);
            for (const m of MOVEMENTS) {
              const info = MOVEMENT_INFO[m];
              const disabled = (which === 'pan' && m === L.praise) || (which === 'praise' && m === L.pan);
              const t = v.trends[m];
              const b = el('button', `mv-btn ${L[which] === m ? 'on' : ''}`, `${icon(m)}<span>${esc(info.name)}</span><small>trend ${t}</small>`);
              b.style.setProperty('--mv', info.color);
              if (disabled) b.setAttribute('disabled', '');
              b.addEventListener('click', () => {
                L[which] = L[which] === m ? null : m;
                this.render(v, me);
              });
              row.appendChild(b);
            }
            return row;
          };
          box.append(mk('Praise ▲', 'praise'), mk('Pan ▼ (optional)', 'pan'));
          const acts = el('div', 'pr-actions');
          const go = el('button', 'btn primary', 'Publish the review');
          if (!L.praise) go.setAttribute('disabled', '');
          go.addEventListener('click', () => L.praise && this.send({ type: 'review', praise: L.praise, pan: L.pan }));
          acts.appendChild(go);
          box.appendChild(acts);
          this.root.appendChild(box);
          break;
        }
        case 'auction': {
          const done = ph.submitted.includes(p.id);
          const box = el('div', 'pr-box auction');
          const card = artCard(ph.lot, { trend: v.trends[ph.lot.movement], cls: 'lot' });
          box.appendChild(card);
          const right = el('div', 'auc-right');
          const opener = v.players[v.turn];
          right.innerHTML = `<div class="pr-kicker">${icon('gavel')} Auction House · opened by ${esc(opener.name)}</div>
            <div class="pr-title">“${esc(ph.lot.title)}” <span class="countdown" data-deadline="${ph.deadline}"></span></div>
            <div class="pr-hint">A masterpiece by ${esc(ph.lot.artist ?? '')}. Everyone bids once, in secret. Highest bid wins; ties go to the artist closest to ${esc(opener.name)} in turn order.</div>
            <div class="bidders">${v.players.map((x) => `<span class="bidder ${ph.submitted.includes(x.id) ? 'in' : ''}">${dot(x.color)}${esc(x.name)}${ph.submitted.includes(x.id) ? icon('check') : ''}</span>`).join('')}</div>`;
          if (done) {
            const mineBid = ph.bids[p.id];
            right.appendChild(el('div', 'sealed', `${icon('check')} Your sealed bid: <b>${mineBid ?? '?'} ₣</b>. Waiting for the others…`));
          } else {
            const max = p.francs;
            L.bid = Math.min(L.bid, max);
            const ctl = el(
              'div',
              'bid-ctl',
              `<button class="icon-btn dec" ${L.bid > 0 ? '' : 'disabled'}>${icon('minus')}</button>
               <div class="bid-amt"><b>${L.bid}</b> ₣</div>
               <button class="icon-btn inc" ${L.bid < max ? '' : 'disabled'}>${icon('plus')}</button>
               <input type="range" min="0" max="${max}" value="${L.bid}" aria-label="Bid amount" />`,
            );
            ctl.querySelector('.dec')!.addEventListener('click', () => {
              L.bid = Math.max(0, L.bid - 1);
              this.render(v, me);
            });
            ctl.querySelector('.inc')!.addEventListener('click', () => {
              L.bid = Math.min(max, L.bid + 1);
              this.render(v, me);
            });
            const range = ctl.querySelector('input')!;
            range.addEventListener('input', () => {
              L.bid = Number(range.value);
              (ctl.querySelector('.bid-amt b') as HTMLElement).textContent = String(L.bid);
            });
            range.addEventListener('change', () => this.render(v, me));
            right.appendChild(ctl);
            const acts = el('div', 'pr-actions');
            acts.innerHTML = `<span class="pr-hint">You have ${francs(p.francs)}</span>`;
            const pass = el('button', 'btn ghost', 'Pass (bid 0)');
            pass.addEventListener('click', () => this.send({ type: 'bid', amount: 0 }));
            const go = el('button', 'btn primary', `Seal my bid`);
            go.addEventListener('click', () => this.send({ type: 'bid', amount: L.bid }));
            acts.append(pass, go);
            right.appendChild(acts);
          }
          box.appendChild(right);
          this.root.appendChild(box);
          break;
        }
        case 'paint': {
          if (!mine) break;
          const paintable = p.hand.some((c) => canAfford(p.pigments, c.cost));
          const box = el('div', 'pr-box slim center');
          box.innerHTML = `<button class="btn primary big end">End turn</button><div class="pr-hint">${paintable ? `${icon('sketch')} You can still paint — use the <b>Paint</b> buttons in your studio.` : 'Nothing left to paint this turn.'}</div>`;
          box.querySelector('.end')!.addEventListener('click', () => this.send({ type: 'endTurn' }));
          this.root.appendChild(box);
          break;
        }
      }
      this.onPreview(preview);
      this.tick();
    });
  }
}
