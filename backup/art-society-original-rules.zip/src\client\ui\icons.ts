/** Line icons (24×24, currentColor). Used in the DOM and rasterised onto board tiles. */
const P: Record<string, string> = {
  hall: '<path d="M3 9.5 12 4l9 5.5"/><path d="M4.5 9.5h15"/><path d="M6.5 11v6.5M10.2 11v6.5M13.8 11v6.5M17.5 11v6.5"/><path d="M4.5 18.5h15M3 21h18"/>',
  drop: '<path d="M12 3.2c3.7 4.7 6.2 8 6.2 11.2a6.2 6.2 0 0 1-12.4 0c0-3.2 2.5-6.5 6.2-11.2z" fill="currentColor" stroke="none"/><path d="M9.4 14.6a2.8 2.8 0 0 0 2.2 2.9" stroke="#fff" stroke-opacity=".55"/>',
  muse: '<path d="M11 2.5c.7 4.6 3 6.9 7.6 7.6-4.6.7-6.9 3-7.6 7.6-.7-4.6-3-6.9-7.6-7.6 4.6-.7 6.9-3 7.6-7.6z" fill="currentColor" stroke="none"/><path d="M18.5 14.5c.3 1.8 1.2 2.7 3 3-1.8.3-2.7 1.2-3 3-.3-1.8-1.2-2.7-3-3 1.8-.3 2.7-1.2 3-3z" fill="currentColor" stroke="none"/>',
  shop: '<path d="M8 2.8h8v2.6l-1.2 1.4v10a2.8 2.8 0 0 1-5.6 0v-10L8 5.4z"/><path d="M9.2 10.5h5.6"/><path d="M10.5 19.6V22h3v-2.4"/>',
  coin: '<circle cx="12" cy="12" r="8.6"/><circle cx="12" cy="12" r="6.2" stroke-opacity=".45"/><path d="M10.2 16.2V7.8h4.4M10.2 11.6h3.4M8.6 14h4"/>',
  gavel: '<path d="M10.2 7.6 14.4 3.4l5.4 5.4-4.2 4.2z"/><path d="M12.6 10.6 4.4 18.8"/><path d="M3 21.2h9.5"/>',
  gazette: '<path d="M4 4.5h13v13.2a2.3 2.3 0 0 0 2.3 2.3H6.3A2.3 2.3 0 0 1 4 17.7z"/><path d="M17 8.5h3v9.2a2.3 2.3 0 0 1-2.3 2.3"/><path d="M7 8h7M7 11.5h7M7 15h4.5"/>',
  soiree: '<path d="M4.8 6.2h14.4c0 3.8-3.1 6.4-7.2 6.4s-7.2-2.6-7.2-6.4z"/><path d="M12 12.6v6.6M8.4 20.2h7.2"/><circle cx="10" cy="3.2" r=".9" fill="currentColor" stroke="none"/><circle cx="13.8" cy="2.4" r=".7" fill="currentColor" stroke="none"/>',
  sketch: '<rect x="4.5" y="3.5" width="15" height="11" rx="1"/><path d="M8 19.5 10 14.5M16 19.5 14 14.5M12 14.5v6.5"/><path d="M7.5 12l3-3.2 2.6 2.6 1.6-1.6 2 2"/>',
  frame: '<rect x="3.5" y="4.5" width="17" height="15" rx="1"/><rect x="6.5" y="7.5" width="11" height="9" stroke-opacity=".6"/><path d="M7.5 15l3-3.5 2.5 2.5 1.5-1.5 2.5 2.5"/>',
  laurel: '<path d="M12 20.5c-4.6 0-8.2-3.9-8.2-8.7 0-2 .6-3.9 1.7-5.4M12 20.5c4.6 0 8.2-3.9 8.2-8.7 0-2-.6-3.9-1.7-5.4"/><path d="M5.2 9.2c1.7.2 2.7 1.2 2.9 2.9-1.7-.2-2.7-1.2-2.9-2.9zM4.5 13.4c1.7-.1 2.9.7 3.3 2.3-1.7.1-2.9-.7-3.3-2.3zM18.8 9.2c-1.7.2-2.7 1.2-2.9 2.9 1.7-.2 2.7-1.2 2.9-2.9zM19.5 13.4c-1.7-.1-2.9.7-3.3 2.3 1.7.1 2.9-.7 3.3-2.3z" fill="currentColor"/>',
  crown: '<path d="M3.5 8.2l4.2 3.6L12 5l4.3 6.8 4.2-3.6-1.9 10.3H5.4z"/><path d="M5.5 21h13"/>',
  dice: '<rect x="3.8" y="3.8" width="16.4" height="16.4" rx="3.6"/><circle cx="8.6" cy="8.6" r="1.35" fill="currentColor"/><circle cx="15.4" cy="15.4" r="1.35" fill="currentColor"/><circle cx="15.4" cy="8.6" r="1.35" fill="currentColor"/><circle cx="8.6" cy="15.4" r="1.35" fill="currentColor"/><circle cx="12" cy="12" r="1.35" fill="currentColor"/>',
  chat: '<path d="M4.5 5.5h15v10h-8l-4.5 3.8v-3.8H4.5z"/>',
  sound: '<path d="M4.5 9.5h3.5L12.5 6v12L8 14.5H4.5z"/><path d="M15.5 9.2a4 4 0 0 1 0 5.6M18 6.8a7.5 7.5 0 0 1 0 10.4"/>',
  mute: '<path d="M4.5 9.5h3.5L12.5 6v12L8 14.5H4.5z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
  music: '<path d="M9 18V5.5l11-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.6 2.6 0 0 1 5 .9c0 1.7-2.5 2.2-2.5 4"/><circle cx="12" cy="17.2" r=".6" fill="currentColor"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5v-2a2 2 0 0 0-2-2h-7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2"/>',
  bot: '<rect x="5" y="8" width="14" height="10.5" rx="3"/><path d="M12 8V4.5"/><circle cx="12" cy="3.8" r="1"/><circle cx="9.3" cy="13" r="1.3" fill="currentColor"/><circle cx="14.7" cy="13" r="1.3" fill="currentColor"/><path d="M3 12.5v2.5M21 12.5v2.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  check: '<path d="M5 12.5l4.2 4.2L19 7"/>',
  camera: '<path d="M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  offline: '<path d="M3 3l18 18"/><path d="M8.5 16.5a5 5 0 0 1 7 0M5 13a10 10 0 0 1 4-2.3M12 9.5a10 10 0 0 1 7 3.5M2 9.5a15 15 0 0 1 4.4-2.8M11 5.5a15 15 0 0 1 11 4"/><circle cx="12" cy="19.5" r=".8" fill="currentColor"/>',
  flag: '<path d="M5.5 21V4M5.5 4.5h11l-2 3.8 2 3.7h-11"/>',
  beret: '<path d="M3.6 13.6c0-4 3.8-7 8.4-7s8.4 3 8.4 6.4c0 .9-1 1.6-2.6 1.6H6.2c-1.6 0-2.6-.4-2.6-1z"/><path d="M12 6.6V4.5"/><path d="M6.5 14.6c.6 1.6 2.9 2.6 5.5 2.6s4.9-1 5.5-2.6"/>',
  tophat: '<path d="M7.8 3.5h8.4v11.8H7.8z"/><path d="M3.5 15.6h17"/><path d="M7.8 12h8.4"/>',
  bowler: '<path d="M6.2 15.2c0-5.2 2.6-8.7 5.8-8.7s5.8 3.5 5.8 8.7"/><path d="M3.2 15.6c2.7 1.7 14.9 1.7 17.6 0"/>',
  flower: '<circle cx="12" cy="9.5" r="2"/><circle cx="12" cy="5.4" r="2.1"/><circle cx="16" cy="8.4" r="2.1"/><circle cx="14.5" cy="13" r="2.1"/><circle cx="9.5" cy="13" r="2.1"/><circle cx="8" cy="8.4" r="2.1"/><path d="M12 15.5V21"/>',
  impressionism: '<path d="M12 5.5c1.7 2.1 1.7 4.7 0 6.8-1.7-2.1-1.7-4.7 0-6.8z"/><path d="M12 12.3c-2.6-.2-4.6-1.8-5.2-4.4 2.6.2 4.6 1.8 5.2 4.4zM12 12.3c2.6-.2 4.6-1.8 5.2-4.4-2.6.2-4.6 1.8-5.2 4.4z"/><path d="M3.8 15.5c2.6 1.7 5.4 2.5 8.2 2.5s5.6-.8 8.2-2.5"/><path d="M6.5 19.6c1.8.6 3.6.9 5.5.9s3.7-.3 5.5-.9"/>',
  postimpressionism: '<path d="M12 12.5c0-1.2 1-2 2-1.8 1.4.3 2 1.8 1.4 3.1-.9 1.7-3.2 2.2-4.8 1.2-2.2-1.4-2.6-4.4-1.1-6.4 1.9-2.6 5.8-3 8.2-.8"/><path d="M3 18.5c3-1.5 5.5-1.5 9 0s6 1.5 9 0"/><path d="M5.5 5.5v2.5M4.25 6.75h2.5"/>',
  cubism: '<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12 4 7.5M12 12v9"/>',
  ukiyoe: '<path d="M3 18c2.5 0 3.5-1.5 4.5-3.5 1.7-3.5 3.5-6 7-6 2.6 0 4.5 1.8 4.5 4-1.6-1.2-3.8-.8-4.4 1-.5 1.6.6 3 2.4 3.4H21"/><path d="M3 21h18"/>',
  abstract: '<circle cx="8" cy="8.5" r="4"/><rect x="12.5" y="11.5" width="7.5" height="7.5"/><path d="M4 20l4-6.5 4 6.5z"/>',
};

export type IconName = keyof typeof P;

export function icon(name: string, cls = 'ic', extra = ''): string {
  const body = P[name] ?? P.frame;
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${body}</svg>`;
}

/** Rasterises an icon for canvas textures. */
export function iconImage(name: string, color: string, size = 256, strokeWidth = 1.6): Promise<HTMLImageElement> {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" color="${color}" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round">${(P[name] ?? P.frame).replace(/currentColor/g, color)}</svg>`;
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
}
