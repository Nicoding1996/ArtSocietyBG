import type { Artwork, MovementId } from '../../shared/types';
import { makePainter, type Painter } from './common';
import { impressionism } from './impressionism';
import { postimpressionism } from './postimpressionism';
import { cubism } from './cubism';
import { ukiyoe } from './ukiyoe';
import { abstract } from './abstract';

export const ART_W = 480;
export const ART_H = 600;

const STYLES: Record<MovementId, (p: Painter) => void> = {
  impressionism,
  postimpressionism,
  cubism,
  ukiyoe,
  abstract,
};

type ArtKey = Pick<Artwork, 'id' | 'movement' | 'seed' | 'kind'>;

export function paintArtwork(art: ArtKey, w = ART_W, h = ART_H): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const p = makePainter(canvas, art.seed, art.kind === 'masterpiece' ? 1.35 : 1);
  try {
    STYLES[art.movement](p);
  } catch (err) {
    console.error('Painting failed', art, err);
    p.c.fillStyle = '#7a6a55';
    p.c.fillRect(0, 0, w, h);
  }
  return canvas;
}

interface Entry {
  canvas: HTMLCanvasElement | null;
  url: string | null;
  urlWaiters: ((url: string) => void)[];
  canvasWaiters: ((canvas: HTMLCanvasElement) => void)[];
}

const cache = new Map<string, Entry>();
const queue: ArtKey[] = [];
let pumping = false;

const keyOf = (a: ArtKey) => `${a.movement}:${a.seed}:${a.kind}`;

/** Paints queued artworks in small time slices so the frame rate survives a full gallery. */
function pump() {
  if (pumping) return;
  pumping = true;
  const step = () => {
    const start = performance.now();
    while (queue.length && performance.now() - start < 20) {
      const art = queue.shift()!;
      const e = cache.get(keyOf(art))!;
      if (e.canvas) continue;
      const canvas = paintArtwork(art);
      e.canvas = canvas;
      for (const fn of e.canvasWaiters.splice(0)) fn(canvas);
      // JPEG encoding happens off the main thread; only <img> users wait for it.
      canvas.toBlob(
        (blob) => {
          e.url = blob ? URL.createObjectURL(blob) : canvas.toDataURL('image/jpeg', 0.9);
          for (const fn of e.urlWaiters.splice(0)) fn(e.url);
        },
        'image/jpeg',
        0.9,
      );
    }
    if (queue.length) setTimeout(step, 0);
    else pumping = false;
  };
  setTimeout(step, 0);
}

function ensure(art: ArtKey): Entry {
  const key = keyOf(art);
  let e = cache.get(key);
  if (!e) {
    e = { canvas: null, url: null, urlWaiters: [], canvasWaiters: [] };
    cache.set(key, e);
    queue.push(art);
    pump();
  }
  return e;
}

/** Canvas for 3D textures. Calls back once painted (immediately if cached). */
export function artCanvas(art: ArtKey, cb: (canvas: HTMLCanvasElement) => void) {
  const e = ensure(art);
  if (e.canvas) cb(e.canvas);
  else e.canvasWaiters.push(cb);
}

/** <img> element that fills in when the painting is ready. */
export function artImg(art: ArtKey, cls = 'art-img'): HTMLImageElement {
  const img = document.createElement('img');
  img.className = cls + ' loading';
  img.alt = '';
  img.decoding = 'async';
  img.draggable = false;
  const show = (url: string) => {
    img.src = url;
    img.classList.remove('loading');
  };
  const e = ensure(art);
  if (e.url) show(e.url);
  else e.urlWaiters.push(show);
  return img;
}
