/** Heuristic AI. Uses only what its own player view shows, so bots never peek at secrets. */
import type { Action, Artwork, GameView, MovementId, PatronId, PigmentSet, PlayerState } from './types';
import { MOVEMENTS, PIGMENTS } from './types';
import { BOARD, PATRON_MOVEMENT, RULES } from './content';
import { canAfford, missingPigments } from './engine';
import { movementCounts } from './scoring';
import type { Rand } from './rng';

function patronBonus(art: Artwork, p: PlayerState, trends: Record<MovementId, number>): number {
  const patron = p.patron;
  if (!patron) return 0;
  const counts = movementCounts(p.collection);
  if (PATRON_MOVEMENT[patron]) return PATRON_MOVEMENT[patron] === art.movement ? 3 : 0;
  switch (patron) {
    case 'curator':
      return counts[art.movement] === 0 ? 2 : 0;
    case 'marteau':
      return art.kind === 'masterpiece' ? 5 : 0;
    case 'plenty':
      return art.kind === 'canvas' ? 2 : 0;
    case 'aurelius':
      return art.value >= 5 ? 3 : 0;
    case 'vogue':
      return trends[art.movement] >= 2 ? 3 : 0.8;
    case 'pur':
      return counts[art.movement] % 2 === 1 ? 4 : 1.2;
    default:
      return 0;
  }
}

export function artWorth(art: Artwork, p: PlayerState, v: GameView): number {
  return art.value + v.trends[art.movement] + patronBonus(art, p, v.trends);
}

/** Pigments still needed to paint every sketch in hand, most valuable sketches first. */
function pigmentNeeds(p: PlayerState): PigmentSet {
  const need: PigmentSet = { red: 0, blue: 0, yellow: 0 };
  for (const c of p.hand) for (const k of PIGMENTS) need[k] += c.cost[k];
  for (const k of PIGMENTS) need[k] = Math.max(0, need[k] - p.pigments[k]);
  return need;
}

function bestPaintable(p: PlayerState, v: GameView): Artwork | null {
  const options = p.hand.filter((c) => canAfford(p.pigments, c.cost));
  options.sort((a, b) => artWorth(b, p, v) - artWorth(a, p, v));
  return options[0] ?? null;
}

function spaceValue(index: number, p: PlayerState, v: GameView): number {
  const space = BOARD[index];
  const need = pigmentNeeds(p);
  switch (space.type) {
    case 'pigment':
      return 2 + (need[space.pigment!] > 0 ? 2 : 0);
    case 'muse':
      return p.hand.length < 2 ? 4.5 : p.hand.length < RULES.handLimit ? 2.5 : 0.5;
    case 'shop':
      return p.francs >= 2 && need.red + need.blue + need.yellow > 0 ? 3 : 0.5;
    case 'patron':
      return 2.5;
    case 'auction':
      return v.lotDeckCount > 0 && p.francs >= 5 ? 3.5 : 1;
    case 'gazette':
      return p.collection.length > 0 ? 2.5 : 1.5;
    case 'soiree':
      return 1.8;
    case 'hall':
      return 1.5;
  }
}

function chooseDelta(v: GameView, p: PlayerState, roll: number): number {
  const range = Math.min(2, p.inspiration);
  let best = 0;
  let bestScore = -Infinity;
  for (let d = -range; d <= range; d++) {
    const steps = roll + d;
    if (steps < 1) continue;
    const target = (p.position + steps) % RULES.boardSize;
    const passBonus = p.position + steps >= RULES.boardSize ? 1 : 0;
    const score = spaceValue(target, p, v) + passBonus - Math.abs(d) * 1.6;
    if (score > bestScore + 1e-9) {
      bestScore = score;
      best = d;
    }
  }
  return best;
}

function chooseCanvas(v: GameView, p: PlayerState): number {
  let best = -1;
  let bestScore = v.canvasDeckCount > 0 ? 1.6 : -Infinity;
  v.canvasRow.forEach((c, i) => {
    const score = artWorth(c, p, v) / (1 + missingPigments(p.pigments, c.cost) * 0.6);
    if (score > bestScore) {
      bestScore = score;
      best = i;
    }
  });
  if (best === -1 && v.canvasDeckCount === 0) return 0;
  return best;
}

function chooseBuy(p: PlayerState): PigmentSet | null {
  const need = pigmentNeeds(p);
  let budget = Math.min(RULES.shopMax, Math.floor(Math.max(0, p.francs - 1) / RULES.shopPrice));
  if (p.patron === 'baron') {
    // Every franc is a point for the Baron: only buy what finishes a sketch right away.
    const closest = Math.min(99, ...p.hand.map((c) => missingPigments(p.pigments, c.cost)));
    budget = closest <= 2 ? Math.min(budget, closest) : 0;
  }
  const buy: PigmentSet = { red: 0, blue: 0, yellow: 0 };
  let total = 0;
  // Buy for the cheapest-to-finish sketch first.
  const hand = [...p.hand].sort((a, b) => missingPigments(p.pigments, a.cost) - missingPigments(p.pigments, b.cost));
  const have = { ...p.pigments };
  for (const c of hand) {
    for (const k of PIGMENTS) {
      while (have[k] < c.cost[k] && total < budget && need[k] > 0) {
        have[k]++;
        buy[k]++;
        total++;
      }
    }
  }
  return total > 0 ? buy : null;
}

function chooseReview(v: GameView, p: PlayerState): Action {
  const mine = movementCounts(p.collection);
  const handCounts = movementCounts(p.hand);
  const others = movementCounts(v.players.filter((x) => x.id !== p.id).flatMap((x) => x.collection));
  const fav = p.patron ? PATRON_MOVEMENT[p.patron] : undefined;
  const praiseScore = (m: MovementId) =>
    mine[m] * 2 + handCounts[m] + (fav === m ? 2 : 0) - others[m] * 0.5 - (v.trends[m] >= RULES.trendMax ? 100 : 0);
  const praise = [...MOVEMENTS].sort((a, b) => praiseScore(b) - praiseScore(a))[0];
  const panScore = (m: MovementId) =>
    others[m] - mine[m] * 2 - handCounts[m] - (fav === m ? 5 : 0) - (v.trends[m] <= RULES.trendMin ? 100 : 0);
  const panOptions = MOVEMENTS.filter((m) => m !== praise).sort((a, b) => panScore(b) - panScore(a));
  const pan = panOptions.length && panScore(panOptions[0]) > 0 ? panOptions[0] : null;
  return { type: 'review', praise, pan };
}

function chooseBid(v: GameView, p: PlayerState, lot: Artwork, r: Rand): number {
  const worth = artWorth(lot, p, v);
  const roundsLeft = v.totalRounds - v.round;
  const eagerness = (0.55 + r() * 0.35 + (roundsLeft <= 1 ? 0.2 : 0)) * (p.patron === 'baron' ? 0.7 : 1);
  return Math.max(0, Math.min(p.francs, Math.round(worth * eagerness)));
}

function choosePatron(p: PlayerState): PatronId {
  const hand = movementCounts(p.hand);
  const score = (id: PatronId) => {
    const m = PATRON_MOVEMENT[id];
    if (m) return 2 + hand[m] * 2;
    const base: Partial<Record<PatronId, number>> = {
      curator: 3.5,
      plenty: 3.2,
      aurelius: 3,
      pur: 3,
      vogue: 2.6,
      marteau: 2.6,
      baron: 2.2,
    };
    return base[id] ?? 2.5;
  };
  return [...p.patronOffer].sort((a, b) => score(b) - score(a))[0];
}

/** The next action this player should take, or null if the game is not waiting on them. */
export function botDecide(v: GameView, me: string, r: Rand): Action | null {
  const p = v.players.find((x) => x.id === me);
  if (!p) return null;
  const ph = v.phase;
  if (ph.kind === 'patrons') return p.patronChosen ? null : { type: 'choosePatron', patron: choosePatron(p) };
  if (ph.kind === 'auction') return ph.submitted.includes(me) ? null : { type: 'bid', amount: chooseBid(v, p, ph.lot, r) };
  if (ph.kind === 'over' || v.players[v.turn].id !== me) return null;
  switch (ph.kind) {
    case 'roll': {
      const art = bestPaintable(p, v);
      return art ? { type: 'paint', artId: art.id } : { type: 'roll' };
    }
    case 'adjust':
      return { type: 'move', delta: chooseDelta(v, p, ph.roll) };
    case 'muse':
      return { type: 'pick', index: chooseCanvas(v, p) };
    case 'shop': {
      const buy = chooseBuy(p);
      return buy ? { type: 'buy', pigments: buy } : { type: 'skip' };
    }
    case 'review':
      return chooseReview(v, p);
    case 'paint': {
      const art = bestPaintable(p, v);
      return art ? { type: 'paint', artId: art.id } : { type: 'endTurn' };
    }
  }
}
