import { MOVEMENT_INFO, PATRONS, RULES, awardInfo } from '../../shared/content';
import type { GameResults, GameView, PlayerResult, PlayerState } from '../../shared/types';
import { artImg } from '../art/generate';
import type { Audio } from '../audio';
import type { World } from '../three/world';
import { el, esc } from './dom';
import { icon } from './icons';
import { dot, patronCard } from './parts';

/** The end-of-game reveal: collections, awards, francs, secret patrons, then the laureate. */
export class Ceremony {
  readonly root = el('div', 'gala');
  private skipping = false;
  private wake: (() => void) | null = null;
  private scores = new Map<string, number>();
  private played = false;
  private reopen = el('button', 'btn gala-reopen', `${icon('crown')} Results`);

  constructor(
    private world: World,
    private audio: Audio,
    private onLobby: () => void,
    private isHost: () => boolean,
  ) {
    this.reopen.addEventListener('click', () => {
      this.root.classList.add('show');
      this.reopen.classList.remove('show');
      this.hudHidden(true);
    });
  }

  /** The HUD fades out while the Gala is on screen. */
  private hudHidden(on: boolean) {
    this.root.parentElement?.classList.toggle('gala-on', on);
  }

  get started() {
    return this.played;
  }

  mount(parent: HTMLElement) {
    parent.append(this.root, this.reopen);
  }

  close() {
    this.hudHidden(false);
    this.root.classList.remove('show');
    this.reopen.classList.remove('show');
    this.root.innerHTML = '';
    this.played = false;
    this.world.clearPodium();
  }

  private wait(ms: number) {
    if (this.skipping) return Promise.resolve();
    return new Promise<void>((resolve) => {
      const t = setTimeout(() => {
        this.wake = null;
        resolve();
      }, ms);
      this.wake = () => {
        clearTimeout(t);
        this.wake = null;
        resolve();
      };
    });
  }

  private skip() {
    this.skipping = true;
    this.wake?.();
  }

  private count(pid: string, add: number) {
    const from = this.scores.get(pid) ?? 0;
    const to = from + add;
    this.scores.set(pid, to);
    const node = this.root.querySelector<HTMLElement>(`.gcol[data-pid="${pid}"] .gcol-score b`);
    if (!node) return;
    if (this.skipping) {
      node.textContent = String(to);
      return;
    }
    const start = performance.now();
    const stepFn = (now: number) => {
      const t = Math.min(1, (now - start) / 600);
      node.textContent = String(Math.round(from + (to - from) * (1 - Math.pow(1 - t, 3))));
      if (t < 1) requestAnimationFrame(stepFn);
    };
    requestAnimationFrame(stepFn);
    const col = node.closest('.gcol') as HTMLElement;
    const pop = el('div', 'gcol-pop', `+${add}`);
    col.appendChild(pop);
    setTimeout(() => pop.remove(), 1200);
  }

  private setAct(title: string, sub = '') {
    const a = this.root.querySelector('.gala-act');
    if (a) a.innerHTML = `${esc(title)}${sub ? `<small>${esc(sub)}</small>` : ''}`;
  }

  async play(v: GameView, me: string | null) {
    const res = v.results;
    if (!res || this.played) return;
    this.played = true;
    this.skipping = false;
    this.scores.clear();
    const byId = new Map(v.players.map((p) => [p.id, p]));
    const result = (pid: string) => res.players.find((r) => r.pid === pid)!;

    this.root.innerHTML = `
      <div class="gala-head"><div class="gala-kicker">${icon('laurel')} The Grand Gala ${icon('laurel')}</div><div class="gala-act"></div></div>
      <div class="gala-cols"></div>
      <div class="gala-foot"><button class="btn ghost skip">Skip to the winner</button></div>`;
    this.root.querySelector('.skip')!.addEventListener('click', () => this.skip());
    const cols = this.root.querySelector('.gala-cols')!;
    for (const p of v.players) {
      const c = el('div', 'gcol');
      c.dataset.pid = p.id;
      c.style.setProperty('--pc', p.color);
      c.innerHTML = `<div class="gcol-name">${dot(p.color)}${esc(p.name)}${p.id === me ? ' <small>(you)</small>' : ''}</div>
        <div class="gcol-score"><b>0</b><span>prestige</span></div>
        <div class="gcol-items"></div>`;
      cols.appendChild(c);
      this.scores.set(p.id, 0);
    }
    this.root.classList.add('show');
    this.root.classList.remove('finale');
    this.reopen.classList.remove('show');
    this.hudHidden(true);
    this.audio.fanfare();
    this.setAct('The Society gathers…', 'Every artwork is judged at the final fashion of its movement');
    this.world.followPlayer(null);
    void this.world.overview(1500);
    await this.wait(2600);

    // Act I: collections, revealed one artwork at a time for every artist in parallel.
    this.setAct('Act I · The Collections', 'Prestige of each work + its movement’s final trend');
    const maxArt = Math.max(0, ...res.players.map((r) => r.art.length));
    for (let i = 0; i < maxArt; i++) {
      for (const p of v.players) {
        const r = result(p.id);
        const a = r.art[i];
        if (!a) continue;
        const art = [...p.collection].find((x) => x.id === a.id);
        const items = this.root.querySelector(`.gcol[data-pid="${p.id}"] .gcol-items`)!;
        const item = el('div', 'gi art');
        if (art) item.appendChild(artImg(art, 'gi-thumb'));
        item.appendChild(el('span', 'gi-val', `${a.base}<small style="color:${MOVEMENT_INFO[a.movement].color}">+${a.trend}</small>`));
        items.appendChild(item);
        this.count(p.id, a.base + a.trend);
      }
      this.audio.coin();
      await this.wait(520);
    }
    await this.wait(900);

    // Act II: Society Awards.
    for (const aw of res.awards) {
      const info = awardInfo(aw.id);
      this.setAct(`Act II · ${info.name}`, `${info.text} — +${RULES.awardPoints} prestige`);
      this.audio.drumroll(0.9);
      await this.wait(1200);
      if (!aw.winners.length) {
        this.setAct(`Act II · ${info.name}`, 'Not awarded this season');
      }
      for (const pid of aw.winners) {
        const items = this.root.querySelector(`.gcol[data-pid="${pid}"] .gcol-items`)!;
        items.appendChild(el('div', 'gi award', `${icon('laurel')}<span>${esc(info.name)}</span>`));
        this.count(pid, RULES.awardPoints);
        this.root.querySelector(`.gcol[data-pid="${pid}"]`)!.classList.add('flash');
        setTimeout(() => this.root.querySelector(`.gcol[data-pid="${pid}"]`)?.classList.remove('flash'), 900);
      }
      if (aw.winners.length) this.audio.sparkle();
      await this.wait(1500);
    }

    // Act III: francs.
    this.setAct('Act III · The Purse', `+1 prestige for every ${RULES.francsPerPoint} ₣ left over`);
    for (const p of v.players) {
      const r = result(p.id);
      if (r.francPoints > 0) {
        const items = this.root.querySelector(`.gcol[data-pid="${p.id}"] .gcol-items`)!;
        items.appendChild(el('div', 'gi franc', `${icon('coin')}<span>${r.francs} ₣</span>`));
        this.count(p.id, r.francPoints);
      }
    }
    this.audio.coin();
    await this.wait(1500);

    // Act IV: secret patrons, from the lowest score so far up to the leader.
    this.setAct('Act IV · The Secret Patrons', 'Who was each artist really painting for?');
    await this.wait(1200);
    const order = [...v.players].sort((a, b) => (this.scores.get(a.id) ?? 0) - (this.scores.get(b.id) ?? 0));
    for (const p of order) {
      const r = result(p.id);
      const items = this.root.querySelector(`.gcol[data-pid="${p.id}"] .gcol-items`)!;
      const flip = el('div', 'gi patron-flip', `<div class="flip-inner"><div class="flip-front">${patronCard(null, 'small')}</div><div class="flip-back">${patronCard(r.patron, 'small')}</div></div>`);
      items.appendChild(flip);
      await this.wait(500);
      flip.classList.add('flipped');
      this.audio.paper();
      await this.wait(700);
      if (r.patronPoints > 0) this.count(p.id, r.patronPoints);
      this.audio.sparkle();
      await this.wait(1300);
    }

    // Make sure every column shows the official total.
    for (const r of res.players) {
      const node = this.root.querySelector<HTMLElement>(`.gcol[data-pid="${r.pid}"] .gcol-score b`);
      if (node) node.textContent = String(r.total);
      this.scores.set(r.pid, r.total);
    }

    // Finale.
    this.skipping = false;
    this.setAct('And the laureate of the Art Society is…');
    this.audio.drumroll(2.4);
    await this.wait(2700);
    this.showFinal(v, res, byId, me);
    this.audio.fanfare();
    const ranked = res.players.map((r) => r.pid);
    await this.world.podium(ranked);
    for (const w of res.winners) this.world.celebrate(w, v.players.map((p) => p.color).concat(['#e2c27a', '#ffffff']));
  }

  private showFinal(v: GameView, res: GameResults, byId: Map<string, PlayerState>, me: string | null) {
    const winners = res.winners.map((id) => byId.get(id)!).filter(Boolean);
    const top = res.players[0];
    const tie = winners.length > 1;
    const rows = res.players
      .map((r: PlayerResult) => {
        const p = byId.get(r.pid)!;
        return `<tr class="${res.winners.includes(r.pid) ? 'win' : ''} ${r.pid === me ? 'me' : ''}">
          <td class="rk">${r.rank}</td><td class="nm">${dot(p.color)}${esc(p.name)}</td>
          <td>${r.artPoints}</td><td>${r.awardPoints}</td><td title="${esc(r.patron ? PATRONS[r.patron].name : '')}">${r.patronPoints}</td><td>${r.francPoints}</td><td class="tot">${r.total}</td></tr>`;
      })
      .join('');
    const host = this.isHost();
    const final = el(
      'div',
      'gala-final',
      `<div class="gf-kicker">${tie ? 'A tie! The laurels are shared by' : 'The new laureate of the Art Society'}</div>
       <div class="gf-name">${winners.map((w) => `<span style="--pc:${w.color}">${esc(w.name)}</span>`).join(' & ')}</div>
       <div class="gf-score">${top.total} prestige${winners.some((w) => w.id === me) ? ' · Congratulations!' : ''}</div>
       <table class="gf-table"><thead><tr><th></th><th>Artist</th><th>Art</th><th>Awards</th><th>Patron</th><th>Purse</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>
       <div class="gf-actions">
         <button class="btn ghost admire">${icon('camera')} Admire the galleries</button>
         ${host ? '<button class="btn primary again">Back to the lobby</button>' : '<span class="waiting">The host can start a new season.</span>'}
       </div>`,
    );
    this.root.querySelector('.gala-foot')?.remove();
    this.root.appendChild(final);
    this.root.classList.add('finale');
    final.querySelector('.admire')!.addEventListener('click', () => {
      this.root.classList.remove('show');
      this.reopen.classList.add('show');
      this.hudHidden(false);
    });
    final.querySelector('.again')?.addEventListener('click', () => this.onLobby());
    void v;
  }
}
