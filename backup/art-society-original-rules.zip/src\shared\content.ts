import type {
  Artwork,
  AwardId,
  EventId,
  MovementId,
  PatronId,
  Pigment,
  PigmentSet,
  Space,
  SpaceType,
} from './types';
import { MOVEMENTS, PIGMENTS } from './types';
import { hashString, pick, shuffle, type Rand } from './rng';

/** Every tunable number of the game lives here. */
export const RULES = {
  boardSize: 24,
  startFrancs: 5,
  startPigments: 2,
  startInspiration: 1,
  startHand: 3,
  handLimit: 5,
  /** Spare pigments needed to mix one missing pigment. */
  mixRatio: 2,
  hallSalary: 2,
  hallInspiration: 1,
  pigmentGain: 3,
  patronGain: 3,
  museInspiration: 1,
  shopMax: 4,
  shopPrice: 1,
  maxInspiration: 5,
  trendMin: 0,
  trendMax: 3,
  trendStart: 1,
  awardPoints: 5,
  francsPerPoint: 3,
  rowSize: 3,
  auctionSeconds: 30,
  patronSeconds: 45,
  roundOptions: [6, 8, 10, 12],
  defaultRounds: 10,
  minPlayers: 2,
  maxPlayers: 6,
} as const;

export interface MovementDef {
  name: string;
  short: string;
  color: string;
  blurb: string;
}

export const MOVEMENT_INFO: Record<MovementId, MovementDef> = {
  impressionism: {
    name: 'Impressionism',
    short: 'Impression',
    color: '#a99be8',
    blurb: 'Light caught in quick, shimmering dabs.',
  },
  postimpressionism: {
    name: 'Post-Impressionism',
    short: 'Post-Imp.',
    color: '#4f7cf0',
    blurb: 'Restless skies and thick, swirling strokes.',
  },
  cubism: {
    name: 'Cubism',
    short: 'Cubism',
    color: '#c99a52',
    blurb: 'The world broken into facets and seen from every side.',
  },
  ukiyoe: {
    name: 'Ukiyo-e',
    short: 'Ukiyo-e',
    color: '#e0644f',
    blurb: 'Woodblock waves, mountains and blossoms of the floating world.',
  },
  abstract: {
    name: 'Abstract',
    short: 'Abstract',
    color: '#34b3a0',
    blurb: 'Pure colour, line and rhythm.',
  },
};

export const PIGMENT_INFO: Record<Pigment, { name: string; color: string; light: string }> = {
  red: { name: 'Crimson', color: '#c8323c', light: '#ff7b7b' },
  blue: { name: 'Ultramarine', color: '#2b5bc8', light: '#7aa2ff' },
  yellow: { name: 'Saffron', color: '#e9b530', light: '#ffe08a' },
};

export const PLAYER_COLORS = [
  '#e4572e',
  '#3a86ff',
  '#2fbf71',
  '#ffbe0b',
  '#9b5de5',
  '#f15bb5',
  '#14b8a6',
  '#f1e9d2',
] as const;

export const BOT_NAMES = [
  'Vincent van Bot',
  'Pablo Pixasso',
  'Frida Kahlobot',
  'Claude Monay',
  'Salvador Dalibot',
  "Georgia O'Keybot",
  'Henri Matissbot',
  'Edgar Degauss',
];

export interface SpaceDef {
  name: string;
  short: string;
  text: string;
  color: string;
}

const SPACE_INFO: Record<SpaceType, SpaceDef> = {
  hall: {
    name: 'Society Hall',
    short: 'Hall',
    text: `Pass it: +${RULES.hallSalary} ₣ stipend. Land on it: also +${RULES.hallInspiration} ✦ inspiration.`,
    color: '#efe3c4',
  },
  pigment: { name: 'Pigment', short: 'Pigment', text: '', color: '#ffffff' },
  muse: {
    name: 'The Muse',
    short: 'Muse',
    text: `Take a sketch from the Muse row or draw one blind, and gain +${RULES.museInspiration} ✦.`,
    color: '#8e7cc3',
  },
  shop: {
    name: 'Art Supplier',
    short: 'Supplier',
    text: `Buy up to ${RULES.shopMax} pigments for ${RULES.shopPrice} ₣ each.`,
    color: '#2a9d8f',
  },
  patron: {
    name: "Patron's Salon",
    short: 'Patron',
    text: `A patron commissions you: +${RULES.patronGain} ₣.`,
    color: '#c9a227',
  },
  auction: {
    name: 'Auction House',
    short: 'Auction',
    text: 'A masterpiece goes under the hammer. Everyone bids in secret; highest bid wins.',
    color: '#7b2d43',
  },
  gazette: {
    name: 'The Gazette',
    short: 'Gazette',
    text: 'Write a review: praise one movement (trend +1) and pan another (trend −1).',
    color: '#4a5568',
  },
  soiree: {
    name: 'Soirée',
    short: 'Soirée',
    text: 'Draw a soirée card: gifts, gossip and scandal.',
    color: '#d76a8a',
  },
};

const PIGMENT_SPACE_NAMES: Record<Pigment, string> = {
  red: 'Crimson Market',
  blue: 'Ultramarine Docks',
  yellow: 'Saffron Fields',
};

export function spaceInfo(space: Space): SpaceDef {
  if (space.type === 'pigment' && space.pigment) {
    const p = PIGMENT_INFO[space.pigment];
    return {
      name: PIGMENT_SPACE_NAMES[space.pigment],
      short: p.name,
      text: `Gather +${RULES.pigmentGain} ${p.name.toLowerCase()} pigment.`,
      color: p.color,
    };
  }
  return SPACE_INFO[space.type];
}

const P = (pigment: Pigment): Space => ({ type: 'pigment', pigment });
const S = (type: SpaceType): Space => ({ type });

/** The 24 spaces of the boulevard, clockwise from the Society Hall. */
export const BOARD: Space[] = [
  S('hall'), P('red'), S('muse'), S('patron'), P('blue'), S('gazette'),
  S('auction'), P('yellow'), S('soiree'), S('shop'), S('muse'), P('red'),
  S('patron'), S('gazette'), P('blue'), S('auction'), S('soiree'), P('yellow'),
  S('muse'), S('patron'), S('shop'), S('gazette'), S('auction'), S('soiree'),
];

export interface PatronDef {
  name: string;
  title: string;
  text: string;
}

export const PATRONS: Record<PatronId, PatronDef> = {
  lumiere: { name: 'Madame Lumière', title: 'Devotee of Impressionism', text: '+3 per Impressionist work' },
  vincenzo: { name: 'Count Vincenzo', title: 'Collector of Night Skies', text: '+3 per Post-Impressionist work' },
  vogel: { name: 'Herr Vogel', title: 'Champion of Cubism', text: '+3 per Cubist work' },
  sakura: { name: 'Lady Sakura', title: 'Keeper of the Floating World', text: '+3 per Ukiyo-e work' },
  kandin: { name: 'Professor Kandin', title: 'Prophet of Abstraction', text: '+3 per Abstract work' },
  curator: { name: 'The Grand Curator', title: 'Lover of Variety', text: '+2 per different movement in your collection' },
  baron: { name: 'Baron von Gold', title: 'Banker of the Society', text: '+1 per ₣ you hold at the end' },
  marteau: { name: 'Madame Marteau', title: 'Queen of the Auction House', text: '+5 per masterpiece' },
  plenty: { name: 'The Muse of Plenty', title: 'Friend of the Prolific', text: '+2 per sketch you painted yourself' },
  aurelius: { name: 'Sir Aurelius', title: 'Seeker of Grandeur', text: '+3 per artwork with base value 5 or more' },
  vogue: { name: 'Mademoiselle Vogue', title: 'Arbiter of Fashion', text: '+3 per artwork whose movement ends at trend 2 or more' },
  pur: { name: 'The Duval Twins', title: 'Collectors of Pairs', text: '+4 per pair of artworks from the same movement' },
};

export const PATRON_IDS = Object.keys(PATRONS) as PatronId[];

/** Movement favoured by a movement patron, if any. */
export const PATRON_MOVEMENT: Partial<Record<PatronId, MovementId>> = {
  lumiere: 'impressionism',
  vincenzo: 'postimpressionism',
  vogel: 'cubism',
  sakura: 'ukiyoe',
  kandin: 'abstract',
};

export interface AwardDef {
  name: string;
  text: string;
}

export function awardInfo(id: AwardId): AwardDef {
  if (id.startsWith('master:')) {
    const m = MOVEMENT_INFO[id.slice(7) as MovementId];
    return { name: `Master of ${m.name}`, text: `Most ${m.name} works` };
  }
  const defs: Record<string, AwardDef> = {
    prolific: { name: 'The Prolific Brush', text: 'Most artworks' },
    connoisseur: { name: 'The Connoisseur', text: 'Most masterpieces' },
    eclectic: { name: 'The Eclectic Eye', text: 'Most different movements' },
    tycoon: { name: 'The Tycoon', text: 'Most francs at the end' },
    visionary: { name: 'The Visionary', text: 'Most valuable single artwork' },
    benefactor: { name: 'Patron of the Arts', text: 'Most francs spent at auction' },
  };
  return defs[id];
}

export const GENERAL_AWARDS: AwardId[] = ['prolific', 'connoisseur', 'eclectic', 'tycoon', 'visionary', 'benefactor'];

export const EVENTS: Record<EventId, { title: string; text: string }> = {
  benefactor: { title: 'A Generous Benefactor', text: 'An admirer slips you 4 ₣.' },
  spill: { title: 'Spilled Turpentine!', text: 'You lose 2 pigments from your largest pile.' },
  buzz: { title: 'Salon Buzz', text: 'Everyone is talking about one movement: its trend rises.' },
  scandal: { title: 'Scandal at the Salon', text: 'A movement falls out of favour: its trend drops.' },
  artfair: { title: 'The Art Fair', text: 'Every artist picks up 1 random pigment.' },
  moonlit: { title: 'Moonlit Inspiration', text: 'You gain 2 ✦ inspiration.' },
  tax: { title: 'The Tax Collector', text: 'Every artist holding 8 ₣ or more pays 2 ₣.' },
  attic: { title: 'Treasure in the Attic', text: 'Draw a sketch from the deck (or +2 ₣ if your hand is full).' },
  dinner: { title: "The Patrons' Dinner", text: 'Every artist gains 2 ₣.' },
  fashion: { title: 'Fickle Fashion', text: 'The most fashionable movement drops, the least fashionable rises.' },
  shipment: { title: 'Shipment from Marseille', text: 'You gain 1 pigment of each colour.' },
  envy: { title: 'A Wager Won', text: 'The richest other artist pays you 2 ₣.' },
  studiovisit: { title: 'A Critic Visits Your Studio', text: 'Your most collected movement gains +1 trend.' },
};

export const EVENT_DECK: EventId[] = [
  'benefactor', 'benefactor', 'spill', 'buzz', 'buzz', 'scandal', 'scandal', 'artfair', 'moonlit',
  'tax', 'attic', 'attic', 'dinner', 'fashion', 'shipment', 'shipment', 'envy', 'studiovisit',
];

const MASTERPIECES: { title: string; artist: string; movement: MovementId; value: number }[] = [
  { title: 'The Lily Pond at Dawn', artist: 'Céleste Moreau', movement: 'impressionism', value: 5 },
  { title: 'Boating Party at Chatou', artist: 'Henri Lavigne', movement: 'impressionism', value: 6 },
  { title: 'The Weeping Lighthouse', artist: 'Céleste Moreau', movement: 'impressionism', value: 7 },
  { title: 'Restless Night over Arles', artist: 'Theo van Brugge', movement: 'postimpressionism', value: 6 },
  { title: 'Sunflowers for the Absent', artist: 'Theo van Brugge', movement: 'postimpressionism', value: 5 },
  { title: 'Guitarist in Fragments', artist: 'Pablo Quintero', movement: 'cubism', value: 6 },
  { title: 'Cathedral, Refracted', artist: 'Georges Braquet', movement: 'cubism', value: 7 },
  { title: 'Still Life with Broken Mirror', artist: 'Georges Braquet', movement: 'cubism', value: 5 },
  { title: 'The Wave and the Mountain', artist: 'Hokuren', movement: 'ukiyoe', value: 7 },
  { title: 'Thirty-Six Views of Dusk', artist: 'Andō Kisaburō', movement: 'ukiyoe', value: 5 },
  { title: 'Composition in Crimson and Gold', artist: 'Piet Dormaal', movement: 'abstract', value: 6 },
  { title: 'Yellow Sound', artist: 'Vassily Kandor', movement: 'abstract', value: 7 },
];

const TITLES: Record<MovementId, [string[], string[]]> = {
  impressionism: [
    ['Water Lilies', 'Poppies', 'Morning Mist', 'The Garden', 'Sailboats', 'Haystacks', 'The Footbridge', 'Woman with a Parasol', 'Willows', 'The Harbour', 'Luncheon', 'Sunlight'],
    ['at Giverny', 'near Argenteuil', 'on the Seine', 'at Dawn', 'in Late Summer', 'at Honfleur', 'after the Rain', 'in Spring', 'at Étretat', 'by the Pond'],
  ],
  postimpressionism: [
    ['Cypresses', 'Wheatfield', 'Sunflowers', 'The Night Café', 'Starlit Village', 'Olive Grove', 'The Yellow House', 'Irises', 'Café Terrace', 'Road with Cypress'],
    ['under a Restless Sky', 'with Crows', 'at Arles', 'in Saint-Rémy', 'at Midnight', 'in the Mistral', 'by Lamplight', 'at Harvest'],
  ],
  cubism: [
    ['Still Life', 'Woman', 'Guitar', 'Violin', 'The Card Players', 'Bottle', 'Harlequin', 'The Poet', 'Pipe and Glass', 'The Clarinettist'],
    ['with Mandolin', 'in Fragments', 'and Newspaper', 'Refracted', 'in Ochre', 'at the Café', 'Seen Twice', 'in Grey and Gold'],
  ],
  ukiyoe: [
    ['Great Wave', 'Red Fuji', 'Plum Blossoms', 'Cranes', 'Evening Snow', 'Fishermen', 'Moonlit Bridge', 'Cherry Blossoms', 'Lone Pine', 'Sudden Rain'],
    ['off Kanagawa', 'at Dawn', 'over Edo Bay', 'at Kameido', 'on the Tōkaidō', 'beneath Mount Fuji', 'in Moonlight', 'at Ōji'],
  ],
  abstract: [
    ['Yellow', 'Crimson', 'Indigo', 'Violet', 'Orange', 'Blue', 'Black', 'Golden'],
    ['Rhythm', 'Sound', 'Circles', 'Accent', 'Fugue', 'Field', 'Harmony', 'Lines', 'Boogie', 'Square'],
  ],
};

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];

function makeTitle(r: Rand, movement: MovementId, used: Set<string>): string {
  const [a, b] = TITLES[movement];
  for (let i = 0; i < 20; i++) {
    let t: string;
    if (movement === 'abstract' && r() < 0.3) t = `Composition No. ${pick(r, ROMAN)}`;
    else t = `${pick(r, a)} ${pick(r, b)}`;
    if (!used.has(t)) {
      used.add(t);
      return t;
    }
  }
  const t = `${pick(r, a)} (Study ${used.size})`;
  used.add(t);
  return t;
}

/** Pigment preference per movement: [red, blue, yellow]. */
const PALETTE_WEIGHTS: Record<MovementId, [number, number, number]> = {
  impressionism: [0.2, 0.4, 0.4],
  postimpressionism: [0.15, 0.45, 0.4],
  cubism: [0.4, 0.2, 0.4],
  ukiyoe: [0.35, 0.5, 0.15],
  abstract: [0.34, 0.33, 0.33],
};

/** Canvas sizes per movement: pigments needed -> base prestige. */
const CANVAS_SIZES = [2, 2, 2, 3, 3, 3, 4, 4, 5];
export const VALUE_FOR_SIZE: Record<number, number> = { 2: 2, 3: 3, 4: 5, 5: 7 };

export function emptyPigments(): PigmentSet {
  return { red: 0, blue: 0, yellow: 0 };
}

function weightedPigment(r: Rand, w: [number, number, number]): Pigment {
  const x = r() * (w[0] + w[1] + w[2]);
  if (x < w[0]) return 'red';
  if (x < w[0] + w[1]) return 'blue';
  return 'yellow';
}

export function buildCanvasDeck(r: Rand): Artwork[] {
  const used = new Set<string>();
  const deck: Artwork[] = [];
  let n = 0;
  for (const movement of MOVEMENTS) {
    for (const size of CANVAS_SIZES) {
      const cost = emptyPigments();
      for (let i = 0; i < size; i++) cost[weightedPigment(r, PALETTE_WEIGHTS[movement])]++;
      // Larger canvases always need at least two colours.
      if (size >= 3 && PIGMENTS.filter((p) => cost[p] > 0).length < 2) {
        const main = PIGMENTS.find((p) => cost[p] > 0)!;
        const other = PIGMENTS.filter((p) => p !== main);
        cost[main]--;
        cost[pick(r, other)]++;
      }
      const title = makeTitle(r, movement, used);
      deck.push({
        id: `c${n++}`,
        kind: 'canvas',
        title,
        movement,
        cost,
        value: VALUE_FOR_SIZE[size],
        seed: Math.floor(r() * 2 ** 31),
      });
    }
  }
  return shuffle(r, deck);
}

export function buildLotDeck(r: Rand): Artwork[] {
  return shuffle(
    r,
    MASTERPIECES.map((m, i) => ({
      id: `m${i}`,
      kind: 'masterpiece' as const,
      title: m.title,
      artist: m.artist,
      movement: m.movement,
      cost: emptyPigments(),
      value: m.value,
      seed: hashString(m.title),
    })),
  );
}
