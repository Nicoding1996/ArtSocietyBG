/**
 * Balance simulator: plays many bot-only games and prints statistics.
 * Usage: npm run sim -- [games=400] [rounds=10]
 */
import { playBotGame } from './botgame';
import type { PatronId } from '../src/shared/types';

const games = Number(process.argv[2] ?? 400);
const rounds = Number(process.argv[3] ?? 10);

for (const n of [2, 3, 4, 5, 6]) {
  let totalScore = 0;
  let winScore = 0;
  let art = 0;
  let masterpieces = 0;
  let auctions = 0;
  let spread = 0;
  const patronWins = new Map<PatronId, number>();
  const patronSeen = new Map<PatronId, number>();
  const parts = { art: 0, awards: 0, patron: 0, francs: 0 };
  const left = { pigments: 0, hand: 0, francs: 0, inspiration: 0 };
  for (let g = 0; g < games; g++) {
    const { s, auctions: a } = playBotGame(1000 + g * 7919 + n, n, rounds);
    auctions += a;
    for (const p of s.players) {
      left.pigments += p.pigments.red + p.pigments.blue + p.pigments.yellow;
      left.hand += p.hand.length;
      left.francs += p.francs;
      left.inspiration += p.inspiration;
    }
    const res = s.results!;
    for (const pr of res.players) {
      totalScore += pr.total;
      art += pr.art.length;
      masterpieces += pr.art.filter((x) => x.kind === 'masterpiece').length;
      parts.art += pr.artPoints;
      parts.awards += pr.awardPoints;
      parts.patron += pr.patronPoints;
      parts.francs += pr.francPoints;
      patronSeen.set(pr.patron!, (patronSeen.get(pr.patron!) ?? 0) + 1);
    }
    const top = res.players[0];
    winScore += top.total;
    spread += top.total - res.players[res.players.length - 1].total;
    for (const w of res.winners) {
      const pr = res.players.find((x) => x.pid === w)!;
      patronWins.set(pr.patron!, (patronWins.get(pr.patron!) ?? 0) + 1 / res.winners.length);
    }
  }
  const pc = games * n;
  console.log(`\n=== ${n} players, ${rounds} rounds, ${games} games ===`);
  console.log(
    `avg score ${(totalScore / pc).toFixed(1)} | winner ${(winScore / games).toFixed(1)} | spread ${(spread / games).toFixed(1)} | artworks/player ${(art / pc).toFixed(2)} | masterpieces/player ${(masterpieces / pc).toFixed(2)} | auctions/game ${(auctions / games).toFixed(1)}`,
  );
  console.log(
    `points from: art ${(parts.art / pc).toFixed(1)}, awards ${(parts.awards / pc).toFixed(1)}, patron ${(parts.patron / pc).toFixed(1)}, francs ${(parts.francs / pc).toFixed(1)}`,
  );
  console.log(
    `left at end: pigments ${(left.pigments / pc).toFixed(1)}, sketches ${(left.hand / pc).toFixed(1)}, francs ${(left.francs / pc).toFixed(1)}, inspiration ${(left.inspiration / pc).toFixed(1)}`,
  );
  const rows = [...patronSeen.entries()]
    .map(([id, seen]) => ({ id, rate: (patronWins.get(id) ?? 0) / seen }))
    .sort((a, b) => b.rate - a.rate)
    .map((x) => `${x.id} ${(x.rate * n * 100).toFixed(0)}%`);
  console.log(`patron win rate vs fair share (100% = fair): ${rows.join(', ')}`);
}
