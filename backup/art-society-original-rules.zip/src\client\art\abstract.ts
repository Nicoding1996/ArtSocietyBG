import { brush, finish, hexToHsl, hsl, jit, type Painter } from './common';

export function abstract(p: Painter) {
  const v = p.r();
  if (v < 0.33) mondrian(p);
  else if (v < 0.7) kandinsky(p);
  else rothko(p);
}

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

function mondrian(p: Painter) {
  const { c, w, h } = p;
  c.fillStyle = '#f1ede3';
  c.fillRect(0, 0, w, h);
  let rects: Rect[] = [{ x: 0, y: 0, w, h }];
  const cuts = p.ri(7, 11);
  for (let i = 0; i < cuts; i++) {
    rects.sort((a, b) => b.w * b.h - a.w * a.h);
    const k = Math.floor(Math.pow(p.r(), 1.6) * Math.min(rects.length, 4));
    const r = rects[k];
    const vertical = r.w > r.h ? p.r() < 0.75 : p.r() < 0.25;
    const t = p.rr(0.25, 0.75);
    rects.splice(k, 1);
    if (vertical) rects.push({ x: r.x, y: r.y, w: r.w * t, h: r.h }, { x: r.x + r.w * t, y: r.y, w: r.w * (1 - t), h: r.h });
    else rects.push({ x: r.x, y: r.y, w: r.w, h: r.h * t }, { x: r.x, y: r.y + r.h * t, w: r.w, h: r.h * (1 - t) });
  }
  rects = rects.sort(() => p.r() - 0.5);
  const colors = ['#d62a26', '#1f4f9e', '#f2c230', '#d62a26', '#1f4f9e', '#f2c230', '#191919', '#dcd8cc'];
  const filled = p.ri(3, 5);
  rects.forEach((r, i) => {
    const col = i < filled ? colors[(i + p.ri(0, 7)) % colors.length] : '#f1ede3';
    c.fillStyle = col;
    c.fillRect(r.x, r.y, r.w, r.h);
    const base = hexToHsl(col);
    for (let k = 0; k < (r.w * r.h) / 900; k++) {
      brush(p, r.x + p.rr(0, r.w), r.y + p.rr(0, r.h), p.r() < 0.5 ? 0 : Math.PI / 2, p.rr(10, 30), p.rr(3, 7), jit(p, base, 3, 5, 4), 0.18);
    }
  });
  const lw = p.rr(8, 12);
  c.strokeStyle = '#151515';
  c.lineWidth = lw;
  for (const r of rects) c.strokeRect(r.x, r.y, r.w, r.h);
  finish(p, { weave: 5, grain: 8, vignette: 0.12, warm: 0.25 });
}

const KPAL = ['#d62828', '#f77f00', '#fcbf49', '#003049', '#2a9d8f', '#6a4c93', '#1b1b1b', '#e9c46a', '#457b9d', '#e76f51'];

function kandinsky(p: Painter) {
  const { c, w, h } = p;
  const g = c.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, '#efe5cf');
  g.addColorStop(1, '#ddcaa6');
  c.fillStyle = g;
  c.fillRect(0, 0, w, h);
  for (let i = 0; i < 5; i++) {
    const x = p.rr(0, w);
    const y = p.rr(0, h);
    const rg = c.createRadialGradient(x, y, 0, x, y, p.rr(80, 200));
    rg.addColorStop(0, hsl(p.rr(0, 360), 50, 70, 0.35));
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = rg;
    c.fillRect(0, 0, w, h);
  }
  // Lines first, shapes over them.
  for (let i = 0; i < p.ri(7, 13); i++) {
    c.strokeStyle = p.r() < 0.7 ? '#1b1b1b' : p.pick(KPAL);
    c.lineWidth = p.pick([1.2, 2, 3, 5, 7]);
    c.beginPath();
    const x = p.rr(0, w);
    const y = p.rr(0, h);
    const a = p.rr(0, Math.PI);
    const l = p.rr(80, 320);
    c.moveTo(x - Math.cos(a) * l, y - Math.sin(a) * l);
    c.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
    c.stroke();
  }
  // The big haloed circle.
  const bx = p.rr(0.25, 0.75) * w;
  const by = p.rr(0.2, 0.5) * h;
  const br = p.rr(0.14, 0.22) * w;
  c.fillStyle = 'rgba(20,20,30,0.85)';
  c.beginPath();
  c.arc(bx, by, br * 1.25, 0, Math.PI * 2);
  c.fill();
  for (let k = 0; k < p.ri(3, 5); k++) {
    c.fillStyle = p.pick(KPAL);
    c.beginPath();
    c.arc(bx + p.rr(-4, 4), by + p.rr(-4, 4), br * (1 - k * 0.22), 0, Math.PI * 2);
    c.fill();
  }
  for (let i = 0; i < p.ri(8, 14); i++) {
    c.globalAlpha = p.rr(0.75, 0.95);
    c.fillStyle = p.pick(KPAL);
    const r = p.rr(6, 40);
    const x = p.rr(0, w);
    const y = p.rr(0, h);
    c.beginPath();
    c.arc(x, y, r, 0, Math.PI * 2);
    c.fill();
    if (p.r() < 0.5) {
      c.strokeStyle = '#1b1b1b';
      c.lineWidth = 1.5;
      c.stroke();
    }
    c.globalAlpha = 1;
  }
  for (let i = 0; i < p.ri(2, 4); i++) {
    c.fillStyle = p.pick(KPAL);
    const x = p.rr(0, w);
    const y = p.rr(0, h);
    const s = p.rr(30, 90);
    const a = p.rr(0, Math.PI * 2);
    c.beginPath();
    for (let k = 0; k < 3; k++) c.lineTo(x + Math.cos(a + (k * Math.PI * 2) / 3) * s, y + Math.sin(a + (k * Math.PI * 2) / 3) * s * p.rr(0.5, 1));
    c.closePath();
    c.fill();
  }
  for (let i = 0; i < p.ri(2, 5); i++) {
    c.strokeStyle = p.pick(KPAL);
    c.lineWidth = p.rr(3, 9);
    c.beginPath();
    c.arc(p.rr(0, w), p.rr(0, h), p.rr(30, 110), p.rr(0, 6), p.rr(0, 6));
    c.stroke();
  }
  if (p.r() < 0.6) {
    const x = p.rr(0.1, 0.8) * w;
    const y = p.rr(0.1, 0.85) * h;
    const s = p.rr(7, 12);
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        c.fillStyle = (i + j) % 2 ? '#1b1b1b' : '#f5f0e6';
        c.fillRect(x + i * s, y + j * s, s, s);
      }
    }
  }
  finish(p, { weave: 6, grain: 10, vignette: 0.2, warm: 0.2 });
}

const ROTHKO = [
  ['#4f1414', '#e2702a', '#b8321f', '#7b1f12'],
  ['#18233a', '#3f6fb5', '#0c111e', '#24385e'],
  ['#c84b31', '#f2b134', '#7a1f1f', '#e98a3b'],
  ['#2f4f3f', '#8fb996', '#1b2a22', '#4e7a5f'],
  ['#5b2350', '#f05d5e', '#2b1b2a', '#c74a7b'],
  ['#1d1d1f', '#6b2d2d', '#2c2c35', '#a1432f'],
];

function rothko(p: Painter) {
  const { c, w, h } = p;
  const pal = p.pick(ROTHKO);
  c.fillStyle = pal[0];
  c.fillRect(0, 0, w, h);
  const bg = hexToHsl(pal[0]);
  for (let i = 0; i < 500; i++) brush(p, p.rr(0, w), p.rr(0, h), p.rr(-0.2, 0.2), p.rr(30, 90), p.rr(8, 20), jit(p, bg, 4, 6, 5), 0.08);
  const n = p.ri(2, 3);
  const margin = w * 0.09;
  const gap = h * 0.035;
  const weights = Array.from({ length: n }, () => p.rr(0.6, 1.6));
  const total = weights.reduce((a, b) => a + b, 0);
  let y = h * 0.06;
  const usable = h * 0.88 - gap * (n - 1);
  weights.forEach((wt, i) => {
    const rh = (usable * wt) / total;
    const col = hexToHsl(pal[1 + (i % 3)]);
    for (let layer = 0; layer < 16; layer++) {
      const inset = p.rr(-6, 10);
      c.globalAlpha = 0.09;
      c.fillStyle = hsl(col[0] + p.rr(-4, 4), col[1], col[2] + p.rr(-6, 6));
      c.beginPath();
      c.roundRect(margin + inset, y + inset, w - 2 * (margin + inset), rh - 2 * inset, 14);
      c.fill();
    }
    c.globalAlpha = 1;
    for (let k = 0; k < (rh * w) / 260; k++) {
      brush(p, p.rr(margin + 8, w - margin - 8), p.rr(y + 8, y + rh - 8), p.rr(-0.15, 0.15), p.rr(20, 60), p.rr(6, 14), jit(p, col, 4, 6, 7), 0.07);
    }
    y += rh + gap;
  });
  finish(p, { weave: 6, grain: 12, vignette: 0.3, warm: 0.15 });
}
