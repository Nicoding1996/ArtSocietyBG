import * as THREE from 'three';
import { RULES } from '../../shared/content';

/** Board dimensions in world units. The board's top face is y = 0. */
export const L = {
  boardR: 13,
  boardH: 0.8,
  trackIn: 9.4,
  trackOut: 11.8,
  trackMid: 10.6,
  tileTop: 0.26,
  daisR: 7.5,
  daisTop: 0.42,
  tier2R: 5.35,
  tier2Top: 0.8,
  plinthR: 3.1,
  plinthTop: 1.15,
  rows: [
    { r: 6.45, y: 0.42 },
    { r: 4.5, y: 0.8 },
  ],
  trendR: 2.05,
};

export const TAU = Math.PI * 2;

/** Angle of a board space; space 0 faces the default camera and play runs clockwise seen from above. */
export const spaceAngle = (i: number) => Math.PI / 2 + i * (TAU / RULES.boardSize);

export const polar = (r: number, a: number, y = 0) => new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r);

/** rotation.y that makes an object's +z face point outward at angle `a`. */
export const faceOut = (a: number) => Math.PI / 2 - a;

/** Where the k-th of n pawns stands on a space. */
export function pawnSpot(space: number, k: number, n: number): THREE.Vector3 {
  const a = spaceAngle(space);
  const c = polar(L.trackMid, a, L.tileTop);
  if (n <= 1) return c;
  const radius = n === 2 ? 0.42 : n <= 4 ? 0.56 : 0.72;
  const local = (k / n) * TAU + (n === 2 ? 0 : Math.PI / 2);
  // Offsets in the tile's own frame: radial (towards the centre) and tangential.
  const radial = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
  const tangent = new THREE.Vector3(-Math.sin(a), 0, Math.cos(a));
  return c.addScaledVector(tangent, Math.cos(local) * radius).addScaledVector(radial, Math.sin(local) * radius * 0.8);
}
