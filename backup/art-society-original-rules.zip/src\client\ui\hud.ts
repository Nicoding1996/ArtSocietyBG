import { MOVEMENT_INFO, RULES, awardInfo } from '../../shared/content';
import { mixedCount, paymentFor } from '../../shared/engine';
import { evaluateAwards, visiblePrestige } from '../../shared/scoring';
import { MOVEMENTS, type Artwork, type GameView, type PlayerState } from '../../shared/types';
import { artImg } from '../art/generate';
import { el, esc, renderIf } from './dom';
import { icon } from './icons';
import { artCard, dot, francs, insp, patronCard, pig, prestige, trendStars } from './parts';
import type { ChatPanel } from './chat';

export interface HudHandlers {
  onPaint(artId: string): void;
  onArt(art: Artwork, owner?: PlayerState): void;
  onHelp(): void;
  onLeave(): void;
  onToggle(what: 'sfx' | 'music' | 'follow'): void;
  toggles(): { sfx: boolean; music: boolean; follow: boolean };
}

export class Hud {
  readonly root = el('div', 'hud');
  private top = el('div', 'topbar');
  private players = el('div', 'players');
  private side = el('div', 'side');
  private trends = el('div', 'trends panel');
  private awards = el('div', 'awards panel');
  private muse = el('div', 'muse panel');
  private studio = el('div', 'studio');
  readonly promptSlot = el('div', 'prompt-slot');

  constructor(
    private h: HudHandlers,
    chat: ChatPanel,
  ) {
    this.side.append(this.trends, this.awards, this.muse, chat.root);
    this.root.append(this.top, this.players, this.side, this.promptSlot, this.studio);
  }

  render(v: GameView, me: string | null) {
    this.renderTop(v, me);
    this.renderPlayers(v, me);
    this.renderTrends(v);
    this.renderAwards(v);
    this.renderMuse(v);
    this.renderStudio(v, me);
  }

  refreshToggles() {
    this.top.dataset.sig = '';
  }

  private renderTop(v: GameView, me: string | null) {
    const active = v.players[v.turn];
    const t = this.h.toggles();
    const phase = v.phase.kind;
    let status: string;
    if (phase === 'patrons') status = 'Choosing secret patrons…';
    else if (phase === 'over') status = 'The Grand Gala';
    else if (phase === 'auction') status = `${icon('gavel')} Auction in progress`;
    else if (active.id === me) status = `<b class="you">Your turn</b>`;
    else status = `${dot(active.color)} <b>${esc(active.name)}</b>&nbsp;is playing…`;
    const sig = JSON.stringify([v.round, v.totalRounds, status, t]);
    renderIf(this.top, sig, () => {
      const final = v.round === v.totalRounds && phase !== 'over';
      this.top.innerHTML = `
        <div class="tb-left"><span class="logo">Art Society</span><span class="round ${final ? 'final' : ''}">${phase === 'patrons' ? 'Prelude' : final ? `Final round · ${v.round}/${v.totalRounds}` : `Round ${v.round} / ${v.totalRounds}`}</span></div>
        <div class="tb-center">${status}</div>
        <div class="tb-right">
          <button class="icon-btn" data-a="help" title="How to play">${icon('help')}</button>
          <button class="icon-btn ${t.follow ? 'on' : ''}" data-a="follow" title="Camera follows the action">${icon('camera')}</button>
          <button class="icon-btn ${t.sfx ? 'on' : ''}" data-a="sfx" title="Sound effects">${icon(t.sfx ? 'sound' : 'mute')}</button>
          <button class="icon-btn ${t.music ? 'on' : ''}" data-a="music" title="Music">${icon('music')}</button>
          <button class="icon-btn" data-a="leave" title="Leave the game">${icon('flag')}</button>
        </div>`;
      this.top.querySelectorAll<HTMLButtonElement>('[data-a]').forEach((b) =>
        b.addEventListener('click', () => {
          const a = b.dataset.a!;
          if (a === 'help') this.h.onHelp();
          else if (a === 'leave') this.h.onLeave();
          else this.h.onToggle(a as 'sfx' | 'music' | 'follow');
        }),
      );
    });
  }

  private renderPlayers(v: GameView, me: string | null) {
    const ph = v.phase;
    const sig = JSON.stringify([
      v.players.map((p) => [p.id, p.name, p.color, p.francs, p.pigments, p.inspiration, p.hand.length, p.collection.map((a) => a.id), p.connected, p.patronChosen]),
      v.turn,
      ph.kind,
      ph.kind === 'auction' ? ph.submitted : null,
      v.trends,
      me,
    ]);
    renderIf(this.players, sig, () => {
      this.players.innerHTML = '';
      v.players.forEach((p, i) => {
        const card = el('div', `pc ${i === v.turn && ph.kind !== 'patrons' && ph.kind !== 'over' ? 'active' : ''} ${p.id === me ? 'me' : ''} ${p.connected ? '' : 'away'}`);
        card.style.setProperty('--pc', p.color);
        let status = '';
        if (ph.kind === 'auction') status = ph.submitted.includes(p.id) ? `<span class="st ok">${icon('check')} Bid sealed</span>` : '<span class="st">Deciding…</span>';
        if (ph.kind === 'patrons') status = p.patronChosen ? `<span class="st ok">${icon('check')} Patron chosen</span>` : '<span class="st">Choosing…</span>';
        card.innerHTML = `
          <div class="pc-head">
            <span class="pc-pawn">${icon(p.hat)}</span>
            <span class="pc-name">${esc(p.name)}</span>
            ${p.id === me ? '<span class="tag">You</span>' : ''}
            ${p.isBot ? `<span class="tag bot" title="Bot">${icon('bot')}</span>` : ''}
            ${!p.connected && !p.isBot ? `<span class="tag away" title="Disconnected — autopilot will play">${icon('offline')}</span>` : ''}
            <span class="pc-score" title="Prestige on display (secret patrons and awards are revealed at the Gala)">${prestige(visiblePrestige(p, v.trends))}</span>
          </div>
          <div class="pc-res">${francs(p.francs)}${pig('red', p.pigments.red)}${pig('blue', p.pigments.blue)}${pig('yellow', p.pigments.yellow)}${insp(p.inspiration)}<span class="res" title="Sketches in hand">${icon('sketch')}<b>${p.hand.length}</b></span></div>
          ${status ? `<div class="pc-status">${status}</div>` : ''}`;
        const gal = el('div', 'pc-gallery');
        for (const a of p.collection) {
          const img = artImg(a, `thumb ${a.kind}`);
          img.title = `${a.title} — ${MOVEMENT_INFO[a.movement].name}, ${a.value} + ${v.trends[a.movement]}`;
          img.addEventListener('click', () => this.h.onArt(a, p));
          gal.appendChild(img);
        }
        if (!p.collection.length) gal.innerHTML = '<span class="empty">No works yet</span>';
        card.appendChild(gal);
        this.players.appendChild(card);
      });
    });
  }

  private renderTrends(v: GameView) {
    renderIf(this.trends, JSON.stringify(v.trends), () => {
      this.trends.innerHTML =
        `<div class="panel-title">${icon('laurel')} Fashion at the Salon</div>` +
        MOVEMENTS.map((m) => {
          const info = MOVEMENT_INFO[m];
          return `<div class="trend-row" style="--mv:${info.color}" title="${esc(info.blurb)} Each ${esc(info.name)} work scores +${v.trends[m]} at the Gala.">
            <span class="mv-ic">${icon(m)}</span><span class="tr-name">${esc(info.name)}</span>${trendStars(v.trends[m], RULES.trendMax)}<b class="tr-val">+${v.trends[m]}</b></div>`;
        }).join('');
    });
  }

  private renderAwards(v: GameView) {
    const results = evaluateAwards(v.awards, v.players, v.trends);
    const sig = JSON.stringify(results);
    renderIf(this.awards, sig, () => {
      this.awards.innerHTML =
        `<div class="panel-title">${icon('crown')} Society Awards <small>+${RULES.awardPoints} each</small></div>` +
        results
          .map((r) => {
            const a = awardInfo(r.id);
            const leaders = r.winners.map((id) => v.players.find((p) => p.id === id)!).filter(Boolean);
            return `<div class="award-row"><div class="aw-name">${esc(a.name)}</div><div class="aw-text">${esc(a.text)}</div>
              <div class="aw-lead">${leaders.length ? `Leading: ${leaders.map((p) => `${dot(p.color)}${esc(p.name)}`).join(' ')}` : '<span class="muted">No one yet</span>'}</div></div>`;
          })
          .join('');
    });
  }

  private renderMuse(v: GameView) {
    const sig = JSON.stringify([v.canvasRow.map((c) => c.id), v.canvasDeckCount, v.lotDeckCount]);
    renderIf(this.muse, sig, () => {
      this.muse.innerHTML = `<div class="panel-title">${icon('muse')} The Muse offers <small>${v.canvasDeckCount} in deck · ${v.lotDeckCount} masterpieces in the vault</small></div>`;
      const row = el('div', 'muse-row');
      for (const c of v.canvasRow) row.appendChild(artCard(c, { cls: 'mini', onClick: () => this.h.onArt(c) }));
      if (!v.canvasRow.length) row.innerHTML = '<span class="muted">The Muse is silent.</span>';
      this.muse.appendChild(row);
    });
  }

  private renderStudio(v: GameView, me: string | null) {
    const p = v.players.find((x) => x.id === me);
    if (!p) {
      this.studio.innerHTML = '';
      return;
    }
    const myTurn = v.players[v.turn].id === me && (v.phase.kind === 'roll' || v.phase.kind === 'paint');
    const sig = JSON.stringify([p.francs, p.pigments, p.inspiration, p.hand.map((c) => c.id), p.patron, myTurn, v.trends]);
    renderIf(this.studio, sig, () => {
      this.studio.innerHTML = '';
      const res = el(
        'div',
        'st-res',
        `<div class="st-label">Your studio</div>
         <div class="st-chips">${francs(p.francs, 'big')}${pig('red', p.pigments.red, 'big')}${pig('blue', p.pigments.blue, 'big')}${pig('yellow', p.pigments.yellow, 'big')}${insp(p.inspiration, 'big')}</div>
         <div class="st-hint">Mix: any 2 spare pigments = 1 missing colour</div>`,
      );
      const hand = el('div', 'st-hand');
      if (!p.hand.length) hand.innerHTML = `<div class="empty-hand">${icon('sketch')}<span>No sketches. Visit <b>The Muse</b> for inspiration.</span></div>`;
      for (const c of p.hand) {
        const pay = paymentFor(p.pigments, c.cost);
        const mix = mixedCount(p.pigments, c.cost);
        const can = myTurn && !!pay;
        const label = pay ? (mix ? `Paint · mix ${mix}` : 'Paint') : 'Need pigment';
        const btn = `<button class="btn paint ${can ? 'primary' : ''}" ${can ? '' : 'disabled'} data-id="${c.id}">${label}</button>`;
        const card = artCard(c, { have: p.pigments, trend: v.trends[c.movement], overlay: btn, cls: can ? 'ready' : pay ? '' : 'short' });
        card.querySelector('.frame')!.addEventListener('click', () => this.h.onArt(c, p));
        card.querySelector<HTMLButtonElement>('.paint')!.addEventListener('click', (e) => {
          e.stopPropagation();
          if (can) this.h.onPaint(c.id);
        });
        hand.appendChild(card);
      }
      const patron = el('div', 'st-patron', `<div class="st-label">Secret patron</div>${patronCard(p.patron)}`);
      this.studio.append(res, hand, patron);
    });
  }
}
