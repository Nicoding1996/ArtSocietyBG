import '@fontsource/cormorant-garamond/600.css';
import '@fontsource/cormorant-garamond/700.css';
import '@fontsource/cormorant-garamond/600-italic.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import './styles.css';
import { paintArtwork } from './art/generate';
import { MOVEMENTS } from '../shared/types';
import { App } from './app';

const params = new URLSearchParams(location.search);
const ui = document.getElementById('ui')!;

if (params.has('gallery')) {
  // A wall of sample paintings, handy for tuning the art generators.
  ui.className = 'gallery-page';
  document.getElementById('scene')!.remove();
  const seed0 = Number(params.get('gallery')) || 1;
  for (const movement of MOVEMENTS) {
    for (let i = 0; i < 5; i++) {
      ui.appendChild(paintArtwork({ id: `${movement}${i}`, movement, seed: seed0 * 1000 + i * 7919, kind: i === 4 ? 'masterpiece' : 'canvas' }, 240, 300));
    }
  }
} else {
  new App(ui);
}
