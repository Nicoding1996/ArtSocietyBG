import * as THREE from 'three';
import { BOARD, RULES, spaceInfo } from '../../shared/content';
import type { Space } from '../../shared/types';
import { fbm, makeNoise } from '../util/noise';
import { iconImage } from '../ui/icons';

export function canvas(w: number, h = w): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  // CPU-backed canvases upload to WebGL without a GPU readback stall.
  return [c, c.getContext('2d', { willReadFrequently: true })!];
}

export function toTexture(c: HTMLCanvasElement, srgb = true, repeat = 1): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  if (repeat !== 1) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat, repeat);
  }
  return t;
}

function rgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** Grainy wood with rings running along x. */
export function woodTexture(size: number, dark: string, light: string, seed: number, rings = 40): HTMLCanvasElement {
  const [c, ctx] = canvas(size);
  const img = ctx.createImageData(size, size);
  const n = makeNoise(seed);
  const a = rgb(dark);
  const b = rgb(light);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = x / size;
      const ny = y / size;
      const warp = fbm(n, nx * 3, ny * 10, 3);
      let t = Math.sin((ny * rings + warp * 5) * Math.PI) * 0.5 + 0.5;
      t = Math.pow(t, 2.2) * 0.6 + n(nx * 300, ny * 12) * 0.12 + 0.25;
      t = Math.max(0, Math.min(1, t));
      const i = (y * size + x) * 4;
      img.data[i] = a[0] + (b[0] - a[0]) * t;
      img.data[i + 1] = a[1] + (b[1] - a[1]) * t;
      img.data[i + 2] = a[2] + (b[2] - a[2]) * t;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

export function marbleTexture(size: number, seed: number): HTMLCanvasElement {
  const [c, ctx] = canvas(size);
  const img = ctx.createImageData(size, size);
  const n = makeNoise(seed);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = x / size;
      const ny = y / size;
      const turb = fbm(n, nx * 4, ny * 4, 5);
      const vein = Math.pow(1 - Math.abs(Math.sin((nx * 3 + ny * 2 + turb * 2.6) * Math.PI)), 9);
      const cloud = fbm(n, nx * 9 + 40, ny * 9, 3) * 10;
      const i = (y * size + x) * 4;
      img.data[i] = 236 + cloud - vein * 70;
      img.data[i + 1] = 230 + cloud - vein * 72;
      img.data[i + 2] = 220 + cloud - vein * 66;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

export function feltTexture(size: number, base: string, seed: number): HTMLCanvasElement {
  const [c, ctx] = canvas(size);
  const img = ctx.createImageData(size, size);
  const n = makeNoise(seed);
  const col = rgb(base);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const v = fbm(n, x / 40, y / 40, 3) * 14 + (Math.random() - 0.5) * 10;
      const i = (y * size + x) * 4;
      img.data[i] = col[0] + v;
      img.data[i + 1] = col[1] + v;
      img.data[i + 2] = col[2] + v;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

const GOLD = '#e2c27a';

/** Gold tooling: rings, a diamond per space and the society's motto around the inner ring. */
function drawOrnaments(ctx: CanvasRenderingContext2D, S: number, boardRadius: number, rings: { track: [number, number]; dais: number }, color: string) {
  const cx = S / 2;
  const k = S / 2 / boardRadius;
  const px = S / 2048;
  const ring = (r: number, width: number, alpha = 1) => {
    ctx.strokeStyle = color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = width * px;
    ctx.beginPath();
    ctx.arc(cx, cx, r * k, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  };
  ring(boardRadius - 0.18, 6);
  ring(boardRadius - 0.32, 2, 0.7);
  ring(rings.track[1] + 0.25, 3);
  ring(rings.track[0] - 0.22, 3);
  ring(rings.track[0] - 0.36, 1.5, 0.7);
  ring(rings.dais + 0.2, 2, 0.8);

  const rOuter = (rings.track[1] + 0.25 + boardRadius - 0.32) / 2;
  for (let i = 0; i < RULES.boardSize; i++) {
    const a = Math.PI / 2 + (i + 0.5) * ((Math.PI * 2) / RULES.boardSize);
    ctx.save();
    ctx.translate(cx + Math.cos(a) * rOuter * k, cx + Math.sin(a) * rOuter * k);
    ctx.rotate(a);
    ctx.scale(px, px);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(-12, 0);
    ctx.lineTo(0, -7);
    ctx.lineTo(12, 0);
    ctx.lineTo(0, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  const textR = ((rings.track[0] - 0.36 + rings.dais + 0.2) / 2) * k;
  const phrase = 'THE ART SOCIETY \u2022 SALON DES ARTISTES \u2022 FOND\u00C9E EN MDCCCLXXIV \u2022 ';
  ctx.font = `700 ${Math.round(k * 0.5)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const spacing = k * 0.07;
  const total = [...phrase].reduce((s, ch) => s + ctx.measureText(ch).width + spacing, 0);
  const reps = Math.max(1, Math.round((Math.PI * 2 * textR) / total));
  const scale = (Math.PI * 2 * textR) / (total * reps);
  let theta = Math.PI / 2;
  for (let r = 0; r < reps; r++) {
    for (const ch of phrase) {
      const wch = (ctx.measureText(ch).width + spacing) * scale;
      theta -= wch / 2 / textR;
      ctx.save();
      ctx.translate(cx + Math.cos(theta) * textR, cx + Math.sin(theta) * textR);
      ctx.rotate(theta - Math.PI / 2);
      ctx.fillText(ch, 0, 0);
      ctx.restore();
      theta -= wch / 2 / textR;
    }
  }
}

/** The board's top face: leather with gold tooling. `mr` packs roughness (G) and metalness (B). */
export function boardTopTextures(boardRadius: number, rings: { track: [number, number]; dais: number }) {
  const S = 2048;
  const [c, ctx] = canvas(S);
  const cx = S / 2;
  const g = ctx.createRadialGradient(cx, cx, 0, cx, cx, S / 2);
  g.addColorStop(0, '#1d4a40');
  g.addColorStop(0.7, '#163a33');
  g.addColorStop(1, '#0e2723');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  // Leather grain: a small noise tile blended over the gradient.
  const N = 512;
  const [nc, nctx] = canvas(N);
  const nimg = nctx.createImageData(N, N);
  const n = makeNoise(7);
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const i = (y * N + x) * 4;
      const v = 128 + n(x / 3, y / 3) * 22 + n(x / 30, y / 30) * 26 + (Math.random() - 0.5) * 18;
      nimg.data[i] = nimg.data[i + 1] = nimg.data[i + 2] = v;
      nimg.data[i + 3] = 255;
    }
  }
  nctx.putImageData(nimg, 0, 0);
  ctx.globalCompositeOperation = 'overlay';
  ctx.globalAlpha = 0.35;
  ctx.drawImage(nc, 0, 0, S, S);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';
  drawOrnaments(ctx, S, boardRadius, rings, GOLD);

  const M = 1024;
  const [mr, mctx] = canvas(M);
  mctx.fillStyle = 'rgb(0,190,0)';
  mctx.fillRect(0, 0, M, M);
  drawOrnaments(mctx, M, boardRadius, rings, 'rgb(0,80,255)');
  return { color: c, mr };
}

const TILE_ICON: Record<Space['type'], string> = {
  hall: 'hall',
  pigment: 'drop',
  muse: 'muse',
  shop: 'shop',
  patron: 'coin',
  auction: 'gavel',
  gazette: 'gazette',
  soiree: 'soiree',
};

function shade(hex: string, f: number): string {
  const [r, g, b] = rgb(hex);
  const m = (v: number) => Math.round(Math.max(0, Math.min(255, f < 0 ? v * (1 + f) : v + (255 - v) * f)));
  return `rgb(${m(r)},${m(g)},${m(b)})`;
}

/** Decal for one space: enamel colour, gold border, icon and name. */
export async function tileTexture(index: number): Promise<HTMLCanvasElement> {
  const space = BOARD[index];
  const info = spaceInfo(space);
  const W = 512;
  const H = 448;
  const [c, ctx] = canvas(W, H);
  const light = space.type === 'hall';
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, shade(info.color, light ? 0.1 : 0.12));
  g.addColorStop(1, shade(info.color, -0.28));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = 0.08;
  for (let i = 0; i < 40; i++) {
    ctx.strokeStyle = i % 2 ? '#fff' : '#000';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(W / 2, H * 1.6, 80 + i * 22, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.strokeStyle = light ? '#b08a3e' : GOLD;
  ctx.lineWidth = 8;
  ctx.strokeRect(22, 22, W - 44, H - 44);
  ctx.lineWidth = 2;
  ctx.strokeRect(38, 38, W - 76, H - 76);

  const fg = light ? '#7a5a22' : '#fbf3dc';
  const iconCol = space.type === 'pigment' ? '#fbf3dc' : fg;
  const img = await iconImage(TILE_ICON[space.type], iconCol, 200, space.type === 'hall' ? 1.4 : 1.5);
  ctx.shadowColor = 'rgba(0,0,0,0.35)';
  ctx.shadowBlur = 12;
  ctx.drawImage(img, W / 2 - 100, 58, 200, 200);
  ctx.shadowBlur = 0;
  ctx.fillStyle = fg;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const label = (index === 0 ? 'Society Hall' : info.short).toUpperCase();
  ctx.font = `700 ${label.length > 9 ? 56 : 64}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillText(label, W / 2, H - 112, W - 90);
  if (space.type === 'pigment') {
    ctx.font = `600 34px Inter, sans-serif`;
    ctx.fillText(`+${RULES.pigmentGain}`, W / 2, 164);
  }
  return c;
}

/** One face of the die. */
export function dieFace(value: number): HTMLCanvasElement {
  const S = 256;
  const [c, ctx] = canvas(S);
  const g = ctx.createRadialGradient(S * 0.4, S * 0.35, 10, S / 2, S / 2, S * 0.75);
  g.addColorStop(0, '#fffaf0');
  g.addColorStop(1, '#e6dcc6');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const pip = (x: number, y: number) => {
    const pg = ctx.createRadialGradient(x - 6, y - 6, 2, x, y, 26);
    const red = value === 1;
    pg.addColorStop(0, red ? '#e04848' : '#3a2f2a');
    pg.addColorStop(1, red ? '#8e1d1d' : '#120d0b');
    ctx.fillStyle = pg;
    ctx.beginPath();
    ctx.arc(x, y, red ? 34 : 24, 0, Math.PI * 2);
    ctx.fill();
  };
  const L = S * 0.27;
  const M = S * 0.5;
  const R = S * 0.73;
  const layouts: Record<number, [number, number][]> = {
    1: [[M, M]],
    2: [[L, L], [R, R]],
    3: [[L, L], [M, M], [R, R]],
    4: [[L, L], [R, L], [L, R], [R, R]],
    5: [[L, L], [R, L], [M, M], [L, R], [R, R]],
    6: [[L, L], [R, L], [L, M], [R, M], [L, R], [R, R]],
  };
  for (const [x, y] of layouts[value]) pip(x, y);
  return c;
}

/** Round badge with an icon, used above the trend columns. */
export async function badgeTexture(iconName: string, color: string): Promise<HTMLCanvasElement> {
  const S = 128;
  const [c, ctx] = canvas(S);
  ctx.fillStyle = 'rgba(18,14,20,0.82)';
  ctx.beginPath();
  ctx.arc(S / 2, S / 2, S / 2 - 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 6;
  ctx.stroke();
  const img = await iconImage(iconName, color, 80, 1.8);
  ctx.drawImage(img, S / 2 - 40, S / 2 - 40, 80, 80);
  return c;
}

export function glowTexture(): HTMLCanvasElement {
  const S = 128;
  const [c, ctx] = canvas(S);
  const g = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(255,240,200,0.6)');
  g.addColorStop(1, 'rgba(255,220,150,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  return c;
}
