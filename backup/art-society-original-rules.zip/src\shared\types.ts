export const PIGMENTS = ['red', 'blue', 'yellow'] as const;
export type Pigment = (typeof PIGMENTS)[number];
export type PigmentSet = Record<Pigment, number>;

export const MOVEMENTS = ['impressionism', 'postimpressionism', 'cubism', 'ukiyoe', 'abstract'] as const;
export type MovementId = (typeof MOVEMENTS)[number];

export const HATS = ['beret', 'tophat', 'bowler', 'flower'] as const;
export type HatId = (typeof HATS)[number];

export interface Artwork {
  id: string;
  kind: 'canvas' | 'masterpiece';
  title: string;
  movement: MovementId;
  /** Pigments needed to paint it (all zero for masterpieces). */
  cost: PigmentSet;
  /** Base prestige. */
  value: number;
  /** Seed for the procedural painting, identical on every client. */
  seed: number;
  /** Fictional old master, masterpieces only. */
  artist?: string;
  paintedBy?: string;
}

export type SpaceType = 'hall' | 'pigment' | 'muse' | 'shop' | 'patron' | 'auction' | 'gazette' | 'soiree';

export interface Space {
  type: SpaceType;
  pigment?: Pigment;
}

export type PatronId =
  | 'lumiere'
  | 'vincenzo'
  | 'vogel'
  | 'sakura'
  | 'kandin'
  | 'curator'
  | 'baron'
  | 'marteau'
  | 'plenty'
  | 'aurelius'
  | 'vogue'
  | 'pur';

export type AwardId =
  | 'prolific'
  | 'connoisseur'
  | 'eclectic'
  | 'tycoon'
  | 'visionary'
  | 'benefactor'
  | `master:${MovementId}`;

export type EventId =
  | 'benefactor'
  | 'spill'
  | 'buzz'
  | 'scandal'
  | 'artfair'
  | 'moonlit'
  | 'tax'
  | 'attic'
  | 'dinner'
  | 'fashion'
  | 'shipment'
  | 'envy'
  | 'studiovisit';

export interface PlayerState {
  id: string;
  name: string;
  color: string;
  hat: HatId;
  isBot: boolean;
  connected: boolean;
  position: number;
  francs: number;
  pigments: PigmentSet;
  inspiration: number;
  hand: Artwork[];
  collection: Artwork[];
  /** Secret. Redacted for other players until the game is over. */
  patron: PatronId | null;
  /** Secret. The two patrons offered at the start. */
  patronOffer: PatronId[];
  patronChosen: boolean;
  auctionSpend: number;
}

export type Phase =
  | { kind: 'patrons'; deadline: number }
  | { kind: 'roll' }
  | { kind: 'adjust'; roll: number }
  | { kind: 'muse' }
  | { kind: 'shop' }
  | { kind: 'review' }
  | {
      kind: 'auction';
      lot: Artwork;
      /** Secret bids. In a player's view only their own bid is present. */
      bids: Record<string, number>;
      submitted: string[];
      deadline: number;
    }
  | { kind: 'paint' }
  | { kind: 'over' };

export type PhaseKind = Phase['kind'];

export type LogKind = 'round' | 'turn' | 'gain' | 'paint' | 'auction' | 'event' | 'trend' | 'info';

export interface LogEntry {
  id: number;
  kind: LogKind;
  text: string;
  pid?: string;
}

export interface ArtScore {
  id: string;
  title: string;
  movement: MovementId;
  kind: Artwork['kind'];
  base: number;
  trend: number;
}

export interface PlayerResult {
  pid: string;
  art: ArtScore[];
  artPoints: number;
  awards: AwardId[];
  awardPoints: number;
  patron: PatronId | null;
  patronPoints: number;
  francs: number;
  francPoints: number;
  total: number;
  rank: number;
}

export interface AwardResult {
  id: AwardId;
  winners: string[];
  value: number;
}

export interface GameResults {
  players: PlayerResult[];
  awards: AwardResult[];
  winners: string[];
  trends: Record<MovementId, number>;
}

export interface GameState {
  seed: number;
  rng: number;
  round: number;
  totalRounds: number;
  /** Index into players of the active player. */
  turn: number;
  players: PlayerState[];
  trends: Record<MovementId, number>;
  canvasDeck: Artwork[];
  canvasRow: Artwork[];
  lotDeck: Artwork[];
  eventDeck: EventId[];
  awards: AwardId[];
  phase: Phase;
  lastRoll: number | null;
  log: LogEntry[];
  logSeq: number;
  results: GameResults | null;
}

/** What a single client receives: decks become counts, other players' secrets are removed. */
export interface GameView extends Omit<GameState, 'rng' | 'canvasDeck' | 'lotDeck' | 'eventDeck'> {
  canvasDeckCount: number;
  lotDeckCount: number;
  you: string | null;
}

export type Action =
  | { type: 'choosePatron'; patron: PatronId }
  | { type: 'roll' }
  | { type: 'move'; delta: number }
  | { type: 'pick'; index: number }
  | { type: 'buy'; pigments: PigmentSet }
  | { type: 'review'; praise: MovementId; pan: MovementId | null }
  | { type: 'skip' }
  | { type: 'bid'; amount: number }
  | { type: 'paint'; artId: string }
  | { type: 'endTurn' };

export type ActionType = Action['type'];

export type GameEvent =
  | { t: 'start' }
  | { t: 'patronChosen'; pid: string }
  | { t: 'round'; round: number; final: boolean }
  | { t: 'turn'; pid: string }
  | { t: 'roll'; pid: string; value: number }
  | { t: 'move'; pid: string; from: number; steps: number; delta: number }
  | { t: 'salary'; pid: string; francs: number }
  | { t: 'land'; pid: string; space: number }
  | {
      t: 'gain';
      pid: string;
      francs?: number;
      inspiration?: number;
      pigments?: Partial<PigmentSet>;
    }
  | { t: 'take'; pid: string; art: Artwork; from: 'row' | 'deck' }
  | { t: 'buy'; pid: string; pigments: PigmentSet; cost: number }
  | { t: 'paint'; pid: string; art: Artwork; paid: PigmentSet }
  | { t: 'trend'; movement: MovementId; delta: number; value: number; pid?: string }
  | { t: 'review'; pid: string; praise: MovementId; pan: MovementId | null }
  | { t: 'soiree'; pid: string; event: EventId; text: string }
  | { t: 'auction'; pid: string; lot: Artwork; deadline: number }
  | { t: 'bid'; pid: string }
  | {
      t: 'sold';
      lot: Artwork;
      winner: string | null;
      price: number;
      bids: Record<string, number>;
    }
  | { t: 'over' };

export interface LobbyPlayer {
  id: string;
  name: string;
  color: string;
  hat: HatId;
  isBot: boolean;
  connected: boolean;
}

export interface RoomSettings {
  rounds: number;
}

export interface RoomView {
  code: string;
  hostId: string;
  status: 'lobby' | 'game';
  settings: RoomSettings;
  players: LobbyPlayer[];
}

export type ClientMessage =
  | { t: 'hello'; token: string; room?: string }
  | { t: 'create'; name: string }
  | { t: 'join'; code: string; name: string }
  | { t: 'leave' }
  | { t: 'profile'; name?: string; color?: string; hat?: HatId }
  | { t: 'settings'; rounds: number }
  | { t: 'addBot' }
  | { t: 'removeBot'; id: string }
  | { t: 'start' }
  | { t: 'act'; action: Action }
  | { t: 'chat'; text: string }
  | { t: 'react'; emoji: string }
  | { t: 'back' }
  | { t: 'toLobby' };

export type ServerMessage =
  | { t: 'welcome'; serverTime: number }
  | { t: 'room'; room: RoomView; you: string; serverTime: number }
  | { t: 'game'; view: GameView; events: GameEvent[]; serverTime: number }
  | { t: 'chat'; pid: string; name: string; color: string; text: string }
  | { t: 'react'; pid: string; emoji: string }
  | { t: 'error'; message: string }
  | { t: 'idle' }
  | { t: 'left' };
