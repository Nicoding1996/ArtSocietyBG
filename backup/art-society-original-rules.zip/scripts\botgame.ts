import { applyAction, applyTimeout, createGame, viewFor, waitingOn } from '../src/shared/engine';
import { botDecide } from '../src/shared/bot';
import { makeRng } from '../src/shared/rng';
import { PLAYER_COLORS } from '../src/shared/content';
import type { GameEvent, GameState } from '../src/shared/types';

/** Plays a full game where every seat is a bot. Throws if a bot makes an illegal move or the game stalls. */
export function playBotGame(
  seed: number,
  players: number,
  totalRounds: number,
  onEvents?: (events: GameEvent[], s: GameState) => void,
): { s: GameState; auctions: number; actions: number } {
  const { state: s, events } = createGame({
    seed,
    rounds: totalRounds,
    now: 0,
    players: Array.from({ length: players }, (_, i) => ({
      id: `p${i}`,
      name: `Bot ${i}`,
      color: PLAYER_COLORS[i],
      hat: 'beret' as const,
      isBot: true,
    })),
  });
  onEvents?.(events, s);
  const r = makeRng(seed ^ 0x9e3779b9);
  let auctions = 0;
  let actions = 0;
  let now = 0;
  while (s.phase.kind !== 'over') {
    let progressed = false;
    for (const pid of waitingOn(s)) {
      const a = botDecide(viewFor(s, pid), pid, r);
      if (!a) continue;
      const res = applyAction(s, pid, a, now);
      if (!res.ok) throw new Error(`Bot ${pid} made an illegal move ${JSON.stringify(a)}: ${res.error}`);
      if (res.events.some((e) => e.t === 'auction')) auctions++;
      onEvents?.(res.events, s);
      actions++;
      progressed = true;
      break;
    }
    if (!progressed) {
      now += 60_000;
      const ev = applyTimeout(s, now);
      if (!ev) throw new Error(`Game stalled in phase ${s.phase.kind}`);
      onEvents?.(ev, s);
    }
    if (actions > 20000) throw new Error('Game did not finish');
  }
  return { s, auctions, actions };
}
