import { EVENTS, MOVEMENT_INFO, RULES, spaceInfo, BOARD, PATRONS } from '../../shared/content';
import type { Artwork, EventId, MovementId, PlayerState } from '../../shared/types';
import { artImg } from '../art/generate';
import { el, esc, sleep } from './dom';
import { icon } from './icons';
import { dot, movementTag } from './parts';

let root: HTMLElement;

export function initOverlays(ui: HTMLElement) {
  root = ui;
  for (const cls of ['toasts', 'banner-layer', 'card-layer', 'tooltip', 'modal-layer']) {
    if (!root.querySelector(`.${cls}`)) root.appendChild(el('div', cls));
  }
}

const layer = (cls: string) => root.querySelector(`.${cls}`) as HTMLElement;

export function toast(text: string, kind: 'info' | 'error' | 'chat' = 'info', ms = 3200) {
  const html = esc(text);
  // The same message twice in a row only needs one toast.
  if ([...layer('toasts').children].some((c) => c.innerHTML === html)) return;
  const t = el('div', `toast ${kind}`, html);
  layer('toasts').appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 400);
  }, ms);
}

export async function banner(title: string, sub = '', ms = 1700, cls = '') {
  const b = el('div', `banner ${cls}`, `<div class="banner-title">${esc(title)}</div>${sub ? `<div class="banner-sub">${esc(sub)}</div>` : ''}`);
  const l = layer('banner-layer');
  l.innerHTML = '';
  l.appendChild(b);
  requestAnimationFrame(() => b.classList.add('show'));
  await sleep(ms);
  b.classList.remove('show');
  setTimeout(() => b.remove(), 500);
}

/** A card that slides in at the centre for a moment (soirée, gazette, auction results). */
async function showCard(node: HTMLElement, ms: number) {
  const l = layer('card-layer');
  l.innerHTML = '';
  l.appendChild(node);
  requestAnimationFrame(() => node.classList.add('show'));
  await sleep(ms);
  node.classList.remove('show');
  await sleep(350);
  node.remove();
}

export function soireeCard(id: EventId, text: string, who: PlayerState | undefined, ms: number) {
  const e = EVENTS[id];
  const card = el(
    'div',
    'event-card soiree',
    `<div class="ev-kicker">${icon('soiree')} Soirée${who ? ` · ${esc(who.name)}` : ''}</div>
     <div class="ev-title">${esc(e.title)}</div>
     <div class="ev-text">${esc(text)}</div>`,
  );
  return showCard(card, ms);
}

export function gazetteCard(who: PlayerState | undefined, praise: MovementId, pan: MovementId | null, ms: number) {
  const card = el(
    'div',
    'event-card gazette',
    `<div class="ev-kicker">${icon('gazette')} The Gazette · Late Edition</div>
     <div class="ev-title">“${esc(MOVEMENT_INFO[praise].name)} is the toast of Paris!”</div>
     <div class="ev-text">${pan ? `Our critic finds ${esc(MOVEMENT_INFO[pan].name)} sadly passé. ` : ''}— review by ${esc(who?.name ?? 'a critic')}</div>
     <div class="ev-trends"><span class="up">${movementTag(praise)} ▲</span>${pan ? `<span class="down">${movementTag(pan)} ▼</span>` : ''}</div>`,
  );
  return showCard(card, ms);
}

export function paintedCard(art: Artwork, who: PlayerState | undefined, ms: number) {
  const card = el('div', 'event-card painted');
  card.appendChild(el('div', 'ev-kicker', `${icon('sketch')} New work by ${esc(who?.name ?? 'an artist')}`));
  const frame = el('div', 'frame big');
  frame.appendChild(artImg(art));
  card.appendChild(frame);
  card.appendChild(el('div', 'ev-title', esc(art.title)));
  card.appendChild(el('div', 'ev-text', `${movementTag(art.movement)} · ${art.value} prestige`));
  return showCard(card, ms);
}

export function auctionResultCard(lot: Artwork, bids: Record<string, number>, winner: string | null, players: PlayerState[], ms: number) {
  const card = el('div', 'event-card auction-result');
  card.appendChild(el('div', 'ev-kicker', `${icon('gavel')} The hammer falls`));
  const row = el('div', 'ar-row');
  const frame = el('div', 'frame big gilded');
  frame.appendChild(artImg(lot));
  row.appendChild(frame);
  const list = el('div', 'bids');
  const sorted = [...players].sort((a, b) => (bids[b.id] ?? 0) - (bids[a.id] ?? 0));
  sorted.forEach((p, i) => {
    const b = el('div', `bid ${p.id === winner ? 'winner' : ''}`, `${dot(p.color)}<span class="bid-name">${esc(p.name)}</span><span class="bid-amt">${bids[p.id] ?? 0} ₣</span>`);
    b.style.animationDelay = `${0.25 + i * 0.22}s`;
    list.appendChild(b);
  });
  row.appendChild(list);
  card.appendChild(row);
  const w = players.find((p) => p.id === winner);
  card.appendChild(el('div', 'ev-title', w ? `${esc(w.name)} wins “${esc(lot.title)}”` : `No bids — “${esc(lot.title)}” returns to the vault`));
  return showCard(card, ms);
}

export function hideCards() {
  const l = layer('card-layer');
  if (l) l.innerHTML = '';
}

export function tooltip(html: string | null, x = 0, y = 0) {
  const t = layer('tooltip');
  if (!html) {
    t.classList.remove('show');
    return;
  }
  if (t.dataset.html !== html) {
    t.innerHTML = html;
    t.dataset.html = html;
  }
  t.style.transform = `translate(${Math.min(window.innerWidth - 280, x + 16)}px, ${Math.min(window.innerHeight - 120, y + 16)}px)`;
  t.classList.add('show');
}

export function spaceTooltip(space: number): string {
  const info = spaceInfo(BOARD[space]);
  return `<div class="tt-title" style="--sc:${info.color}">${esc(info.name)}</div><div class="tt-text">${esc(info.text)}</div>`;
}

export function closeModal() {
  layer('modal-layer').innerHTML = '';
}

function modal(content: HTMLElement, cls = '') {
  const l = layer('modal-layer');
  l.innerHTML = '';
  const back = el('div', `modal-back ${cls}`);
  const box = el('div', 'modal');
  const close = el('button', 'icon-btn modal-close', icon('close'));
  close.title = 'Close';
  close.onclick = closeModal;
  box.append(close, content);
  back.appendChild(box);
  back.addEventListener('click', (e) => {
    if (e.target === back) closeModal();
  });
  l.appendChild(back);
}

export function lightbox(art: Artwork, owner?: PlayerState, trend?: number) {
  const wrap = el('div', 'lightbox');
  const frame = el('div', `frame huge ${art.kind === 'masterpiece' ? 'gilded' : ''}`);
  frame.appendChild(artImg(art));
  const info = el(
    'div',
    'lb-info',
    `<div class="lb-title">${esc(art.title)}</div>
     <div class="lb-sub">${art.kind === 'masterpiece' ? `Masterpiece by ${esc(art.artist)}` : owner ? `Painted by ${esc(owner.name)}` : 'Sketch'}</div>
     <div class="lb-meta">${movementTag(art.movement)}<span class="value">${icon('laurel')}${art.value}${trend !== undefined ? ` + ${trend} trend` : ''}</span></div>
     <p class="lb-blurb">${esc(MOVEMENT_INFO[art.movement].blurb)}</p>`,
  );
  wrap.append(frame, info);
  modal(wrap, 'lb-back');
}

export function showHelp() {
  const c = el('div', 'help');
  const spaces = ['hall', 'pigment', 'muse', 'shop', 'patron', 'auction', 'gazette', 'soiree'] as const;
  const rows = spaces
    .map((t) => {
      const i = BOARD.findIndex((s) => s.type === t);
      const info = spaceInfo(BOARD[i]);
      const name = t === 'pigment' ? 'Pigment markets' : info.name;
      const text = t === 'pigment' ? `Gather +${RULES.pigmentGain} pigment of the market's colour (crimson, ultramarine or saffron).` : info.text;
      return `<li><b style="--sc:${info.color}">${esc(name)}</b> ${esc(text)}</li>`;
    })
    .join('');
  c.innerHTML = `
    <h2>How to play</h2>
    <p class="lead">You are a painter in the Art Society. Over the season, travel the boulevard, gather pigments, paint masterpieces and win the favour of critics. At the Grand Gala the Society reveals who earned the most <b>prestige</b>.</p>
    <div class="help-cols">
      <div>
        <h3>Your turn</h3>
        <ol>
          <li><b>Roll</b> the die. Spend <b>✦ inspiration</b> to move one space more or less per ✦.</li>
          <li>Move clockwise and resolve the space you land on.</li>
          <li><b>Paint</b> any sketch in your hand whose pigments you have. Short a colour? <b>Mix</b>: any 2 spare pigments make 1 of another colour.</li>
          <li>End your turn.</li>
        </ol>
        <h3>Scoring at the Grand Gala</h3>
        <ul>
          <li>Every artwork: its prestige <b>+ its movement's trend</b> (0–${RULES.trendMax}).</li>
          <li>Three <b>Society Awards</b>: +${RULES.awardPoints} each to the leader (ties all score).</li>
          <li>Your <b>secret patron</b>'s bonus, revealed at the end.</li>
          <li>+1 prestige for every ${RULES.francsPerPoint} ₣ left over.</li>
        </ul>
      </div>
      <div>
        <h3>The boulevard</h3>
        <ul class="spaces">${rows}</ul>
        <h3>Patrons</h3>
        <p class="small">Each artist secretly serves one of ${Object.keys(PATRONS).length} patrons, such as ${esc(PATRONS.lumiere.name)} (${esc(PATRONS.lumiere.text)}) or ${esc(PATRONS.marteau.name)} (${esc(PATRONS.marteau.text)}). Watch what your rivals collect and guess!</p>
      </div>
    </div>
    <p class="small">Tips: drag to orbit the board, scroll to zoom, click a painting to admire it. Hover a space to see what it does.</p>`;
  modal(c, 'help-back');
}
