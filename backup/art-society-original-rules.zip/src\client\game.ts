import { PIGMENT_INFO, spaceInfo, BOARD } from '../shared/content';
import { PIGMENTS, type Artwork, type GameEvent, type GameView, type MovementId, type PlayerState } from '../shared/types';
import type { Audio } from './audio';
import type { Net } from './net';
import type { World } from './three/world';
import { Ceremony } from './ui/ceremony';
import type { ChatPanel } from './ui/chat';
import { el, esc, sleep } from './ui/dom';
import { Hud } from './ui/hud';
import { icon } from './ui/icons';
import { auctionResultCard, banner, gazetteCard, hideCards, lightbox, paintedCard, showHelp, soireeCard, spaceTooltip, toast, tooltip } from './ui/overlays';
import { Prompts } from './ui/prompts';

interface Shown {
  id: string;
  color: string;
  collection: Artwork[];
}

/** Plays server updates as animations, then shows the resulting state in the HUD and 3D world. */
export class GameScreen {
  readonly root = el('div', 'game-screen');
  private hud: Hud;
  private prompts: Prompts;
  private ceremony: Ceremony;
  private view: GameView | null = null;
  private queue: { view: GameView; events: GameEvent[] }[] = [];
  private busy = false;
  private shown: Shown[] = [];
  private trends: Record<MovementId, number> | null = null;
  private disposed = false;

  constructor(
    private world: World,
    private net: Net,
    private audio: Audio,
    private chat: ChatPanel,
    private me: () => string | null,
    isHost: () => boolean,
    private onLeave: () => void,
  ) {
    this.prompts = new Prompts(
      (action) => {
        this.audio.click();
        this.net.send({ t: 'act', action });
      },
      () => this.net.now(),
      (space) => this.world.board.highlight(space),
    );
    this.hud = new Hud(
      {
        onPaint: (artId) => {
          this.audio.click();
          this.net.send({ t: 'act', action: { type: 'paint', artId } });
        },
        onArt: (art, owner) => this.openArt(art, owner),
        onHelp: () => showHelp(),
        onLeave: () => {
          if (confirm('Leave this game? An autopilot will take over your seat.')) this.onLeave();
        },
        onToggle: (what) => {
          if (what === 'sfx') this.audio.setSfx(!this.audio.sfxOn);
          if (what === 'music') this.audio.setMusic(!this.audio.musicOn);
          if (what === 'follow') this.world.follow = !this.world.follow;
          this.hud.refreshToggles();
          if (this.view) this.hud.render(this.view, this.me());
        },
        toggles: () => ({ sfx: this.audio.sfxOn, music: this.audio.musicOn, follow: this.world.follow }),
      },
      chat,
    );
    this.hud.promptSlot.appendChild(this.prompts.root);
    this.ceremony = new Ceremony(world, audio, () => this.net.send({ t: 'toLobby' }), isHost);
    this.root.appendChild(this.hud.root);
    this.ceremony.mount(this.root);
    world.onHover = (space, x, y) => tooltip(space === null ? null : spaceTooltip(space), x, y);
    world.onPickArt = (art) => this.openArt(art);
  }

  dispose() {
    this.disposed = true;
    this.prompts.dispose();
    this.ceremony.close();
    hideCards();
    tooltip(null);
    this.world.onHover = null;
    this.world.onPickArt = null;
    this.world.board.highlight(null);
    this.root.remove();
  }

  private openArt(art: Artwork, owner?: PlayerState) {
    const v = this.view;
    const o = owner ?? v?.players.find((p) => p.collection.some((a) => a.id === art.id));
    lightbox(art, o, v?.trends[art.movement]);
  }

  rejected(message: string) {
    toast(message, 'error');
    this.audio.error();
    this.prompts.unlock();
  }

  react(pid: string, emoji: string) {
    this.world.float(pid, `<span class="emoji">${esc(emoji)}</span>`, 'react');
  }

  receive(view: GameView, events: GameEvent[]) {
    this.queue.push({ view, events });
    if (!this.busy) void this.process();
  }

  private async process() {
    this.busy = true;
    while (this.queue.length && !this.disposed) {
      const u = this.queue.shift()!;
      // Catch up quickly if updates pile up (e.g. after the tab was in the background).
      const backlog = this.queue.length;
      this.world.tw.speed = backlog > 3 ? 6 : backlog > 0 ? 2 : 1;
      if ((this.view || u.events.some((e) => e.t === 'start')) && u.events.length) {
        this.prompts.hide();
        for (const e of u.events) {
          if (this.disposed) return;
          try {
            await this.play(e, u.view);
          } catch (err) {
            console.error('Animation failed', e, err);
          }
        }
      }
      this.apply(u.view);
    }
    this.world.tw.speed = 1;
    this.busy = false;
  }

  private wait(ms: number) {
    return sleep(ms / this.world.tw.speed);
  }

  private async play(e: GameEvent, next: GameView) {
    const w = this.world;
    const me = this.me();
    const speed = w.tw.speed;
    const who = 'pid' in e ? next.players.find((p) => p.id === e.pid) : undefined;
    switch (e.t) {
      case 'start':
        w.setDemo(false);
        this.audio.gong();
        this.apply(next);
        await banner('The Art Society convenes', 'Choose your secret patron', 2200 / speed);
        break;
      case 'round':
        this.audio.gong();
        void w.overview(1200);
        await banner(e.final ? 'The final round' : `Round ${e.round}`, e.final ? 'Make it count — the Gala awaits!' : `of ${next.totalRounds}`, 1600 / speed, e.final ? 'final' : '');
        break;
      case 'turn':
        w.setActive(e.pid);
        w.followPlayer(e.pid);
        if (e.pid === me) {
          this.audio.chime();
          void banner('Your turn', '', 1100 / speed, 'small');
        }
        await this.wait(450);
        break;
      case 'roll':
        this.audio.diceShake();
        await w.rollDie(e.pid, e.value, () => this.audio.diceHit());
        w.float(e.pid, `${icon('dice')} ${e.value}`, 'roll');
        await this.wait(250);
        break;
      case 'move':
        if (e.delta) w.float(e.pid, `${icon('muse')} ${e.delta > 0 ? '+' : ''}${e.delta}`, 'insp');
        await w.movePawn(e.pid, e.from, e.steps, (space) => this.audio.hop(space));
        break;
      case 'salary':
        w.float(e.pid, `+${e.francs} ₣ stipend`, 'franc');
        this.audio.coin();
        break;
      case 'land': {
        const info = spaceInfo(BOARD[e.space]);
        w.pulseSpace(e.space, '#ffffff');
        w.float(e.pid, esc(info.name), 'space');
        this.audio.land();
        await this.wait(350);
        break;
      }
      case 'gain': {
        const bits: string[] = [];
        if (e.francs) bits.push(`<span class="${e.francs < 0 ? 'neg' : ''}">${e.francs > 0 ? '+' : ''}${e.francs} ₣</span>`);
        if (e.inspiration) bits.push(`<span>+${e.inspiration} ${icon('muse')}</span>`);
        for (const k of PIGMENTS) {
          const n = e.pigments?.[k];
          if (n) bits.push(`<span class="${n < 0 ? 'neg' : ''}" style="--pc:${PIGMENT_INFO[k].color}">${n > 0 ? '+' : ''}${n} <i class="drop"></i></span>`);
        }
        if (bits.length) w.float(e.pid, bits.join(' '), 'gain');
        if (e.francs && e.francs > 0) this.audio.coin();
        else if (e.inspiration || e.pigments) this.audio.sparkle();
        w.sparkleAt(e.pid, '#ffe7a8');
        await this.wait(200);
        break;
      }
      case 'take':
        w.float(e.pid, `+1 ${icon('sketch')} sketch`, 'gain');
        this.audio.paper();
        await this.wait(500);
        break;
      case 'buy':
        w.float(e.pid, `−${e.cost} ₣ · ${PIGMENTS.filter((k) => e.pigments[k]).map((k) => `<span style="--pc:${PIGMENT_INFO[k].color}">+${e.pigments[k]} <i class="drop"></i></span>`).join(' ')}`, 'gain');
        this.audio.coin();
        await this.wait(600);
        break;
      case 'paint': {
        const s = this.shown.find((x) => x.id === e.pid);
        if (s && !s.collection.some((a) => a.id === e.art.id)) s.collection.push(e.art);
        this.audio.brush();
        void paintedCard(e.art, who, 2300 / speed);
        await w.revealArtwork(this.shown, e.art, who?.color ?? '#ffffff');
        await this.wait(500);
        break;
      }
      case 'trend': {
        if (!this.trends) this.trends = { ...next.trends };
        this.trends[e.movement] = e.value;
        w.setTrends(this.trends, true);
        this.audio.trend(e.delta > 0);
        await this.wait(450);
        break;
      }
      case 'review':
        this.audio.paper();
        await gazetteCard(who, e.praise, e.pan, 2000 / speed);
        break;
      case 'soiree':
        this.audio.chime();
        await soireeCard(e.event, e.text, who, 2700 / speed);
        break;
      case 'auction':
        this.audio.gavel(1);
        void banner('Auction!', 'A masterpiece goes under the hammer', 1500 / speed, 'small');
        await w.showLot(e.lot);
        break;
      case 'bid':
        if (e.pid !== me) this.audio.click();
        break;
      case 'sold': {
        this.audio.drumroll(0.8);
        await this.wait(800);
        this.audio.gavel(2);
        const players = next.players;
        await auctionResultCard(e.lot, e.bids, e.winner, players, 3000 / speed);
        await w.sellLot(e.winner);
        if (e.winner) {
          const s = this.shown.find((x) => x.id === e.winner);
          if (s && !s.collection.some((a) => a.id === e.lot.id)) s.collection.push(e.lot);
          await w.revealArtwork(this.shown, e.lot, players.find((p) => p.id === e.winner)?.color ?? '#fff');
        }
        break;
      }
      case 'over':
        await banner('The season is over', 'To the Grand Gala!', 2200 / speed);
        break;
      default:
        break;
    }
  }

  private apply(v: GameView) {
    this.view = v;
    const me = this.me();
    const w = this.world;
    const ph = v.phase;
    const playing = ph.kind !== 'patrons' && ph.kind !== 'over';
    w.syncPawns(
      v.players.map((p) => ({ id: p.id, color: p.color, hat: p.hat, position: p.position })),
      playing ? v.players[v.turn].id : null,
    );
    if (playing) w.followPlayer(v.players[v.turn].id);
    this.shown = v.players.map((p) => ({ id: p.id, color: p.color, collection: [...p.collection] }));
    w.syncGallery(this.shown);
    this.trends = { ...v.trends };
    w.setTrends(v.trends);
    if (ph.kind === 'auction') {
      if (!w.gallery.hasLot) void w.showLot(ph.lot);
    } else if (w.gallery.hasLot) w.hideLotNow();
    this.chat.setColors(Object.fromEntries(v.players.map((p) => [p.id, p.color])));
    this.chat.setLog(v.log);
    this.hud.render(v, me);
    this.prompts.render(v, me);
    if (ph.kind === 'over' && !this.ceremony.started) void this.ceremony.play(v, me);
  }
}
